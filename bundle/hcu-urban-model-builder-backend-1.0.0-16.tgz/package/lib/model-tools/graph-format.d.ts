import { EdgeType, NodeType } from '../client.js';
import type { Edges } from '../services/edges/edges.schema.js';
import type { ModelsVersions } from '../services/models-versions/models-versions.schema.js';
import type { Nodes } from '../services/nodes/nodes.schema.js';
/** Names used towards language models instead of the numeric enums. */
export declare const NODE_TYPE_NAMES: {
    readonly 0: "stock";
    readonly 1: "variable";
    readonly 2: "flow";
    readonly 3: "converter";
    readonly 4: "state";
    readonly 5: "transition";
    readonly 6: "action";
    readonly 7: "population";
    readonly 8: "agent";
    readonly 9: "folder";
    readonly 10: "ghost";
    readonly 11: "ogc-api-features";
};
export declare const EDGE_TYPE_NAMES: {
    readonly 0: "link";
    readonly 1: "flow";
    readonly 2: "transition";
    readonly 3: "agent-population";
};
export type NodeTypeName = (typeof NODE_TYPE_NAMES)[NodeType];
export type EdgeTypeName = (typeof EDGE_TYPE_NAMES)[EdgeType];
export declare const NODE_TYPE_BY_NAME: Record<NodeTypeName, NodeType>;
export declare const EDGE_TYPE_BY_NAME: Record<EdgeTypeName, EdgeType>;
/** Node types a tool may create. Ghost and OGC API Features nodes are read-only for now (see the plan). */
export declare const CREATABLE_NODE_TYPE_NAMES: readonly ["stock", "variable", "flow", "converter", "state", "transition", "action", "population", "agent", "folder"];
export declare const CONTAINER_NODE_TYPES: NodeType[];
export declare const ARROW_NODE_TYPES: NodeType[];
type DataField = {
    description: string;
    formula?: boolean;
};
/**
 * The type-specific fields of `node.data` a tool may set, per node type. This is the single source for input
 * validation and for the reference text given to language models. Fields set by the editor itself (for example
 * the direction of a flow) are intentionally missing.
 */
export declare const NODE_DATA_FIELDS: Partial<Record<NodeType, Record<string, DataField>>>;
/** Values a simulation needs but a language model tends to leave out, set when a tool creates a node. */
export declare const NODE_DATA_CREATE_DEFAULTS: Partial<Record<NodeType, Record<string, unknown>>>;
/** Node types whose values are recorded by default when a tool creates them. */
export declare const DEFAULT_OUTPUT_NODE_TYPES: NodeType[];
/** Returns the names referenced as [Name] in the equations of a node. */
export declare function getFormulaReferences(node: Pick<Nodes, 'type' | 'data'>): string[];
export declare function serializeNode(node: Nodes): Partial<{
    id: string;
    type: "variable" | "state" | "transition" | "action" | "agent" | "flow" | "stock" | "converter" | "population" | "folder" | "ghost" | "ogc-api-features";
    name: string | null | undefined;
    description: string | null | undefined;
    data: ({
        value?: string | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
    } & {
        type?: import("simulation/types").StockTypeType | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        initial?: string | undefined;
        delay?: string | undefined;
        nonNegative?: boolean | undefined;
    } & {
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        nonNegative?: boolean | undefined;
        rate?: string | undefined;
    } & {
        values?: {
            x: number;
            y: number;
        }[] | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        interpolation?: "Linear" | "Discrete" | undefined;
    } & {
        startActive?: string | undefined;
        residency?: string | undefined;
    } & {
        repeat?: boolean | undefined;
        value?: string | undefined;
        action?: string | undefined;
        recalculate?: boolean | undefined;
        trigger?: import("simulation/types").TriggerType | undefined;
    } & {
        repeat?: boolean | undefined;
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        value?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        recalculate?: boolean | undefined;
        trigger?: import("simulation/types").TriggerType | undefined;
    } & {
        populationSize?: number | undefined;
        geoUnits?: string | undefined;
        geoWidth?: string | undefined;
        geoHeight?: string | undefined;
        geoWrapAround?: boolean | undefined;
        geoPlacementType?: import("simulation/types").PlacementType | undefined;
        geoPlacementFunction?: string | undefined;
        networkType?: import("simulation/types").NetworkType | undefined;
        networkFunction?: string | undefined;
    } & {
        query?: {
            offset?: number | undefined;
            properties?: string[] | undefined;
            limit?: number | undefined;
            skipGeometry?: boolean | undefined;
            propertyFilters?: Record<string, {
                operator?: string | undefined;
                value: string;
            }> | undefined;
        } | undefined;
        baseUrl?: string | undefined;
        apiType?: string | undefined;
        endpointId?: string | undefined;
        apiId?: string | undefined;
        collectionId?: string | undefined;
        dataTransform?: {
            keyProperty?: string | undefined;
            valueProperties?: string[] | undefined;
        } | undefined;
    }) | undefined;
    parentId: string | null | undefined;
    ghostOf: string | null | undefined;
    isParameter: true | undefined;
    parameterMin: number | null | undefined;
    parameterMax: number | null | undefined;
    parameterStep: number | null | undefined;
    isOutputParameter: boolean;
    position: {
        x: number;
        y: number;
    };
}>;
export declare function serializeEdge(edge: Edges): {
    id: string;
    type: "link" | "transition" | "flow" | "agent-population";
    source: string;
    target: string;
};
export declare function serializeVersion(version: ModelsVersions): {
    id: string;
    modelId: string;
    version: string;
    state: string;
    isLatest: boolean;
    editable: boolean;
    role: string;
    notes: string | undefined;
    settings: {
        timeUnits: "Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months" | null | undefined;
        timeStart: number | null | undefined;
        timeLength: number | null | undefined;
        timeStep: number | null | undefined;
        algorithm: import("simulation").AlgorithmType | null | undefined;
        globals: string | undefined;
    };
};
export {};
