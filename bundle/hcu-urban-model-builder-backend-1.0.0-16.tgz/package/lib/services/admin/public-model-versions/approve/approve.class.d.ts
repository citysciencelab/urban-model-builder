import type { NullableId, Params } from '@feathersjs/feathers';
import type { Application } from '../../../../declarations.js';
import type { AdminPublicModelVersionsApprove, AdminPublicModelVersionsApprovePatch, AdminPublicModelVersionsApproveQuery } from './approve.schema.js';
export type { AdminPublicModelVersionsApprove, AdminPublicModelVersionsApprovePatch, AdminPublicModelVersionsApproveQuery };
export interface AdminPublicModelVersionsApproveServiceOptions {
    app: Application;
}
export interface AdminPublicModelVersionsApproveParams extends Params<AdminPublicModelVersionsApproveQuery> {
}
export declare class AdminPublicModelVersionsApproveService {
    options: AdminPublicModelVersionsApproveServiceOptions;
    app: Application;
    constructor(options: AdminPublicModelVersionsApproveServiceOptions);
    patch(id: NullableId, _data: AdminPublicModelVersionsApprovePatch, params?: AdminPublicModelVersionsApproveParams): Promise<{
        role?: number | null | undefined;
        algorithm?: import("simulation").AlgorithmType | null | undefined;
        updatedAt?: string | null | undefined;
        deletedAt?: string | null | undefined;
        parentId?: string | null | undefined;
        notes?: string | null | undefined;
        timeUnits?: "Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months" | null | undefined;
        timeStart?: number | null | undefined;
        timeLength?: number | null | undefined;
        timeStep?: number | null | undefined;
        isLatest?: boolean | null | undefined;
        globals?: string | null | undefined;
        customUnits?: {
            data: Record<string, number[]>;
        } | null | undefined;
        ogcEndpoints?: {
            apiType?: import("../../../../client.js").OgcApiType | undefined;
            name: string;
            id: string;
            isDefault: boolean;
            baseUrl: string;
        }[] | null | undefined;
        createdBy?: string | null | undefined;
        publishedBy?: string | null | undefined;
        publishedToUMPAt?: string | null | undefined;
        publishedToUMPApprovedAt?: string | null | undefined;
        id: string;
        createdAt: string;
        modelId: string;
        majorVersion: number;
        minorVersion: number;
        draftVersion: number;
        publishedAt: string;
    }>;
}
export declare const getOptions: (app: Application) => {
    app: Application;
};
