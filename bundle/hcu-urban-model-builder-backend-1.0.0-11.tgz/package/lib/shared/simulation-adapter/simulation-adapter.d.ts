import { Logger } from 'winston';
import { ClientApplication } from '../../client.js';
import { Application } from '../../declarations.js';
type PopulationNodeResult = {
    id: string;
    location: [number, number];
    state: number[];
}[][];
type SimulationResultSeries = number[] | number[][] | Record<string, number>[] | PopulationNodeResult;
type SimulationResult = {
    nodes: Record<string, {
        series: SimulationResultSeries;
    }>;
    times: number[];
};
export declare const NODE_TYPE_TO_PARAMETER_NAME_MAP: {
    readonly 0: "initial";
    readonly 1: "value";
    readonly 2: "rate";
    readonly 4: "startActive";
    readonly 5: "value";
    readonly 7: "populationSize";
};
export declare class SimulationAdapter<T extends ClientApplication | Application> {
    private modelVersionId;
    private nodeIdToParameterValueMap;
    private logger;
    private app;
    private model;
    private nodeIdPrimitiveMapWithGhosts;
    private nodeIdPrimitiveMapWithoutGhosts;
    private ghostParentToChildIdMap;
    private primitiveIdNodeIdMap;
    private primitiveIdTypeMap;
    private outputParameterNodesIds;
    private simulationResultBeforeSerialization;
    constructor(app: T, modelVersionId: string, nodeIdToParameterValueMap: Map<string, number>, logger?: Logger | typeof console);
    simulate(): Promise<this>;
    getResults(): SimulationResult;
    getResultsForUMP(): Record<string, any>;
    private createSimulationModel;
    private createModelPrimitives;
    private addGhostNodesToPrimitiveMap;
    private assignPrimitiveParents;
    private assignConverterInput;
    private assignAgentPopulation;
    private createModelRelationsByEdges;
    private serializeSimulationResult;
    private serializeSimulationResultForUMP;
    private setPrimitiveStartEndByEdge;
    private setParameter;
    private isParameterNodeType;
}
export {};
