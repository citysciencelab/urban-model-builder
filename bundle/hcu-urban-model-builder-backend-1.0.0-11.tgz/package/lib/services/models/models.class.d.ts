import type { Params } from '@feathersjs/feathers';
import { KnexService } from '@feathersjs/knex';
import type { KnexAdapterParams, KnexAdapterOptions } from '@feathersjs/knex';
import type { Application } from '../../declarations.js';
import { type Models, type ModelsCloneVersion, type ModelsData, type ModelsExport, type ModelsImport, type ModelsNewDraft, type ModelsPatch, type ModelsPublish, type ModelsQuery, type ModelsSimulate } from './models.schema.js';
import { ModelsVersions } from '../models-versions/models-versions.schema.js';
import { Nodes } from '../nodes/nodes.schema.js';
import { Edges } from '../edges/edges.schema.js';
import { Scenarios } from '../scenarios/scenarios.schema.js';
import { ScenarioValues } from '../scenarios-values/scenarios-values.schema.js';
export type { Models, ModelsData, ModelsPatch, ModelsQuery };
export interface ModelsParams extends KnexAdapterParams<ModelsQuery> {
    serializeForUMP?: boolean;
}
export interface ModelsServiceOptions extends KnexAdapterOptions {
    app: Application;
}
type ExportedScenario = {
    scenario: Scenarios;
    scenarioValues: ScenarioValues[];
};
type ExportedModelVersion = {
    modelVersion: ModelsVersions;
    nodes: Nodes[];
    edges: Edges[];
    scenarios: ExportedScenario[];
};
type ExportedModelPayload = {
    schemaVersion: 1;
    exportedAt: string;
    model: Models;
    modelVersions: ExportedModelVersion[];
};
export declare class ModelsService<ServiceParams extends Params = ModelsParams> extends KnexService<Models, ModelsData, ModelsParams, ModelsPatch> {
    options: ModelsServiceOptions;
    createQuery(params: KnexAdapterParams<ModelsQuery>): import("knex").Knex.QueryBuilder<any, any>;
    get app(): Application;
    simulate(data: ModelsSimulate, params?: ModelsParams): Promise<Record<string, any> | {
        nodes: Record<string, {
            series: number[] | {
                id: string;
                location: [number, number];
                state: number[];
            }[][] | number[][] | Record<string, number>[];
        }>;
        times: number[];
    }>;
    newDraft(data: ModelsNewDraft, params?: ServiceParams): Promise<{
        role?: number | null | undefined;
        algorithm?: import("simulation").AlgorithmType | null | undefined;
        parentId?: string | null | undefined;
        updatedAt?: string | null | undefined;
        deletedAt?: string | null | undefined;
        notes?: string | null | undefined;
        timeUnits?: "Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months" | null | undefined;
        timeStart?: number | null | undefined;
        timeLength?: number | null | undefined;
        timeStep?: number | null | undefined;
        isLatest?: boolean | null | undefined;
        globals?: string | null | undefined;
        customUnits?: {
            data: Record<string, string[]>;
        } | null | undefined;
        createdBy?: string | null | undefined;
        publishedBy?: string | null | undefined;
        publishedToUMPAt?: string | null | undefined;
        publishedToUMPApprovedAt?: string | null | undefined;
        id: string;
        createdAt: string;
        modelId: string;
        majorVersion: number;
        minorVersion: number;
        draftVersion: number;
        publishedAt: string;
    }>;
    publishMinor(data: ModelsPublish, params?: ServiceParams): Promise<{}>;
    publishMajor(data: ModelsPublish, params?: ServiceParams): Promise<{}>;
    cloneVersion(data: ModelsCloneVersion, params?: ServiceParams): Promise<{
        role?: number | null | undefined;
        algorithm?: import("simulation").AlgorithmType | null | undefined;
        parentId?: string | null | undefined;
        updatedAt?: string | null | undefined;
        deletedAt?: string | null | undefined;
        notes?: string | null | undefined;
        timeUnits?: "Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months" | null | undefined;
        timeStart?: number | null | undefined;
        timeLength?: number | null | undefined;
        timeStep?: number | null | undefined;
        isLatest?: boolean | null | undefined;
        globals?: string | null | undefined;
        customUnits?: {
            data: Record<string, string[]>;
        } | null | undefined;
        createdBy?: string | null | undefined;
        publishedBy?: string | null | undefined;
        publishedToUMPAt?: string | null | undefined;
        publishedToUMPApprovedAt?: string | null | undefined;
        id: string;
        createdAt: string;
        modelId: string;
        majorVersion: number;
        minorVersion: number;
        draftVersion: number;
        publishedAt: string;
    }>;
    exportModel(data: ModelsExport, params?: ServiceParams): Promise<ExportedModelPayload>;
    importModel(data: ModelsImport, params?: ServiceParams): Promise<{
        model: {
            role?: number | null | undefined;
            description?: string | null | undefined;
            updatedAt?: string | null | undefined;
            deletedAt?: string | null | undefined;
            createdBy?: string | undefined;
            latestPublishedVersionId?: string | null | undefined;
            latestDraftVersionId?: string | null | undefined;
            globalUuid?: string | null | undefined;
            forkedFromVersionId?: string | null | undefined;
            id: string;
            createdAt: string;
            internalName: string;
            publicName: string;
            currentMinorVersion: number;
            currentMajorVersion: number;
            currentDraftVersion: number;
        };
        modelVersion: {
            role?: number | null | undefined;
            algorithm?: import("simulation").AlgorithmType | null | undefined;
            parentId?: string | null | undefined;
            updatedAt?: string | null | undefined;
            deletedAt?: string | null | undefined;
            notes?: string | null | undefined;
            timeUnits?: "Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months" | null | undefined;
            timeStart?: number | null | undefined;
            timeLength?: number | null | undefined;
            timeStep?: number | null | undefined;
            isLatest?: boolean | null | undefined;
            globals?: string | null | undefined;
            customUnits?: {
                data: Record<string, string[]>;
            } | null | undefined;
            createdBy?: string | null | undefined;
            publishedBy?: string | null | undefined;
            publishedToUMPAt?: string | null | undefined;
            publishedToUMPApprovedAt?: string | null | undefined;
            id: string;
            createdAt: string;
            modelId: string;
            majorVersion: number;
            minorVersion: number;
            draftVersion: number;
            publishedAt: string;
        };
    }>;
    private cloneModelVersion;
    private getAuthorizedModel;
    private findAllModelVersions;
    private findAllNodes;
    private findAllEdges;
    private findAllScenarios;
    private findAllScenarioValues;
    private validateImportPayload;
}
export declare const getOptions: (app: Application) => ModelsServiceOptions;
