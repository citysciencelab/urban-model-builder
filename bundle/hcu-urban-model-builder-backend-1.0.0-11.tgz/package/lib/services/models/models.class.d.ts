import type { Params } from '@feathersjs/feathers';
import { KnexService } from '@feathersjs/knex';
import type { KnexAdapterParams, KnexAdapterOptions } from '@feathersjs/knex';
import type { Application } from '../../declarations.js';
import { type Models, type ModelsCloneVersion, type ModelsData, type ModelsNewDraft, type ModelsPatch, type ModelsPublish, type ModelsQuery, type ModelsSimulate } from './models.schema.js';
export type { Models, ModelsData, ModelsPatch, ModelsQuery };
export interface ModelsParams extends KnexAdapterParams<ModelsQuery> {
    serializeForUMP?: boolean;
}
export interface ModelsServiceOptions extends KnexAdapterOptions {
    app: Application;
}
export declare class ModelsService<ServiceParams extends Params = ModelsParams> extends KnexService<Models, ModelsData, ModelsParams, ModelsPatch> {
    options: ModelsServiceOptions;
    createQuery(params: KnexAdapterParams<ModelsQuery>): import("knex").Knex.QueryBuilder<any, any>;
    get app(): Application;
    simulate(data: ModelsSimulate, params?: ModelsParams): Promise<Record<string, any> | {
        nodes: Record<string, {
            series: number[] | {
                id: string;
                location: [number, number];
                state: number[];
            }[][] | number[][] | Record<string, number>[];
        }>;
        times: number[];
    }>;
    newDraft(data: ModelsNewDraft, params?: ServiceParams): Promise<{
        role?: number | null | undefined;
        algorithm?: import("simulation").AlgorithmType | null | undefined;
        parentId?: string | null | undefined;
        notes?: string | null | undefined;
        timeUnits?: "Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months" | null | undefined;
        timeStart?: number | null | undefined;
        timeLength?: number | null | undefined;
        timeStep?: number | null | undefined;
        isLatest?: boolean | null | undefined;
        globals?: string | null | undefined;
        customUnits?: {
            data: Record<string, number[]>;
        } | null | undefined;
        createdBy?: string | null | undefined;
        publishedBy?: string | null | undefined;
        updatedAt?: string | null | undefined;
        deletedAt?: string | null | undefined;
        publishedToUMPAt?: string | null | undefined;
        publishedToUMPApprovedAt?: string | null | undefined;
        id: string;
        modelId: string;
        majorVersion: number;
        minorVersion: number;
        draftVersion: number;
        publishedAt: string;
        createdAt: string;
    }>;
    publishMinor(data: ModelsPublish, params?: ServiceParams): Promise<{}>;
    publishMajor(data: ModelsPublish, params?: ServiceParams): Promise<{}>;
    cloneVersion(data: ModelsCloneVersion, params?: ServiceParams): Promise<{
        role?: number | null | undefined;
        algorithm?: import("simulation").AlgorithmType | null | undefined;
        parentId?: string | null | undefined;
        notes?: string | null | undefined;
        timeUnits?: "Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months" | null | undefined;
        timeStart?: number | null | undefined;
        timeLength?: number | null | undefined;
        timeStep?: number | null | undefined;
        isLatest?: boolean | null | undefined;
        globals?: string | null | undefined;
        customUnits?: {
            data: Record<string, number[]>;
        } | null | undefined;
        createdBy?: string | null | undefined;
        publishedBy?: string | null | undefined;
        updatedAt?: string | null | undefined;
        deletedAt?: string | null | undefined;
        publishedToUMPAt?: string | null | undefined;
        publishedToUMPApprovedAt?: string | null | undefined;
        id: string;
        modelId: string;
        majorVersion: number;
        minorVersion: number;
        draftVersion: number;
        publishedAt: string;
        createdAt: string;
    }>;
    private cloneModelVersion;
}
export declare const getOptions: (app: Application) => ModelsServiceOptions;
