import type { Id, Params } from '@feathersjs/feathers';
import { KnexService } from '@feathersjs/knex';
import type { KnexAdapterParams, KnexAdapterOptions } from '@feathersjs/knex';
import type { Application } from '../../declarations.js';
import type { ModelsVersionsExport, ModelsVersionsImport, ModelsVersions, ModelsVersionsData, ModelsVersionsJoinChannelData, ModelsVersionsLeaveChannelData, ModelsVersionsPatch, ModelsVersionsQuery } from './models-versions.schema.js';
export type { ModelsVersions, ModelsVersionsData, ModelsVersionsPatch, ModelsVersionsQuery };
export interface ModelsVersionsParams extends KnexAdapterParams<ModelsVersionsQuery> {
}
export interface ModelsVersionsServiceOptions extends KnexAdapterOptions {
    app: Application;
}
export declare class ModelsVersionsService<ServiceParams extends Params = ModelsVersionsParams> extends KnexService<ModelsVersions, ModelsVersionsData, ModelsVersionsParams, ModelsVersionsPatch> {
    app: Application;
    constructor(options: ModelsVersionsServiceOptions);
    createQuery(params: KnexAdapterParams<ModelsVersionsQuery>): import("knex").Knex.QueryBuilder<any, any>;
    _get(id: Id, params?: ModelsVersionsParams | undefined): Promise<{
        role?: number | null | undefined;
        algorithm?: import("simulation").AlgorithmType | null | undefined;
        parentId?: string | null | undefined;
        updatedAt?: string | null | undefined;
        deletedAt?: string | null | undefined;
        notes?: string | null | undefined;
        timeUnits?: "Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months" | null | undefined;
        timeStart?: number | null | undefined;
        timeLength?: number | null | undefined;
        timeStep?: number | null | undefined;
        isLatest?: boolean | null | undefined;
        globals?: string | null | undefined;
        customUnits?: {
            data: Record<string, string[]>;
        } | null | undefined;
        createdBy?: string | null | undefined;
        publishedBy?: string | null | undefined;
        publishedToUMPAt?: string | null | undefined;
        publishedToUMPApprovedAt?: string | null | undefined;
        id: string;
        modelId: string;
        createdAt: string;
        majorVersion: number;
        minorVersion: number;
        draftVersion: number;
        publishedAt: string;
    }>;
    joinChannel(data: ModelsVersionsJoinChannelData, params?: ModelsVersionsParams): Promise<{
        id: string;
    }>;
    leaveChannel(data: ModelsVersionsLeaveChannelData, params?: ModelsVersionsParams): Promise<{
        id: string;
    }>;
    exportVersion(data: ModelsVersionsExport): Promise<{
        schemaVersion: number;
        exportedAt: string;
        modelVersion: {
            role?: number | null | undefined;
            algorithm?: import("simulation").AlgorithmType | null | undefined;
            parentId?: string | null | undefined;
            updatedAt?: string | null | undefined;
            deletedAt?: string | null | undefined;
            notes?: string | null | undefined;
            timeUnits?: "Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months" | null | undefined;
            timeStart?: number | null | undefined;
            timeLength?: number | null | undefined;
            timeStep?: number | null | undefined;
            isLatest?: boolean | null | undefined;
            globals?: string | null | undefined;
            customUnits?: {
                data: Record<string, string[]>;
            } | null | undefined;
            createdBy?: string | null | undefined;
            publishedBy?: string | null | undefined;
            publishedToUMPAt?: string | null | undefined;
            publishedToUMPApprovedAt?: string | null | undefined;
            id: string;
            modelId: string;
            createdAt: string;
            majorVersion: number;
            minorVersion: number;
            draftVersion: number;
            publishedAt: string;
        };
        nodes: {
            name?: string | null | undefined;
            height?: number | null | undefined;
            width?: number | null | undefined;
            description?: string | null | undefined;
            parentId?: string | null | undefined;
            parameterMin?: number | null | undefined;
            parameterMax?: number | null | undefined;
            parameterStep?: number | null | undefined;
            parameterType?: import("../../client.js").ParameterTypes | null | undefined;
            parameterOptions?: {
                data: {
                    value: number;
                    label: string;
                }[];
            } | null | undefined;
            ghostParentId?: string | null | undefined;
            type: import("../nodes/nodes.shared.js").NodeType;
            data: {
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: import("simulation/types").StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: import("simulation/types").TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: import("simulation/types").TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: import("simulation/types").PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: import("simulation/types").NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            };
            id: string;
            position: {
                x: number;
                y: number;
            };
            modelsVersionsId: string;
            isParameter: boolean;
            isOutputParameter: boolean;
        }[];
        edges: {
            points?: {
                data: {
                    id: string;
                    x: number;
                    y: number;
                }[];
            } | null | undefined;
            type: import("../edges/edges.shared.js").EdgeType;
            id: string;
            modelsVersionsId: string;
            sourceId: string;
            targetId: string;
            sourceHandle: string;
            targetHandle: string;
        }[];
        scenarios: {
            scenario: {
                updatedAt?: string | null | undefined;
                deletedAt?: string | null | undefined;
                name: string;
                id: string;
                modelsVersionsId: string;
                createdAt: string;
                isDefault: boolean;
            };
            scenarioValues: {
                updatedAt?: string | null | undefined;
                deletedAt?: string | null | undefined;
                id: string;
                value: number;
                nodesId: string;
                scenariosId: string;
                createdAt: string;
            }[];
        }[];
    }>;
    importVersion(data: ModelsVersionsImport): Promise<{
        role?: number | null | undefined;
        algorithm?: import("simulation").AlgorithmType | null | undefined;
        parentId?: string | null | undefined;
        updatedAt?: string | null | undefined;
        deletedAt?: string | null | undefined;
        notes?: string | null | undefined;
        timeUnits?: "Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months" | null | undefined;
        timeStart?: number | null | undefined;
        timeLength?: number | null | undefined;
        timeStep?: number | null | undefined;
        isLatest?: boolean | null | undefined;
        globals?: string | null | undefined;
        customUnits?: {
            data: Record<string, string[]>;
        } | null | undefined;
        createdBy?: string | null | undefined;
        publishedBy?: string | null | undefined;
        publishedToUMPAt?: string | null | undefined;
        publishedToUMPApprovedAt?: string | null | undefined;
        id: string;
        modelId: string;
        createdAt: string;
        majorVersion: number;
        minorVersion: number;
        draftVersion: number;
        publishedAt: string;
    }>;
    private findAllNodes;
    private findAllEdges;
    private findAllScenarios;
    private findAllScenarioValues;
    private removeAllScenarios;
    private removeAllNodes;
    private validateImportPayload;
}
export declare const getOptions: (app: Application) => ModelsVersionsServiceOptions;
