import type { Id, Params } from '@feathersjs/feathers';
import { KnexService } from '@feathersjs/knex';
import type { KnexAdapterParams, KnexAdapterOptions } from '@feathersjs/knex';
import type { Application } from '../../declarations.js';
import type { ModelsVersions, ModelsVersionsData, ModelsVersionsJoinChannelData, ModelsVersionsLeaveChannelData, ModelsVersionsPatch, ModelsVersionsQuery } from './models-versions.schema.js';
export type { ModelsVersions, ModelsVersionsData, ModelsVersionsPatch, ModelsVersionsQuery };
export interface ModelsVersionsParams extends KnexAdapterParams<ModelsVersionsQuery> {
}
export interface ModelsVersionsServiceOptions extends KnexAdapterOptions {
    app: Application;
}
export declare class ModelsVersionsService<ServiceParams extends Params = ModelsVersionsParams> extends KnexService<ModelsVersions, ModelsVersionsData, ModelsVersionsParams, ModelsVersionsPatch> {
    app: Application;
    constructor(options: ModelsVersionsServiceOptions);
    createQuery(params: KnexAdapterParams<ModelsVersionsQuery>): import("knex").Knex.QueryBuilder<any, any>;
    _get(id: Id, params?: ModelsVersionsParams | undefined): Promise<{
        role?: number | null | undefined;
        algorithm?: import("simulation").AlgorithmType | null | undefined;
        parentId?: string | null | undefined;
        notes?: string | null | undefined;
        timeUnits?: "Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months" | null | undefined;
        timeStart?: number | null | undefined;
        timeLength?: number | null | undefined;
        timeStep?: number | null | undefined;
        isLatest?: boolean | null | undefined;
        globals?: string | null | undefined;
        customUnits?: {
            data: Record<string, number[]>;
        } | null | undefined;
        createdBy?: string | null | undefined;
        publishedBy?: string | null | undefined;
        updatedAt?: string | null | undefined;
        deletedAt?: string | null | undefined;
        publishedToUMPAt?: string | null | undefined;
        publishedToUMPApprovedAt?: string | null | undefined;
        id: string;
        modelId: string;
        majorVersion: number;
        minorVersion: number;
        draftVersion: number;
        publishedAt: string;
        createdAt: string;
    }>;
    joinChannel(data: ModelsVersionsJoinChannelData, params?: ModelsVersionsParams): Promise<{
        id: string;
    }>;
    leaveChannel(data: ModelsVersionsLeaveChannelData, params?: ModelsVersionsParams): Promise<{
        id: string;
    }>;
}
export declare const getOptions: (app: Application) => ModelsVersionsServiceOptions;
