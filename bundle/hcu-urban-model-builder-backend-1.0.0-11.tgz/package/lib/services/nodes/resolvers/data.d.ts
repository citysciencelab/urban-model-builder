import { Nodes } from '../nodes.schema.js';
export declare const nodeDataResolver: (inputData: Nodes["data"] | undefined, node: Nodes) => ({
    value?: string | undefined;
    units?: string | undefined;
    constraints?: Partial<{
        max?: number | undefined;
        min?: number | undefined;
    }> | undefined;
} & {
    type?: import("simulation/types").StockTypeType | undefined;
    units?: string | undefined;
    constraints?: Partial<{
        max?: number | undefined;
        min?: number | undefined;
    }> | undefined;
    initial?: string | undefined;
    delay?: string | undefined;
    nonNegative?: boolean | undefined;
} & {
    direction?: "left" | "top" | "bottom" | "right" | undefined;
    units?: string | undefined;
    constraints?: Partial<{
        max?: number | undefined;
        min?: number | undefined;
    }> | undefined;
    nonNegative?: boolean | undefined;
    rate?: string | undefined;
} & {
    values?: {
        x: number;
        y: number;
    }[] | undefined;
    units?: string | undefined;
    constraints?: Partial<{
        max?: number | undefined;
        min?: number | undefined;
    }> | undefined;
    interpolation?: "Linear" | "Discrete" | undefined;
} & {
    startActive?: string | undefined;
    residency?: string | undefined;
} & {
    repeat?: boolean | undefined;
    value?: string | undefined;
    action?: string | undefined;
    recalculate?: boolean | undefined;
    trigger?: import("simulation/types").TriggerType | undefined;
} & {
    repeat?: boolean | undefined;
    direction?: "left" | "top" | "bottom" | "right" | undefined;
    value?: string | undefined;
    constraints?: Partial<{
        max?: number | undefined;
        min?: number | undefined;
    }> | undefined;
    recalculate?: boolean | undefined;
    trigger?: import("simulation/types").TriggerType | undefined;
} & {
    populationSize?: number | undefined;
    geoUnits?: string | undefined;
    geoWidth?: string | undefined;
    geoHeight?: string | undefined;
    geoWrapAround?: boolean | undefined;
    geoPlacementType?: import("simulation/types").PlacementType | undefined;
    geoPlacementFunction?: string | undefined;
    networkType?: import("simulation/types").NetworkType | undefined;
    networkFunction?: string | undefined;
} & {
    query?: {
        offset?: number | undefined;
        properties?: string[] | undefined;
        limit?: number | undefined;
        skipGeometry?: boolean | undefined;
        propertyFilters?: Record<string, {
            operator?: string | undefined;
            value: string;
        }> | undefined;
    } | undefined;
    apiId?: string | undefined;
    collectionId?: string | undefined;
    dataTransform?: {
        keyProperty?: string | undefined;
        valueProperties?: string[] | undefined;
    } | undefined;
} & {
    modelId?: string | undefined;
    modelVersionId?: string | undefined;
    importedFolderId?: string | undefined;
}) | {
    value?: string | undefined;
    units?: string | undefined;
    constraints?: Partial<{
        max?: number | undefined;
        min?: number | undefined;
    }> | undefined;
    type?: import("simulation/types").StockTypeType | undefined;
    initial?: string | undefined;
    delay?: string | undefined;
    nonNegative?: boolean | undefined;
    direction?: "left" | "top" | "bottom" | "right" | undefined;
    rate?: string | undefined;
    values?: {
        x: number;
        y: number;
    }[] | undefined;
    interpolation?: "Linear" | "Discrete" | undefined;
    startActive?: string | undefined;
    residency?: string | undefined;
    repeat?: boolean | undefined;
    action?: string | undefined;
    recalculate?: boolean | undefined;
    trigger?: import("simulation/types").TriggerType | undefined;
    populationSize?: number | undefined;
    geoUnits?: string | undefined;
    geoWidth?: string | undefined;
    geoHeight?: string | undefined;
    geoWrapAround?: boolean | undefined;
    geoPlacementType?: import("simulation/types").PlacementType | undefined;
    geoPlacementFunction?: string | undefined;
    networkType?: import("simulation/types").NetworkType | undefined;
    networkFunction?: string | undefined;
    query: {
        offset?: number | undefined;
        properties?: string[] | undefined;
        limit?: number | undefined;
        skipGeometry?: boolean | undefined;
        propertyFilters?: Record<string, {
            operator?: string | undefined;
            value: string;
        }> | undefined;
    } | {
        limit: number;
        offset: number;
        properties: never[];
        skipGeometry: true;
    };
    apiId?: string | undefined;
    collectionId?: string | undefined;
    dataTransform?: {
        keyProperty?: string | undefined;
        valueProperties?: string[] | undefined;
    } | undefined;
    modelId?: string | undefined;
    modelVersionId?: string | undefined;
    importedFolderId?: string | undefined;
};
