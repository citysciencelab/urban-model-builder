import type { Static, TObject, TSchema } from '@feathersjs/typebox';
import { NetworkType, PlacementType, StockTypeType, TriggerType } from 'simulation/types';
import type { HookContext } from '../../declarations.js';
import type { NodesService } from './nodes.class.js';
import { NodeType } from './nodes.shared.js';
import { ParameterTypes } from '../../client.js';
export declare const variableNodeSchema: TObject<{
    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    }>>>;
    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
}>;
export declare const stockNodeSchema: TObject<{
    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    }>>>;
    initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
    delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
}>;
export declare const flowNodeSchema: TObject<{
    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    }>>>;
    rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
}>;
export declare const converterNodeSchema: TObject<{
    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    }>>>;
    values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
        x: import("@sinclair/typebox").TNumber;
        y: import("@sinclair/typebox").TNumber;
    }>>>;
    interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
}>;
export declare const stateNodeSchema: TObject<{
    startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
}>;
export declare const actionNodeSchema: TObject<{
    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
    action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
}>;
export declare const transitionNodeSchema: TObject<{
    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    }>>>;
}>;
export declare const populationNodeSchema: TObject<{
    populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
    geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
    networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
}>;
export declare const ogcFeatureNodeSchema: TObject<{
    apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    query: import("@sinclair/typebox").TOptional<TObject<{
        limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
        propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
            value: import("@sinclair/typebox").TString<string>;
            operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>>>;
    }>>;
    dataTransform: import("@sinclair/typebox").TOptional<TObject<{
        keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
    }>>;
}>;
export declare const subModelNodeSchema: TObject<{
    modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
    modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
    importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
}>;
export declare const nodesSchema: TObject<{
    id: import("@sinclair/typebox").TString<"uuid">;
    modelsVersionsId: import("@sinclair/typebox").TString<"uuid">;
    type: import("@sinclair/typebox").TEnum<typeof NodeType>;
    name: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    description: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    data: import("@sinclair/typebox").TIntersect<[TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
        delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>>>;
        interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
    }>, TObject<{
        startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
        action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
        direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
    }>, TObject<{
        populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
        geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
        networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        query: import("@sinclair/typebox").TOptional<TObject<{
            limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                value: import("@sinclair/typebox").TString<string>;
                operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>>>;
        }>>;
        dataTransform: import("@sinclair/typebox").TOptional<TObject<{
            keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
        }>>;
    }>, TObject<{
        modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
    }>]>;
    position: TObject<{
        x: import("@sinclair/typebox").TNumber;
        y: import("@sinclair/typebox").TNumber;
    }>;
    height: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    width: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
    isParameter: import("@sinclair/typebox").TBoolean;
    parameterMin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parameterMax: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parameterStep: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parameterType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<ParameterTypes>[]>]>>;
    parameterOptions: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, TObject<{
        data: import("@sinclair/typebox").TArray<TObject<{
            value: import("@sinclair/typebox").TNumber;
            label: import("@sinclair/typebox").TString<string>;
        }>>;
    }>]>>;
    isOutputParameter: import("@sinclair/typebox").TBoolean;
    ghostParentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
}>;
export type Nodes = Static<typeof nodesSchema>;
export declare const nodesValidator: import("@feathersjs/schema").Validator<any, any>;
export declare const nodesResolver: import("@feathersjs/schema").Resolver<{
    name?: string | null | undefined;
    height?: number | null | undefined;
    width?: number | null | undefined;
    description?: string | null | undefined;
    parentId?: string | null | undefined;
    parameterMin?: number | null | undefined;
    parameterMax?: number | null | undefined;
    parameterStep?: number | null | undefined;
    parameterType?: ParameterTypes | null | undefined;
    parameterOptions?: {
        data: {
            value: number;
            label: string;
        }[];
    } | null | undefined;
    ghostParentId?: string | null | undefined;
    type: NodeType;
    data: {
        value?: string | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
    } & {
        type?: StockTypeType | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        initial?: string | undefined;
        delay?: string | undefined;
        nonNegative?: boolean | undefined;
    } & {
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        nonNegative?: boolean | undefined;
        rate?: string | undefined;
    } & {
        values?: {
            x: number;
            y: number;
        }[] | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        interpolation?: "Linear" | "Discrete" | undefined;
    } & {
        startActive?: string | undefined;
        residency?: string | undefined;
    } & {
        repeat?: boolean | undefined;
        value?: string | undefined;
        action?: string | undefined;
        recalculate?: boolean | undefined;
        trigger?: TriggerType | undefined;
    } & {
        repeat?: boolean | undefined;
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        value?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        recalculate?: boolean | undefined;
        trigger?: TriggerType | undefined;
    } & {
        populationSize?: number | undefined;
        geoUnits?: string | undefined;
        geoWidth?: string | undefined;
        geoHeight?: string | undefined;
        geoWrapAround?: boolean | undefined;
        geoPlacementType?: PlacementType | undefined;
        geoPlacementFunction?: string | undefined;
        networkType?: NetworkType | undefined;
        networkFunction?: string | undefined;
    } & {
        query?: {
            offset?: number | undefined;
            properties?: string[] | undefined;
            limit?: number | undefined;
            skipGeometry?: boolean | undefined;
            propertyFilters?: Record<string, {
                operator?: string | undefined;
                value: string;
            }> | undefined;
        } | undefined;
        apiId?: string | undefined;
        collectionId?: string | undefined;
        dataTransform?: {
            keyProperty?: string | undefined;
            valueProperties?: string[] | undefined;
        } | undefined;
    } & {
        modelId?: string | undefined;
        modelVersionId?: string | undefined;
        importedFolderId?: string | undefined;
    };
    id: string;
    position: {
        x: number;
        y: number;
    };
    modelsVersionsId: string;
    isParameter: boolean;
    isOutputParameter: boolean;
}, HookContext<NodesService<import("./nodes.class.js").NodesParams>>>;
export declare const nodesExternalResolver: import("@feathersjs/schema").Resolver<{
    name?: string | null | undefined;
    height?: number | null | undefined;
    width?: number | null | undefined;
    description?: string | null | undefined;
    parentId?: string | null | undefined;
    parameterMin?: number | null | undefined;
    parameterMax?: number | null | undefined;
    parameterStep?: number | null | undefined;
    parameterType?: ParameterTypes | null | undefined;
    parameterOptions?: {
        data: {
            value: number;
            label: string;
        }[];
    } | null | undefined;
    ghostParentId?: string | null | undefined;
    type: NodeType;
    data: {
        value?: string | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
    } & {
        type?: StockTypeType | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        initial?: string | undefined;
        delay?: string | undefined;
        nonNegative?: boolean | undefined;
    } & {
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        nonNegative?: boolean | undefined;
        rate?: string | undefined;
    } & {
        values?: {
            x: number;
            y: number;
        }[] | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        interpolation?: "Linear" | "Discrete" | undefined;
    } & {
        startActive?: string | undefined;
        residency?: string | undefined;
    } & {
        repeat?: boolean | undefined;
        value?: string | undefined;
        action?: string | undefined;
        recalculate?: boolean | undefined;
        trigger?: TriggerType | undefined;
    } & {
        repeat?: boolean | undefined;
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        value?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        recalculate?: boolean | undefined;
        trigger?: TriggerType | undefined;
    } & {
        populationSize?: number | undefined;
        geoUnits?: string | undefined;
        geoWidth?: string | undefined;
        geoHeight?: string | undefined;
        geoWrapAround?: boolean | undefined;
        geoPlacementType?: PlacementType | undefined;
        geoPlacementFunction?: string | undefined;
        networkType?: NetworkType | undefined;
        networkFunction?: string | undefined;
    } & {
        query?: {
            offset?: number | undefined;
            properties?: string[] | undefined;
            limit?: number | undefined;
            skipGeometry?: boolean | undefined;
            propertyFilters?: Record<string, {
                operator?: string | undefined;
                value: string;
            }> | undefined;
        } | undefined;
        apiId?: string | undefined;
        collectionId?: string | undefined;
        dataTransform?: {
            keyProperty?: string | undefined;
            valueProperties?: string[] | undefined;
        } | undefined;
    } & {
        modelId?: string | undefined;
        modelVersionId?: string | undefined;
        importedFolderId?: string | undefined;
    };
    id: string;
    position: {
        x: number;
        y: number;
    };
    modelsVersionsId: string;
    isParameter: boolean;
    isOutputParameter: boolean;
}, HookContext<NodesService<import("./nodes.class.js").NodesParams>>>;
export declare const nodesDataSchema: import("@sinclair/typebox").TPick<TObject<{
    id: import("@sinclair/typebox").TString<"uuid">;
    modelsVersionsId: import("@sinclair/typebox").TString<"uuid">;
    type: import("@sinclair/typebox").TEnum<typeof NodeType>;
    name: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    description: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    data: import("@sinclair/typebox").TIntersect<[TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
        delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>>>;
        interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
    }>, TObject<{
        startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
        action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
        direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
    }>, TObject<{
        populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
        geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
        networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        query: import("@sinclair/typebox").TOptional<TObject<{
            limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                value: import("@sinclair/typebox").TString<string>;
                operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>>>;
        }>>;
        dataTransform: import("@sinclair/typebox").TOptional<TObject<{
            keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
        }>>;
    }>, TObject<{
        modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
    }>]>;
    position: TObject<{
        x: import("@sinclair/typebox").TNumber;
        y: import("@sinclair/typebox").TNumber;
    }>;
    height: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    width: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
    isParameter: import("@sinclair/typebox").TBoolean;
    parameterMin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parameterMax: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parameterStep: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parameterType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<ParameterTypes>[]>]>>;
    parameterOptions: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, TObject<{
        data: import("@sinclair/typebox").TArray<TObject<{
            value: import("@sinclair/typebox").TNumber;
            label: import("@sinclair/typebox").TString<string>;
        }>>;
    }>]>>;
    isOutputParameter: import("@sinclair/typebox").TBoolean;
    ghostParentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
}>, ["modelsVersionsId", "type", "name", "description", "position", "data", "height", "width", "parentId", "isParameter", "isOutputParameter", "parameterType", "parameterMin", "parameterMax", "parameterStep", "parameterOptions", "isOutputParameter", "ghostParentId"]>;
export type NodesData = Static<typeof nodesDataSchema>;
export declare const nodesDataValidator: import("@feathersjs/schema").Validator<any, any>;
export declare const nodesDataResolver: import("@feathersjs/schema").Resolver<{
    name?: string | null | undefined;
    height?: number | null | undefined;
    width?: number | null | undefined;
    description?: string | null | undefined;
    parentId?: string | null | undefined;
    parameterMin?: number | null | undefined;
    parameterMax?: number | null | undefined;
    parameterStep?: number | null | undefined;
    parameterType?: ParameterTypes | null | undefined;
    parameterOptions?: {
        data: {
            value: number;
            label: string;
        }[];
    } | null | undefined;
    ghostParentId?: string | null | undefined;
    type: NodeType;
    data: {
        value?: string | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
    } & {
        type?: StockTypeType | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        initial?: string | undefined;
        delay?: string | undefined;
        nonNegative?: boolean | undefined;
    } & {
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        nonNegative?: boolean | undefined;
        rate?: string | undefined;
    } & {
        values?: {
            x: number;
            y: number;
        }[] | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        interpolation?: "Linear" | "Discrete" | undefined;
    } & {
        startActive?: string | undefined;
        residency?: string | undefined;
    } & {
        repeat?: boolean | undefined;
        value?: string | undefined;
        action?: string | undefined;
        recalculate?: boolean | undefined;
        trigger?: TriggerType | undefined;
    } & {
        repeat?: boolean | undefined;
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        value?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        recalculate?: boolean | undefined;
        trigger?: TriggerType | undefined;
    } & {
        populationSize?: number | undefined;
        geoUnits?: string | undefined;
        geoWidth?: string | undefined;
        geoHeight?: string | undefined;
        geoWrapAround?: boolean | undefined;
        geoPlacementType?: PlacementType | undefined;
        geoPlacementFunction?: string | undefined;
        networkType?: NetworkType | undefined;
        networkFunction?: string | undefined;
    } & {
        query?: {
            offset?: number | undefined;
            properties?: string[] | undefined;
            limit?: number | undefined;
            skipGeometry?: boolean | undefined;
            propertyFilters?: Record<string, {
                operator?: string | undefined;
                value: string;
            }> | undefined;
        } | undefined;
        apiId?: string | undefined;
        collectionId?: string | undefined;
        dataTransform?: {
            keyProperty?: string | undefined;
            valueProperties?: string[] | undefined;
        } | undefined;
    } & {
        modelId?: string | undefined;
        modelVersionId?: string | undefined;
        importedFolderId?: string | undefined;
    };
    id: string;
    position: {
        x: number;
        y: number;
    };
    modelsVersionsId: string;
    isParameter: boolean;
    isOutputParameter: boolean;
}, HookContext<NodesService<import("./nodes.class.js").NodesParams>>>;
export declare const nodesPatchSchema: import("@sinclair/typebox").TPartial<TObject<{
    id: import("@sinclair/typebox").TString<"uuid">;
    modelsVersionsId: import("@sinclair/typebox").TString<"uuid">;
    type: import("@sinclair/typebox").TEnum<typeof NodeType>;
    name: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    description: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    data: import("@sinclair/typebox").TIntersect<[TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
        delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>>>;
        interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
    }>, TObject<{
        startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
        action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
        direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
    }>, TObject<{
        populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
        geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
        networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        query: import("@sinclair/typebox").TOptional<TObject<{
            limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                value: import("@sinclair/typebox").TString<string>;
                operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>>>;
        }>>;
        dataTransform: import("@sinclair/typebox").TOptional<TObject<{
            keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
        }>>;
    }>, TObject<{
        modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
    }>]>;
    position: TObject<{
        x: import("@sinclair/typebox").TNumber;
        y: import("@sinclair/typebox").TNumber;
    }>;
    height: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    width: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
    isParameter: import("@sinclair/typebox").TBoolean;
    parameterMin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parameterMax: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parameterStep: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parameterType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<ParameterTypes>[]>]>>;
    parameterOptions: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, TObject<{
        data: import("@sinclair/typebox").TArray<TObject<{
            value: import("@sinclair/typebox").TNumber;
            label: import("@sinclair/typebox").TString<string>;
        }>>;
    }>]>>;
    isOutputParameter: import("@sinclair/typebox").TBoolean;
    ghostParentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
}>>;
export type NodesPatch = Static<typeof nodesPatchSchema>;
export declare const nodesPatchValidator: import("@feathersjs/schema").Validator<any, any>;
export declare const nodesPatchResolver: import("@feathersjs/schema").Resolver<{
    name?: string | null | undefined;
    height?: number | null | undefined;
    width?: number | null | undefined;
    description?: string | null | undefined;
    parentId?: string | null | undefined;
    parameterMin?: number | null | undefined;
    parameterMax?: number | null | undefined;
    parameterStep?: number | null | undefined;
    parameterType?: ParameterTypes | null | undefined;
    parameterOptions?: {
        data: {
            value: number;
            label: string;
        }[];
    } | null | undefined;
    ghostParentId?: string | null | undefined;
    type: NodeType;
    data: {
        value?: string | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
    } & {
        type?: StockTypeType | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        initial?: string | undefined;
        delay?: string | undefined;
        nonNegative?: boolean | undefined;
    } & {
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        nonNegative?: boolean | undefined;
        rate?: string | undefined;
    } & {
        values?: {
            x: number;
            y: number;
        }[] | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        interpolation?: "Linear" | "Discrete" | undefined;
    } & {
        startActive?: string | undefined;
        residency?: string | undefined;
    } & {
        repeat?: boolean | undefined;
        value?: string | undefined;
        action?: string | undefined;
        recalculate?: boolean | undefined;
        trigger?: TriggerType | undefined;
    } & {
        repeat?: boolean | undefined;
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        value?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        recalculate?: boolean | undefined;
        trigger?: TriggerType | undefined;
    } & {
        populationSize?: number | undefined;
        geoUnits?: string | undefined;
        geoWidth?: string | undefined;
        geoHeight?: string | undefined;
        geoWrapAround?: boolean | undefined;
        geoPlacementType?: PlacementType | undefined;
        geoPlacementFunction?: string | undefined;
        networkType?: NetworkType | undefined;
        networkFunction?: string | undefined;
    } & {
        query?: {
            offset?: number | undefined;
            properties?: string[] | undefined;
            limit?: number | undefined;
            skipGeometry?: boolean | undefined;
            propertyFilters?: Record<string, {
                operator?: string | undefined;
                value: string;
            }> | undefined;
        } | undefined;
        apiId?: string | undefined;
        collectionId?: string | undefined;
        dataTransform?: {
            keyProperty?: string | undefined;
            valueProperties?: string[] | undefined;
        } | undefined;
    } & {
        modelId?: string | undefined;
        modelVersionId?: string | undefined;
        importedFolderId?: string | undefined;
    };
    id: string;
    position: {
        x: number;
        y: number;
    };
    modelsVersionsId: string;
    isParameter: boolean;
    isOutputParameter: boolean;
}, HookContext<NodesService<import("./nodes.class.js").NodesParams>>>;
export declare const nodesQueryProperties: import("@sinclair/typebox").TPick<TObject<{
    id: import("@sinclair/typebox").TString<"uuid">;
    modelsVersionsId: import("@sinclair/typebox").TString<"uuid">;
    type: import("@sinclair/typebox").TEnum<typeof NodeType>;
    name: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    description: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    data: import("@sinclair/typebox").TIntersect<[TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
        delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>>>;
        interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
    }>, TObject<{
        startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
        action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
        direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
    }>, TObject<{
        populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
        geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
        networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        query: import("@sinclair/typebox").TOptional<TObject<{
            limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                value: import("@sinclair/typebox").TString<string>;
                operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>>>;
        }>>;
        dataTransform: import("@sinclair/typebox").TOptional<TObject<{
            keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
        }>>;
    }>, TObject<{
        modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
    }>]>;
    position: TObject<{
        x: import("@sinclair/typebox").TNumber;
        y: import("@sinclair/typebox").TNumber;
    }>;
    height: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    width: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
    isParameter: import("@sinclair/typebox").TBoolean;
    parameterMin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parameterMax: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parameterStep: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    parameterType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<ParameterTypes>[]>]>>;
    parameterOptions: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, TObject<{
        data: import("@sinclair/typebox").TArray<TObject<{
            value: import("@sinclair/typebox").TNumber;
            label: import("@sinclair/typebox").TString<string>;
        }>>;
    }>]>>;
    isOutputParameter: import("@sinclair/typebox").TBoolean;
    ghostParentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
}>, ["id", "modelsVersionsId", "type", "name", "position", "data", "height", "width", "parentId", "ghostParentId", "isParameter", "isOutputParameter"]>;
export declare const nodesQuerySchema: import("@sinclair/typebox").TIntersect<[import("@sinclair/typebox").TIntersect<[import("@sinclair/typebox").TPartial<TObject<{
    $limit: import("@sinclair/typebox").TNumber;
    $skip: import("@sinclair/typebox").TNumber;
    $sort: TObject<{
        name: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
        type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
        data: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
        id: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
        height: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
        width: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
        position: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
        parentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
        modelsVersionsId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
        isParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
        isOutputParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
        ghostParentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
    }>;
    $select: import("@sinclair/typebox").TUnsafe<("name" | "type" | "data" | "id" | "height" | "width" | "position" | "parentId" | "modelsVersionsId" | "isParameter" | "isOutputParameter" | "ghostParentId")[]>;
    $and: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<TObject<{
        name: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
            $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
            $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
            $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
            $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
            $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>>;
            $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TEnum<typeof NodeType>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TEnum<typeof NodeType>;
            $gte: import("@sinclair/typebox").TEnum<typeof NodeType>;
            $lt: import("@sinclair/typebox").TEnum<typeof NodeType>;
            $lte: import("@sinclair/typebox").TEnum<typeof NodeType>;
            $ne: import("@sinclair/typebox").TEnum<typeof NodeType>;
            $in: import("@sinclair/typebox").TEnum<typeof NodeType> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TEnum<typeof NodeType>>;
            $nin: import("@sinclair/typebox").TEnum<typeof NodeType> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TEnum<typeof NodeType>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        data: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TIntersect<[TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
            delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>>;
            interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
        }>, TObject<{
            startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
        }>, TObject<{
            populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
            geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
            networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            query: import("@sinclair/typebox").TOptional<TObject<{
                limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                    value: import("@sinclair/typebox").TString<string>;
                    operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>>>;
            }>>;
            dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            }>>;
        }>, TObject<{
            modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        }>]>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>;
            $gte: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>;
            $lt: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>;
            $lte: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>;
            $ne: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>;
            $in: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>>;
            $nin: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        id: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<"uuid">, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TString<"uuid">;
            $gte: import("@sinclair/typebox").TString<"uuid">;
            $lt: import("@sinclair/typebox").TString<"uuid">;
            $lte: import("@sinclair/typebox").TString<"uuid">;
            $ne: import("@sinclair/typebox").TString<"uuid">;
            $in: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
            $nin: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        height: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
            $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        width: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
            $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        position: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>;
            $gte: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>;
            $lt: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>;
            $lte: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>;
            $ne: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>;
            $in: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }> | import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>;
            $nin: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }> | import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        parentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
            $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        modelsVersionsId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<"uuid">, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TString<"uuid">;
            $gte: import("@sinclair/typebox").TString<"uuid">;
            $lt: import("@sinclair/typebox").TString<"uuid">;
            $lte: import("@sinclair/typebox").TString<"uuid">;
            $ne: import("@sinclair/typebox").TString<"uuid">;
            $in: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
            $nin: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        isParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TBoolean;
            $gte: import("@sinclair/typebox").TBoolean;
            $lt: import("@sinclair/typebox").TBoolean;
            $lte: import("@sinclair/typebox").TBoolean;
            $ne: import("@sinclair/typebox").TBoolean;
            $in: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
            $nin: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        isOutputParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TBoolean;
            $gte: import("@sinclair/typebox").TBoolean;
            $lt: import("@sinclair/typebox").TBoolean;
            $lte: import("@sinclair/typebox").TBoolean;
            $ne: import("@sinclair/typebox").TBoolean;
            $in: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
            $nin: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        ghostParentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
            $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
    }>>, TObject<{
        $or: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<TObject<{
            name: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
                $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
                $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
                $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
                $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
                $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
                $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>>;
                $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>>;
            }>, TObject<{
                [key: string]: TSchema;
            } | undefined>]>>]>>;
            type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TEnum<typeof NodeType>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
                $gt: import("@sinclair/typebox").TEnum<typeof NodeType>;
                $gte: import("@sinclair/typebox").TEnum<typeof NodeType>;
                $lt: import("@sinclair/typebox").TEnum<typeof NodeType>;
                $lte: import("@sinclair/typebox").TEnum<typeof NodeType>;
                $ne: import("@sinclair/typebox").TEnum<typeof NodeType>;
                $in: import("@sinclair/typebox").TEnum<typeof NodeType> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TEnum<typeof NodeType>>;
                $nin: import("@sinclair/typebox").TEnum<typeof NodeType> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TEnum<typeof NodeType>>;
            }>, TObject<{
                [key: string]: TSchema;
            } | undefined>]>>]>>;
            data: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
                $gt: import("@sinclair/typebox").TIntersect<[TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                    delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                        x: import("@sinclair/typebox").TNumber;
                        y: import("@sinclair/typebox").TNumber;
                    }>>>;
                    interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
                }>, TObject<{
                    startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                }>, TObject<{
                    populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                    geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                    networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    query: import("@sinclair/typebox").TOptional<TObject<{
                        limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                        properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                        propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                            value: import("@sinclair/typebox").TString<string>;
                            operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        }>>>;
                    }>>;
                    dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                        keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    }>>;
                }>, TObject<{
                    modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                }>]>;
                $gte: import("@sinclair/typebox").TIntersect<[TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                    delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                        x: import("@sinclair/typebox").TNumber;
                        y: import("@sinclair/typebox").TNumber;
                    }>>>;
                    interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
                }>, TObject<{
                    startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                }>, TObject<{
                    populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                    geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                    networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    query: import("@sinclair/typebox").TOptional<TObject<{
                        limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                        properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                        propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                            value: import("@sinclair/typebox").TString<string>;
                            operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        }>>>;
                    }>>;
                    dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                        keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    }>>;
                }>, TObject<{
                    modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                }>]>;
                $lt: import("@sinclair/typebox").TIntersect<[TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                    delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                        x: import("@sinclair/typebox").TNumber;
                        y: import("@sinclair/typebox").TNumber;
                    }>>>;
                    interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
                }>, TObject<{
                    startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                }>, TObject<{
                    populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                    geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                    networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    query: import("@sinclair/typebox").TOptional<TObject<{
                        limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                        properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                        propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                            value: import("@sinclair/typebox").TString<string>;
                            operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        }>>>;
                    }>>;
                    dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                        keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    }>>;
                }>, TObject<{
                    modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                }>]>;
                $lte: import("@sinclair/typebox").TIntersect<[TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                    delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                        x: import("@sinclair/typebox").TNumber;
                        y: import("@sinclair/typebox").TNumber;
                    }>>>;
                    interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
                }>, TObject<{
                    startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                }>, TObject<{
                    populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                    geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                    networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    query: import("@sinclair/typebox").TOptional<TObject<{
                        limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                        properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                        propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                            value: import("@sinclair/typebox").TString<string>;
                            operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        }>>>;
                    }>>;
                    dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                        keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    }>>;
                }>, TObject<{
                    modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                }>]>;
                $ne: import("@sinclair/typebox").TIntersect<[TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                    delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                        x: import("@sinclair/typebox").TNumber;
                        y: import("@sinclair/typebox").TNumber;
                    }>>>;
                    interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
                }>, TObject<{
                    startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                }>, TObject<{
                    populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                    geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                    networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    query: import("@sinclair/typebox").TOptional<TObject<{
                        limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                        properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                        propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                            value: import("@sinclair/typebox").TString<string>;
                            operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        }>>>;
                    }>>;
                    dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                        keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    }>>;
                }>, TObject<{
                    modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                }>]>;
                $in: import("@sinclair/typebox").TIntersect<[TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                    delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                        x: import("@sinclair/typebox").TNumber;
                        y: import("@sinclair/typebox").TNumber;
                    }>>>;
                    interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
                }>, TObject<{
                    startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                }>, TObject<{
                    populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                    geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                    networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    query: import("@sinclair/typebox").TOptional<TObject<{
                        limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                        properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                        propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                            value: import("@sinclair/typebox").TString<string>;
                            operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        }>>>;
                    }>>;
                    dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                        keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    }>>;
                }>, TObject<{
                    modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                }>]> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TIntersect<[TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                    delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                        x: import("@sinclair/typebox").TNumber;
                        y: import("@sinclair/typebox").TNumber;
                    }>>>;
                    interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
                }>, TObject<{
                    startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                }>, TObject<{
                    populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                    geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                    networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    query: import("@sinclair/typebox").TOptional<TObject<{
                        limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                        properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                        propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                            value: import("@sinclair/typebox").TString<string>;
                            operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        }>>>;
                    }>>;
                    dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                        keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    }>>;
                }>, TObject<{
                    modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                }>]>>;
                $nin: import("@sinclair/typebox").TIntersect<[TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                    delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                        x: import("@sinclair/typebox").TNumber;
                        y: import("@sinclair/typebox").TNumber;
                    }>>>;
                    interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
                }>, TObject<{
                    startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                }>, TObject<{
                    populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                    geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                    networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    query: import("@sinclair/typebox").TOptional<TObject<{
                        limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                        properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                        propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                            value: import("@sinclair/typebox").TString<string>;
                            operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        }>>>;
                    }>>;
                    dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                        keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    }>>;
                }>, TObject<{
                    modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                }>]> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TIntersect<[TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                    delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                }>, TObject<{
                    units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                    values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                        x: import("@sinclair/typebox").TNumber;
                        y: import("@sinclair/typebox").TNumber;
                    }>>>;
                    interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
                }>, TObject<{
                    startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                    direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                    constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                        min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    }>>>;
                }>, TObject<{
                    populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                    geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                    networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>, TObject<{
                    apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    query: import("@sinclair/typebox").TOptional<TObject<{
                        limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                        skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                        properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                        propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                            value: import("@sinclair/typebox").TString<string>;
                            operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        }>>>;
                    }>>;
                    dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                        keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                        valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    }>>;
                }>, TObject<{
                    modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                    importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                }>]>>;
            }>, TObject<{
                [key: string]: TSchema;
            } | undefined>]>>]>>;
            id: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<"uuid">, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
                $gt: import("@sinclair/typebox").TString<"uuid">;
                $gte: import("@sinclair/typebox").TString<"uuid">;
                $lt: import("@sinclair/typebox").TString<"uuid">;
                $lte: import("@sinclair/typebox").TString<"uuid">;
                $ne: import("@sinclair/typebox").TString<"uuid">;
                $in: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
                $nin: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
            }>, TObject<{
                [key: string]: TSchema;
            } | undefined>]>>]>>;
            height: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
                $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
                $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
                $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
                $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
                $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
                $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
                $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
            }>, TObject<{
                [key: string]: TSchema;
            } | undefined>]>>]>>;
            width: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
                $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
                $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
                $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
                $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
                $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
                $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
                $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
            }>, TObject<{
                [key: string]: TSchema;
            } | undefined>]>>]>>;
            position: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
                $gt: TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>;
                $gte: TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>;
                $lt: TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>;
                $lte: TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>;
                $ne: TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>;
                $in: TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }> | import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>;
                $nin: TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }> | import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>;
            }>, TObject<{
                [key: string]: TSchema;
            } | undefined>]>>]>>;
            parentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
                $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
                $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
                $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
                $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
                $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
                $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
                $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
            }>, TObject<{
                [key: string]: TSchema;
            } | undefined>]>>]>>;
            modelsVersionsId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<"uuid">, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
                $gt: import("@sinclair/typebox").TString<"uuid">;
                $gte: import("@sinclair/typebox").TString<"uuid">;
                $lt: import("@sinclair/typebox").TString<"uuid">;
                $lte: import("@sinclair/typebox").TString<"uuid">;
                $ne: import("@sinclair/typebox").TString<"uuid">;
                $in: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
                $nin: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
            }>, TObject<{
                [key: string]: TSchema;
            } | undefined>]>>]>>;
            isParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
                $gt: import("@sinclair/typebox").TBoolean;
                $gte: import("@sinclair/typebox").TBoolean;
                $lt: import("@sinclair/typebox").TBoolean;
                $lte: import("@sinclair/typebox").TBoolean;
                $ne: import("@sinclair/typebox").TBoolean;
                $in: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
                $nin: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                [key: string]: TSchema;
            } | undefined>]>>]>>;
            isOutputParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
                $gt: import("@sinclair/typebox").TBoolean;
                $gte: import("@sinclair/typebox").TBoolean;
                $lt: import("@sinclair/typebox").TBoolean;
                $lte: import("@sinclair/typebox").TBoolean;
                $ne: import("@sinclair/typebox").TBoolean;
                $in: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
                $nin: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                [key: string]: TSchema;
            } | undefined>]>>]>>;
            ghostParentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
                $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
                $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
                $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
                $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
                $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
                $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
                $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
            }>, TObject<{
                [key: string]: TSchema;
            } | undefined>]>>]>>;
        }>>>;
    }>]>>;
    $or: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<TObject<{
        name: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
            $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
            $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
            $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
            $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
            $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>>;
            $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TEnum<typeof NodeType>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TEnum<typeof NodeType>;
            $gte: import("@sinclair/typebox").TEnum<typeof NodeType>;
            $lt: import("@sinclair/typebox").TEnum<typeof NodeType>;
            $lte: import("@sinclair/typebox").TEnum<typeof NodeType>;
            $ne: import("@sinclair/typebox").TEnum<typeof NodeType>;
            $in: import("@sinclair/typebox").TEnum<typeof NodeType> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TEnum<typeof NodeType>>;
            $nin: import("@sinclair/typebox").TEnum<typeof NodeType> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TEnum<typeof NodeType>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        data: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TIntersect<[TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
            delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>>;
            interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
        }>, TObject<{
            startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
        }>, TObject<{
            populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
            geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
            networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            query: import("@sinclair/typebox").TOptional<TObject<{
                limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                    value: import("@sinclair/typebox").TString<string>;
                    operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>>>;
            }>>;
            dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            }>>;
        }>, TObject<{
            modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        }>]>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>;
            $gte: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>;
            $lt: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>;
            $lte: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>;
            $ne: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>;
            $in: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>>;
            $nin: import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TIntersect<[TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
                delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            }>, TObject<{
                units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
                values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                    x: import("@sinclair/typebox").TNumber;
                    y: import("@sinclair/typebox").TNumber;
                }>>>;
                interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
            }>, TObject<{
                startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
                direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
                constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                    min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                }>>>;
            }>, TObject<{
                populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
                geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
                networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>, TObject<{
                apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                query: import("@sinclair/typebox").TOptional<TObject<{
                    limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                    skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                    properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                    propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                        value: import("@sinclair/typebox").TString<string>;
                        operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    }>>>;
                }>>;
                dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                    keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                    valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                }>>;
            }>, TObject<{
                modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
                importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            }>]>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        id: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<"uuid">, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TString<"uuid">;
            $gte: import("@sinclair/typebox").TString<"uuid">;
            $lt: import("@sinclair/typebox").TString<"uuid">;
            $lte: import("@sinclair/typebox").TString<"uuid">;
            $ne: import("@sinclair/typebox").TString<"uuid">;
            $in: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
            $nin: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        height: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
            $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        width: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
            $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
            $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        position: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>;
            $gte: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>;
            $lt: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>;
            $lte: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>;
            $ne: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>;
            $in: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }> | import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>;
            $nin: TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }> | import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        parentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
            $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        modelsVersionsId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<"uuid">, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TString<"uuid">;
            $gte: import("@sinclair/typebox").TString<"uuid">;
            $lt: import("@sinclair/typebox").TString<"uuid">;
            $lte: import("@sinclair/typebox").TString<"uuid">;
            $ne: import("@sinclair/typebox").TString<"uuid">;
            $in: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
            $nin: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        isParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TBoolean;
            $gte: import("@sinclair/typebox").TBoolean;
            $lt: import("@sinclair/typebox").TBoolean;
            $lte: import("@sinclair/typebox").TBoolean;
            $ne: import("@sinclair/typebox").TBoolean;
            $in: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
            $nin: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        isOutputParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TBoolean;
            $gte: import("@sinclair/typebox").TBoolean;
            $lt: import("@sinclair/typebox").TBoolean;
            $lte: import("@sinclair/typebox").TBoolean;
            $ne: import("@sinclair/typebox").TBoolean;
            $in: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
            $nin: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
        ghostParentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
            $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
            $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
            $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
        }>, TObject<{
            [key: string]: TSchema;
        } | undefined>]>>]>>;
    }>>>;
}>>, import("@sinclair/typebox").TOptional<TObject<{
    name: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
        $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
        $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
        $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
        $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
        $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
        $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>>;
        $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>>;
    }>, TObject<{
        [key: string]: TSchema;
    } | undefined>]>>]>>;
    type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TEnum<typeof NodeType>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
        $gt: import("@sinclair/typebox").TEnum<typeof NodeType>;
        $gte: import("@sinclair/typebox").TEnum<typeof NodeType>;
        $lt: import("@sinclair/typebox").TEnum<typeof NodeType>;
        $lte: import("@sinclair/typebox").TEnum<typeof NodeType>;
        $ne: import("@sinclair/typebox").TEnum<typeof NodeType>;
        $in: import("@sinclair/typebox").TEnum<typeof NodeType> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TEnum<typeof NodeType>>;
        $nin: import("@sinclair/typebox").TEnum<typeof NodeType> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TEnum<typeof NodeType>>;
    }>, TObject<{
        [key: string]: TSchema;
    } | undefined>]>>]>>;
    data: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TIntersect<[TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
        delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
    }>, TObject<{
        units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
        values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>>>;
        interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
    }>, TObject<{
        startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
        action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
        direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
            min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        }>>>;
    }>, TObject<{
        populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
        geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
        networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>, TObject<{
        apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        query: import("@sinclair/typebox").TOptional<TObject<{
            limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                value: import("@sinclair/typebox").TString<string>;
                operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>>>;
        }>>;
        dataTransform: import("@sinclair/typebox").TOptional<TObject<{
            keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
        }>>;
    }>, TObject<{
        modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
    }>]>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
        $gt: import("@sinclair/typebox").TIntersect<[TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
            delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>>;
            interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
        }>, TObject<{
            startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
        }>, TObject<{
            populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
            geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
            networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            query: import("@sinclair/typebox").TOptional<TObject<{
                limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                    value: import("@sinclair/typebox").TString<string>;
                    operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>>>;
            }>>;
            dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            }>>;
        }>, TObject<{
            modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        }>]>;
        $gte: import("@sinclair/typebox").TIntersect<[TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
            delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>>;
            interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
        }>, TObject<{
            startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
        }>, TObject<{
            populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
            geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
            networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            query: import("@sinclair/typebox").TOptional<TObject<{
                limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                    value: import("@sinclair/typebox").TString<string>;
                    operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>>>;
            }>>;
            dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            }>>;
        }>, TObject<{
            modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        }>]>;
        $lt: import("@sinclair/typebox").TIntersect<[TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
            delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>>;
            interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
        }>, TObject<{
            startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
        }>, TObject<{
            populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
            geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
            networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            query: import("@sinclair/typebox").TOptional<TObject<{
                limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                    value: import("@sinclair/typebox").TString<string>;
                    operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>>>;
            }>>;
            dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            }>>;
        }>, TObject<{
            modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        }>]>;
        $lte: import("@sinclair/typebox").TIntersect<[TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
            delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>>;
            interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
        }>, TObject<{
            startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
        }>, TObject<{
            populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
            geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
            networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            query: import("@sinclair/typebox").TOptional<TObject<{
                limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                    value: import("@sinclair/typebox").TString<string>;
                    operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>>>;
            }>>;
            dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            }>>;
        }>, TObject<{
            modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        }>]>;
        $ne: import("@sinclair/typebox").TIntersect<[TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
            delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>>;
            interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
        }>, TObject<{
            startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
        }>, TObject<{
            populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
            geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
            networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            query: import("@sinclair/typebox").TOptional<TObject<{
                limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                    value: import("@sinclair/typebox").TString<string>;
                    operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>>>;
            }>>;
            dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            }>>;
        }>, TObject<{
            modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        }>]>;
        $in: import("@sinclair/typebox").TIntersect<[TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
            delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>>;
            interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
        }>, TObject<{
            startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
        }>, TObject<{
            populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
            geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
            networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            query: import("@sinclair/typebox").TOptional<TObject<{
                limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                    value: import("@sinclair/typebox").TString<string>;
                    operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>>>;
            }>>;
            dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            }>>;
        }>, TObject<{
            modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        }>]> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TIntersect<[TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
            delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>>;
            interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
        }>, TObject<{
            startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
        }>, TObject<{
            populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
            geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
            networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            query: import("@sinclair/typebox").TOptional<TObject<{
                limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                    value: import("@sinclair/typebox").TString<string>;
                    operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>>>;
            }>>;
            dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            }>>;
        }>, TObject<{
            modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        }>]>>;
        $nin: import("@sinclair/typebox").TIntersect<[TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
            delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>>;
            interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
        }>, TObject<{
            startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
        }>, TObject<{
            populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
            geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
            networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            query: import("@sinclair/typebox").TOptional<TObject<{
                limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                    value: import("@sinclair/typebox").TString<string>;
                    operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>>>;
            }>>;
            dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            }>>;
        }>, TObject<{
            modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        }>]> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TIntersect<[TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            initial: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            type: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<StockTypeType>[]>>;
            delay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            rate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            nonNegative: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
        }>, TObject<{
            units: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
            values: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<TObject<{
                x: import("@sinclair/typebox").TNumber;
                y: import("@sinclair/typebox").TNumber;
            }>>>;
            interpolation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"Linear">, import("@sinclair/typebox").TLiteral<"Discrete">]>>;
        }>, TObject<{
            startActive: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            residency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            action: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            value: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            recalculate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            repeat: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            trigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<TriggerType>[]>>;
            direction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"left" | "top" | "bottom" | "right">[]>>;
            constraints: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TPartial<TObject<{
                min: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                max: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            }>>>;
        }>, TObject<{
            populationSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            geoUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWidth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoHeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            geoWrapAround: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
            geoPlacementType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<PlacementType>[]>>;
            geoPlacementFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            networkType: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<NetworkType>[]>>;
            networkFunction: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>, TObject<{
            apiId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            collectionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            query: import("@sinclair/typebox").TOptional<TObject<{
                limit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                offset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
                skipGeometry: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
                properties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
                propertyFilters: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, TObject<{
                    value: import("@sinclair/typebox").TString<string>;
                    operator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                }>>>;
            }>>;
            dataTransform: import("@sinclair/typebox").TOptional<TObject<{
                keyProperty: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                valueProperties: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            }>>;
        }>, TObject<{
            modelId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            modelVersionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
            importedFolderId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<"uuid">>;
        }>]>>;
    }>, TObject<{
        [key: string]: TSchema;
    } | undefined>]>>]>>;
    id: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<"uuid">, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
        $gt: import("@sinclair/typebox").TString<"uuid">;
        $gte: import("@sinclair/typebox").TString<"uuid">;
        $lt: import("@sinclair/typebox").TString<"uuid">;
        $lte: import("@sinclair/typebox").TString<"uuid">;
        $ne: import("@sinclair/typebox").TString<"uuid">;
        $in: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
        $nin: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
    }>, TObject<{
        [key: string]: TSchema;
    } | undefined>]>>]>>;
    height: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
        $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
        $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
        $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
        $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
        $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
        $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
        $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
    }>, TObject<{
        [key: string]: TSchema;
    } | undefined>]>>]>>;
    width: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
        $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
        $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
        $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
        $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
        $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
        $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
        $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>>;
    }>, TObject<{
        [key: string]: TSchema;
    } | undefined>]>>]>>;
    position: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[TObject<{
        x: import("@sinclair/typebox").TNumber;
        y: import("@sinclair/typebox").TNumber;
    }>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
        $gt: TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>;
        $gte: TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>;
        $lt: TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>;
        $lte: TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>;
        $ne: TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>;
        $in: TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }> | import("@sinclair/typebox").TArray<TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>>;
        $nin: TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }> | import("@sinclair/typebox").TArray<TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>>;
    }>, TObject<{
        [key: string]: TSchema;
    } | undefined>]>>]>>;
    parentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
        $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
        $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
        $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
        $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
        $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
        $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
        $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
    }>, TObject<{
        [key: string]: TSchema;
    } | undefined>]>>]>>;
    modelsVersionsId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<"uuid">, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
        $gt: import("@sinclair/typebox").TString<"uuid">;
        $gte: import("@sinclair/typebox").TString<"uuid">;
        $lt: import("@sinclair/typebox").TString<"uuid">;
        $lte: import("@sinclair/typebox").TString<"uuid">;
        $ne: import("@sinclair/typebox").TString<"uuid">;
        $in: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
        $nin: import("@sinclair/typebox").TString<"uuid"> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>;
    }>, TObject<{
        [key: string]: TSchema;
    } | undefined>]>>]>>;
    isParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
        $gt: import("@sinclair/typebox").TBoolean;
        $gte: import("@sinclair/typebox").TBoolean;
        $lt: import("@sinclair/typebox").TBoolean;
        $lte: import("@sinclair/typebox").TBoolean;
        $ne: import("@sinclair/typebox").TBoolean;
        $in: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
        $nin: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
    }>, TObject<{
        [key: string]: TSchema;
    } | undefined>]>>]>>;
    isOutputParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
        $gt: import("@sinclair/typebox").TBoolean;
        $gte: import("@sinclair/typebox").TBoolean;
        $lt: import("@sinclair/typebox").TBoolean;
        $lte: import("@sinclair/typebox").TBoolean;
        $ne: import("@sinclair/typebox").TBoolean;
        $in: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
        $nin: import("@sinclair/typebox").TBoolean | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TBoolean>;
    }>, TObject<{
        [key: string]: TSchema;
    } | undefined>]>>]>>;
    ghostParentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[TObject<{
        $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
        $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
        $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
        $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
        $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
        $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
        $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>>;
    }>, TObject<{
        [key: string]: TSchema;
    } | undefined>]>>]>>;
}>>]>, TObject<{}>]>;
export type NodesQuery = Static<typeof nodesQuerySchema>;
export declare const nodesQueryValidator: import("@feathersjs/schema").Validator<any, any>;
export declare const nodesQueryResolver: import("@feathersjs/schema").Resolver<Partial<{
    $limit: number;
    $skip: number;
    $sort: {
        name?: number | undefined;
        type?: number | undefined;
        data?: number | undefined;
        id?: number | undefined;
        height?: number | undefined;
        width?: number | undefined;
        position?: number | undefined;
        parentId?: number | undefined;
        modelsVersionsId?: number | undefined;
        isParameter?: number | undefined;
        isOutputParameter?: number | undefined;
        ghostParentId?: number | undefined;
    };
    $select: ("name" | "type" | "data" | "id" | "height" | "width" | "position" | "parentId" | "modelsVersionsId" | "isParameter" | "isOutputParameter" | "ghostParentId")[];
    $and: ({
        name?: string | Partial<{
            $gt?: string | null | undefined;
            $gte?: string | null | undefined;
            $lt?: string | null | undefined;
            $lte?: string | null | undefined;
            $ne?: string | null | undefined;
            $in: string | (string | null)[] | null;
            $nin: string | (string | null)[] | null;
        } & {}> | null | undefined;
        type?: NodeType | Partial<{
            $gt: NodeType;
            $gte: NodeType;
            $lt: NodeType;
            $lte: NodeType;
            $ne: NodeType;
            $in: NodeType | NodeType[];
            $nin: NodeType | NodeType[];
        } & {}> | undefined;
        data?: ({
            value?: string | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
        } & {
            type?: StockTypeType | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            initial?: string | undefined;
            delay?: string | undefined;
            nonNegative?: boolean | undefined;
        } & {
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            nonNegative?: boolean | undefined;
            rate?: string | undefined;
        } & {
            values?: {
                x: number;
                y: number;
            }[] | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            interpolation?: "Linear" | "Discrete" | undefined;
        } & {
            startActive?: string | undefined;
            residency?: string | undefined;
        } & {
            repeat?: boolean | undefined;
            value?: string | undefined;
            action?: string | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            repeat?: boolean | undefined;
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            value?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            populationSize?: number | undefined;
            geoUnits?: string | undefined;
            geoWidth?: string | undefined;
            geoHeight?: string | undefined;
            geoWrapAround?: boolean | undefined;
            geoPlacementType?: PlacementType | undefined;
            geoPlacementFunction?: string | undefined;
            networkType?: NetworkType | undefined;
            networkFunction?: string | undefined;
        } & {
            query?: {
                offset?: number | undefined;
                properties?: string[] | undefined;
                limit?: number | undefined;
                skipGeometry?: boolean | undefined;
                propertyFilters?: Record<string, {
                    operator?: string | undefined;
                    value: string;
                }> | undefined;
            } | undefined;
            apiId?: string | undefined;
            collectionId?: string | undefined;
            dataTransform?: {
                keyProperty?: string | undefined;
                valueProperties?: string[] | undefined;
            } | undefined;
        } & {
            modelId?: string | undefined;
            modelVersionId?: string | undefined;
            importedFolderId?: string | undefined;
        }) | Partial<{
            $gt: {
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            };
            $gte: {
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            };
            $lt: {
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            };
            $lte: {
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            };
            $ne: {
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            };
            $in: ({
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            }) | ({
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            })[];
            $nin: ({
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            }) | ({
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            })[];
        } & {}> | undefined;
        id?: string | Partial<{
            $gt: string;
            $gte: string;
            $lt: string;
            $lte: string;
            $ne: string;
            $in: string | string[];
            $nin: string | string[];
        } & {}> | undefined;
        height?: number | Partial<{
            $gt?: number | null | undefined;
            $gte?: number | null | undefined;
            $lt?: number | null | undefined;
            $lte?: number | null | undefined;
            $ne?: number | null | undefined;
            $in: number | (number | null)[] | null;
            $nin: number | (number | null)[] | null;
        } & {}> | null | undefined;
        width?: number | Partial<{
            $gt?: number | null | undefined;
            $gte?: number | null | undefined;
            $lt?: number | null | undefined;
            $lte?: number | null | undefined;
            $ne?: number | null | undefined;
            $in: number | (number | null)[] | null;
            $nin: number | (number | null)[] | null;
        } & {}> | null | undefined;
        position?: {
            x: number;
            y: number;
        } | Partial<{
            $gt: {
                x: number;
                y: number;
            };
            $gte: {
                x: number;
                y: number;
            };
            $lt: {
                x: number;
                y: number;
            };
            $lte: {
                x: number;
                y: number;
            };
            $ne: {
                x: number;
                y: number;
            };
            $in: {
                x: number;
                y: number;
            } | {
                x: number;
                y: number;
            }[];
            $nin: {
                x: number;
                y: number;
            } | {
                x: number;
                y: number;
            }[];
        } & {}> | undefined;
        parentId?: string | Partial<{
            $gt?: string | null | undefined;
            $gte?: string | null | undefined;
            $lt?: string | null | undefined;
            $lte?: string | null | undefined;
            $ne?: string | null | undefined;
            $in: string | (string | null)[] | null;
            $nin: string | (string | null)[] | null;
        } & {}> | null | undefined;
        modelsVersionsId?: string | Partial<{
            $gt: string;
            $gte: string;
            $lt: string;
            $lte: string;
            $ne: string;
            $in: string | string[];
            $nin: string | string[];
        } & {}> | undefined;
        isParameter?: boolean | Partial<{
            $gt: boolean;
            $gte: boolean;
            $lt: boolean;
            $lte: boolean;
            $ne: boolean;
            $in: boolean | boolean[];
            $nin: boolean | boolean[];
        } & {}> | undefined;
        isOutputParameter?: boolean | Partial<{
            $gt: boolean;
            $gte: boolean;
            $lt: boolean;
            $lte: boolean;
            $ne: boolean;
            $in: boolean | boolean[];
            $nin: boolean | boolean[];
        } & {}> | undefined;
        ghostParentId?: string | Partial<{
            $gt?: string | null | undefined;
            $gte?: string | null | undefined;
            $lt?: string | null | undefined;
            $lte?: string | null | undefined;
            $ne?: string | null | undefined;
            $in: string | (string | null)[] | null;
            $nin: string | (string | null)[] | null;
        } & {}> | null | undefined;
    } | {
        $or: {
            name?: string | Partial<{
                $gt?: string | null | undefined;
                $gte?: string | null | undefined;
                $lt?: string | null | undefined;
                $lte?: string | null | undefined;
                $ne?: string | null | undefined;
                $in: string | (string | null)[] | null;
                $nin: string | (string | null)[] | null;
            } & {}> | null | undefined;
            type?: NodeType | Partial<{
                $gt: NodeType;
                $gte: NodeType;
                $lt: NodeType;
                $lte: NodeType;
                $ne: NodeType;
                $in: NodeType | NodeType[];
                $nin: NodeType | NodeType[];
            } & {}> | undefined;
            data?: ({
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            }) | Partial<{
                $gt: {
                    value?: string | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                } & {
                    type?: StockTypeType | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    initial?: string | undefined;
                    delay?: string | undefined;
                    nonNegative?: boolean | undefined;
                } & {
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    nonNegative?: boolean | undefined;
                    rate?: string | undefined;
                } & {
                    values?: {
                        x: number;
                        y: number;
                    }[] | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    interpolation?: "Linear" | "Discrete" | undefined;
                } & {
                    startActive?: string | undefined;
                    residency?: string | undefined;
                } & {
                    repeat?: boolean | undefined;
                    value?: string | undefined;
                    action?: string | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    repeat?: boolean | undefined;
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    value?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    populationSize?: number | undefined;
                    geoUnits?: string | undefined;
                    geoWidth?: string | undefined;
                    geoHeight?: string | undefined;
                    geoWrapAround?: boolean | undefined;
                    geoPlacementType?: PlacementType | undefined;
                    geoPlacementFunction?: string | undefined;
                    networkType?: NetworkType | undefined;
                    networkFunction?: string | undefined;
                } & {
                    query?: {
                        offset?: number | undefined;
                        properties?: string[] | undefined;
                        limit?: number | undefined;
                        skipGeometry?: boolean | undefined;
                        propertyFilters?: Record<string, {
                            operator?: string | undefined;
                            value: string;
                        }> | undefined;
                    } | undefined;
                    apiId?: string | undefined;
                    collectionId?: string | undefined;
                    dataTransform?: {
                        keyProperty?: string | undefined;
                        valueProperties?: string[] | undefined;
                    } | undefined;
                } & {
                    modelId?: string | undefined;
                    modelVersionId?: string | undefined;
                    importedFolderId?: string | undefined;
                };
                $gte: {
                    value?: string | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                } & {
                    type?: StockTypeType | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    initial?: string | undefined;
                    delay?: string | undefined;
                    nonNegative?: boolean | undefined;
                } & {
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    nonNegative?: boolean | undefined;
                    rate?: string | undefined;
                } & {
                    values?: {
                        x: number;
                        y: number;
                    }[] | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    interpolation?: "Linear" | "Discrete" | undefined;
                } & {
                    startActive?: string | undefined;
                    residency?: string | undefined;
                } & {
                    repeat?: boolean | undefined;
                    value?: string | undefined;
                    action?: string | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    repeat?: boolean | undefined;
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    value?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    populationSize?: number | undefined;
                    geoUnits?: string | undefined;
                    geoWidth?: string | undefined;
                    geoHeight?: string | undefined;
                    geoWrapAround?: boolean | undefined;
                    geoPlacementType?: PlacementType | undefined;
                    geoPlacementFunction?: string | undefined;
                    networkType?: NetworkType | undefined;
                    networkFunction?: string | undefined;
                } & {
                    query?: {
                        offset?: number | undefined;
                        properties?: string[] | undefined;
                        limit?: number | undefined;
                        skipGeometry?: boolean | undefined;
                        propertyFilters?: Record<string, {
                            operator?: string | undefined;
                            value: string;
                        }> | undefined;
                    } | undefined;
                    apiId?: string | undefined;
                    collectionId?: string | undefined;
                    dataTransform?: {
                        keyProperty?: string | undefined;
                        valueProperties?: string[] | undefined;
                    } | undefined;
                } & {
                    modelId?: string | undefined;
                    modelVersionId?: string | undefined;
                    importedFolderId?: string | undefined;
                };
                $lt: {
                    value?: string | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                } & {
                    type?: StockTypeType | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    initial?: string | undefined;
                    delay?: string | undefined;
                    nonNegative?: boolean | undefined;
                } & {
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    nonNegative?: boolean | undefined;
                    rate?: string | undefined;
                } & {
                    values?: {
                        x: number;
                        y: number;
                    }[] | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    interpolation?: "Linear" | "Discrete" | undefined;
                } & {
                    startActive?: string | undefined;
                    residency?: string | undefined;
                } & {
                    repeat?: boolean | undefined;
                    value?: string | undefined;
                    action?: string | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    repeat?: boolean | undefined;
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    value?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    populationSize?: number | undefined;
                    geoUnits?: string | undefined;
                    geoWidth?: string | undefined;
                    geoHeight?: string | undefined;
                    geoWrapAround?: boolean | undefined;
                    geoPlacementType?: PlacementType | undefined;
                    geoPlacementFunction?: string | undefined;
                    networkType?: NetworkType | undefined;
                    networkFunction?: string | undefined;
                } & {
                    query?: {
                        offset?: number | undefined;
                        properties?: string[] | undefined;
                        limit?: number | undefined;
                        skipGeometry?: boolean | undefined;
                        propertyFilters?: Record<string, {
                            operator?: string | undefined;
                            value: string;
                        }> | undefined;
                    } | undefined;
                    apiId?: string | undefined;
                    collectionId?: string | undefined;
                    dataTransform?: {
                        keyProperty?: string | undefined;
                        valueProperties?: string[] | undefined;
                    } | undefined;
                } & {
                    modelId?: string | undefined;
                    modelVersionId?: string | undefined;
                    importedFolderId?: string | undefined;
                };
                $lte: {
                    value?: string | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                } & {
                    type?: StockTypeType | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    initial?: string | undefined;
                    delay?: string | undefined;
                    nonNegative?: boolean | undefined;
                } & {
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    nonNegative?: boolean | undefined;
                    rate?: string | undefined;
                } & {
                    values?: {
                        x: number;
                        y: number;
                    }[] | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    interpolation?: "Linear" | "Discrete" | undefined;
                } & {
                    startActive?: string | undefined;
                    residency?: string | undefined;
                } & {
                    repeat?: boolean | undefined;
                    value?: string | undefined;
                    action?: string | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    repeat?: boolean | undefined;
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    value?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    populationSize?: number | undefined;
                    geoUnits?: string | undefined;
                    geoWidth?: string | undefined;
                    geoHeight?: string | undefined;
                    geoWrapAround?: boolean | undefined;
                    geoPlacementType?: PlacementType | undefined;
                    geoPlacementFunction?: string | undefined;
                    networkType?: NetworkType | undefined;
                    networkFunction?: string | undefined;
                } & {
                    query?: {
                        offset?: number | undefined;
                        properties?: string[] | undefined;
                        limit?: number | undefined;
                        skipGeometry?: boolean | undefined;
                        propertyFilters?: Record<string, {
                            operator?: string | undefined;
                            value: string;
                        }> | undefined;
                    } | undefined;
                    apiId?: string | undefined;
                    collectionId?: string | undefined;
                    dataTransform?: {
                        keyProperty?: string | undefined;
                        valueProperties?: string[] | undefined;
                    } | undefined;
                } & {
                    modelId?: string | undefined;
                    modelVersionId?: string | undefined;
                    importedFolderId?: string | undefined;
                };
                $ne: {
                    value?: string | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                } & {
                    type?: StockTypeType | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    initial?: string | undefined;
                    delay?: string | undefined;
                    nonNegative?: boolean | undefined;
                } & {
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    nonNegative?: boolean | undefined;
                    rate?: string | undefined;
                } & {
                    values?: {
                        x: number;
                        y: number;
                    }[] | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    interpolation?: "Linear" | "Discrete" | undefined;
                } & {
                    startActive?: string | undefined;
                    residency?: string | undefined;
                } & {
                    repeat?: boolean | undefined;
                    value?: string | undefined;
                    action?: string | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    repeat?: boolean | undefined;
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    value?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    populationSize?: number | undefined;
                    geoUnits?: string | undefined;
                    geoWidth?: string | undefined;
                    geoHeight?: string | undefined;
                    geoWrapAround?: boolean | undefined;
                    geoPlacementType?: PlacementType | undefined;
                    geoPlacementFunction?: string | undefined;
                    networkType?: NetworkType | undefined;
                    networkFunction?: string | undefined;
                } & {
                    query?: {
                        offset?: number | undefined;
                        properties?: string[] | undefined;
                        limit?: number | undefined;
                        skipGeometry?: boolean | undefined;
                        propertyFilters?: Record<string, {
                            operator?: string | undefined;
                            value: string;
                        }> | undefined;
                    } | undefined;
                    apiId?: string | undefined;
                    collectionId?: string | undefined;
                    dataTransform?: {
                        keyProperty?: string | undefined;
                        valueProperties?: string[] | undefined;
                    } | undefined;
                } & {
                    modelId?: string | undefined;
                    modelVersionId?: string | undefined;
                    importedFolderId?: string | undefined;
                };
                $in: ({
                    value?: string | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                } & {
                    type?: StockTypeType | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    initial?: string | undefined;
                    delay?: string | undefined;
                    nonNegative?: boolean | undefined;
                } & {
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    nonNegative?: boolean | undefined;
                    rate?: string | undefined;
                } & {
                    values?: {
                        x: number;
                        y: number;
                    }[] | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    interpolation?: "Linear" | "Discrete" | undefined;
                } & {
                    startActive?: string | undefined;
                    residency?: string | undefined;
                } & {
                    repeat?: boolean | undefined;
                    value?: string | undefined;
                    action?: string | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    repeat?: boolean | undefined;
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    value?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    populationSize?: number | undefined;
                    geoUnits?: string | undefined;
                    geoWidth?: string | undefined;
                    geoHeight?: string | undefined;
                    geoWrapAround?: boolean | undefined;
                    geoPlacementType?: PlacementType | undefined;
                    geoPlacementFunction?: string | undefined;
                    networkType?: NetworkType | undefined;
                    networkFunction?: string | undefined;
                } & {
                    query?: {
                        offset?: number | undefined;
                        properties?: string[] | undefined;
                        limit?: number | undefined;
                        skipGeometry?: boolean | undefined;
                        propertyFilters?: Record<string, {
                            operator?: string | undefined;
                            value: string;
                        }> | undefined;
                    } | undefined;
                    apiId?: string | undefined;
                    collectionId?: string | undefined;
                    dataTransform?: {
                        keyProperty?: string | undefined;
                        valueProperties?: string[] | undefined;
                    } | undefined;
                } & {
                    modelId?: string | undefined;
                    modelVersionId?: string | undefined;
                    importedFolderId?: string | undefined;
                }) | ({
                    value?: string | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                } & {
                    type?: StockTypeType | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    initial?: string | undefined;
                    delay?: string | undefined;
                    nonNegative?: boolean | undefined;
                } & {
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    nonNegative?: boolean | undefined;
                    rate?: string | undefined;
                } & {
                    values?: {
                        x: number;
                        y: number;
                    }[] | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    interpolation?: "Linear" | "Discrete" | undefined;
                } & {
                    startActive?: string | undefined;
                    residency?: string | undefined;
                } & {
                    repeat?: boolean | undefined;
                    value?: string | undefined;
                    action?: string | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    repeat?: boolean | undefined;
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    value?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    populationSize?: number | undefined;
                    geoUnits?: string | undefined;
                    geoWidth?: string | undefined;
                    geoHeight?: string | undefined;
                    geoWrapAround?: boolean | undefined;
                    geoPlacementType?: PlacementType | undefined;
                    geoPlacementFunction?: string | undefined;
                    networkType?: NetworkType | undefined;
                    networkFunction?: string | undefined;
                } & {
                    query?: {
                        offset?: number | undefined;
                        properties?: string[] | undefined;
                        limit?: number | undefined;
                        skipGeometry?: boolean | undefined;
                        propertyFilters?: Record<string, {
                            operator?: string | undefined;
                            value: string;
                        }> | undefined;
                    } | undefined;
                    apiId?: string | undefined;
                    collectionId?: string | undefined;
                    dataTransform?: {
                        keyProperty?: string | undefined;
                        valueProperties?: string[] | undefined;
                    } | undefined;
                } & {
                    modelId?: string | undefined;
                    modelVersionId?: string | undefined;
                    importedFolderId?: string | undefined;
                })[];
                $nin: ({
                    value?: string | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                } & {
                    type?: StockTypeType | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    initial?: string | undefined;
                    delay?: string | undefined;
                    nonNegative?: boolean | undefined;
                } & {
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    nonNegative?: boolean | undefined;
                    rate?: string | undefined;
                } & {
                    values?: {
                        x: number;
                        y: number;
                    }[] | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    interpolation?: "Linear" | "Discrete" | undefined;
                } & {
                    startActive?: string | undefined;
                    residency?: string | undefined;
                } & {
                    repeat?: boolean | undefined;
                    value?: string | undefined;
                    action?: string | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    repeat?: boolean | undefined;
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    value?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    populationSize?: number | undefined;
                    geoUnits?: string | undefined;
                    geoWidth?: string | undefined;
                    geoHeight?: string | undefined;
                    geoWrapAround?: boolean | undefined;
                    geoPlacementType?: PlacementType | undefined;
                    geoPlacementFunction?: string | undefined;
                    networkType?: NetworkType | undefined;
                    networkFunction?: string | undefined;
                } & {
                    query?: {
                        offset?: number | undefined;
                        properties?: string[] | undefined;
                        limit?: number | undefined;
                        skipGeometry?: boolean | undefined;
                        propertyFilters?: Record<string, {
                            operator?: string | undefined;
                            value: string;
                        }> | undefined;
                    } | undefined;
                    apiId?: string | undefined;
                    collectionId?: string | undefined;
                    dataTransform?: {
                        keyProperty?: string | undefined;
                        valueProperties?: string[] | undefined;
                    } | undefined;
                } & {
                    modelId?: string | undefined;
                    modelVersionId?: string | undefined;
                    importedFolderId?: string | undefined;
                }) | ({
                    value?: string | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                } & {
                    type?: StockTypeType | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    initial?: string | undefined;
                    delay?: string | undefined;
                    nonNegative?: boolean | undefined;
                } & {
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    nonNegative?: boolean | undefined;
                    rate?: string | undefined;
                } & {
                    values?: {
                        x: number;
                        y: number;
                    }[] | undefined;
                    units?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    interpolation?: "Linear" | "Discrete" | undefined;
                } & {
                    startActive?: string | undefined;
                    residency?: string | undefined;
                } & {
                    repeat?: boolean | undefined;
                    value?: string | undefined;
                    action?: string | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    repeat?: boolean | undefined;
                    direction?: "left" | "top" | "bottom" | "right" | undefined;
                    value?: string | undefined;
                    constraints?: Partial<{
                        max?: number | undefined;
                        min?: number | undefined;
                    }> | undefined;
                    recalculate?: boolean | undefined;
                    trigger?: TriggerType | undefined;
                } & {
                    populationSize?: number | undefined;
                    geoUnits?: string | undefined;
                    geoWidth?: string | undefined;
                    geoHeight?: string | undefined;
                    geoWrapAround?: boolean | undefined;
                    geoPlacementType?: PlacementType | undefined;
                    geoPlacementFunction?: string | undefined;
                    networkType?: NetworkType | undefined;
                    networkFunction?: string | undefined;
                } & {
                    query?: {
                        offset?: number | undefined;
                        properties?: string[] | undefined;
                        limit?: number | undefined;
                        skipGeometry?: boolean | undefined;
                        propertyFilters?: Record<string, {
                            operator?: string | undefined;
                            value: string;
                        }> | undefined;
                    } | undefined;
                    apiId?: string | undefined;
                    collectionId?: string | undefined;
                    dataTransform?: {
                        keyProperty?: string | undefined;
                        valueProperties?: string[] | undefined;
                    } | undefined;
                } & {
                    modelId?: string | undefined;
                    modelVersionId?: string | undefined;
                    importedFolderId?: string | undefined;
                })[];
            } & {}> | undefined;
            id?: string | Partial<{
                $gt: string;
                $gte: string;
                $lt: string;
                $lte: string;
                $ne: string;
                $in: string | string[];
                $nin: string | string[];
            } & {}> | undefined;
            height?: number | Partial<{
                $gt?: number | null | undefined;
                $gte?: number | null | undefined;
                $lt?: number | null | undefined;
                $lte?: number | null | undefined;
                $ne?: number | null | undefined;
                $in: number | (number | null)[] | null;
                $nin: number | (number | null)[] | null;
            } & {}> | null | undefined;
            width?: number | Partial<{
                $gt?: number | null | undefined;
                $gte?: number | null | undefined;
                $lt?: number | null | undefined;
                $lte?: number | null | undefined;
                $ne?: number | null | undefined;
                $in: number | (number | null)[] | null;
                $nin: number | (number | null)[] | null;
            } & {}> | null | undefined;
            position?: {
                x: number;
                y: number;
            } | Partial<{
                $gt: {
                    x: number;
                    y: number;
                };
                $gte: {
                    x: number;
                    y: number;
                };
                $lt: {
                    x: number;
                    y: number;
                };
                $lte: {
                    x: number;
                    y: number;
                };
                $ne: {
                    x: number;
                    y: number;
                };
                $in: {
                    x: number;
                    y: number;
                } | {
                    x: number;
                    y: number;
                }[];
                $nin: {
                    x: number;
                    y: number;
                } | {
                    x: number;
                    y: number;
                }[];
            } & {}> | undefined;
            parentId?: string | Partial<{
                $gt?: string | null | undefined;
                $gte?: string | null | undefined;
                $lt?: string | null | undefined;
                $lte?: string | null | undefined;
                $ne?: string | null | undefined;
                $in: string | (string | null)[] | null;
                $nin: string | (string | null)[] | null;
            } & {}> | null | undefined;
            modelsVersionsId?: string | Partial<{
                $gt: string;
                $gte: string;
                $lt: string;
                $lte: string;
                $ne: string;
                $in: string | string[];
                $nin: string | string[];
            } & {}> | undefined;
            isParameter?: boolean | Partial<{
                $gt: boolean;
                $gte: boolean;
                $lt: boolean;
                $lte: boolean;
                $ne: boolean;
                $in: boolean | boolean[];
                $nin: boolean | boolean[];
            } & {}> | undefined;
            isOutputParameter?: boolean | Partial<{
                $gt: boolean;
                $gte: boolean;
                $lt: boolean;
                $lte: boolean;
                $ne: boolean;
                $in: boolean | boolean[];
                $nin: boolean | boolean[];
            } & {}> | undefined;
            ghostParentId?: string | Partial<{
                $gt?: string | null | undefined;
                $gte?: string | null | undefined;
                $lt?: string | null | undefined;
                $lte?: string | null | undefined;
                $ne?: string | null | undefined;
                $in: string | (string | null)[] | null;
                $nin: string | (string | null)[] | null;
            } & {}> | null | undefined;
        }[];
    })[];
    $or: {
        name?: string | Partial<{
            $gt?: string | null | undefined;
            $gte?: string | null | undefined;
            $lt?: string | null | undefined;
            $lte?: string | null | undefined;
            $ne?: string | null | undefined;
            $in: string | (string | null)[] | null;
            $nin: string | (string | null)[] | null;
        } & {}> | null | undefined;
        type?: NodeType | Partial<{
            $gt: NodeType;
            $gte: NodeType;
            $lt: NodeType;
            $lte: NodeType;
            $ne: NodeType;
            $in: NodeType | NodeType[];
            $nin: NodeType | NodeType[];
        } & {}> | undefined;
        data?: ({
            value?: string | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
        } & {
            type?: StockTypeType | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            initial?: string | undefined;
            delay?: string | undefined;
            nonNegative?: boolean | undefined;
        } & {
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            nonNegative?: boolean | undefined;
            rate?: string | undefined;
        } & {
            values?: {
                x: number;
                y: number;
            }[] | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            interpolation?: "Linear" | "Discrete" | undefined;
        } & {
            startActive?: string | undefined;
            residency?: string | undefined;
        } & {
            repeat?: boolean | undefined;
            value?: string | undefined;
            action?: string | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            repeat?: boolean | undefined;
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            value?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            populationSize?: number | undefined;
            geoUnits?: string | undefined;
            geoWidth?: string | undefined;
            geoHeight?: string | undefined;
            geoWrapAround?: boolean | undefined;
            geoPlacementType?: PlacementType | undefined;
            geoPlacementFunction?: string | undefined;
            networkType?: NetworkType | undefined;
            networkFunction?: string | undefined;
        } & {
            query?: {
                offset?: number | undefined;
                properties?: string[] | undefined;
                limit?: number | undefined;
                skipGeometry?: boolean | undefined;
                propertyFilters?: Record<string, {
                    operator?: string | undefined;
                    value: string;
                }> | undefined;
            } | undefined;
            apiId?: string | undefined;
            collectionId?: string | undefined;
            dataTransform?: {
                keyProperty?: string | undefined;
                valueProperties?: string[] | undefined;
            } | undefined;
        } & {
            modelId?: string | undefined;
            modelVersionId?: string | undefined;
            importedFolderId?: string | undefined;
        }) | Partial<{
            $gt: {
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            };
            $gte: {
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            };
            $lt: {
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            };
            $lte: {
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            };
            $ne: {
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            };
            $in: ({
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            }) | ({
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            })[];
            $nin: ({
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            }) | ({
                value?: string | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
            } & {
                type?: StockTypeType | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                initial?: string | undefined;
                delay?: string | undefined;
                nonNegative?: boolean | undefined;
            } & {
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                nonNegative?: boolean | undefined;
                rate?: string | undefined;
            } & {
                values?: {
                    x: number;
                    y: number;
                }[] | undefined;
                units?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                interpolation?: "Linear" | "Discrete" | undefined;
            } & {
                startActive?: string | undefined;
                residency?: string | undefined;
            } & {
                repeat?: boolean | undefined;
                value?: string | undefined;
                action?: string | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                repeat?: boolean | undefined;
                direction?: "left" | "top" | "bottom" | "right" | undefined;
                value?: string | undefined;
                constraints?: Partial<{
                    max?: number | undefined;
                    min?: number | undefined;
                }> | undefined;
                recalculate?: boolean | undefined;
                trigger?: TriggerType | undefined;
            } & {
                populationSize?: number | undefined;
                geoUnits?: string | undefined;
                geoWidth?: string | undefined;
                geoHeight?: string | undefined;
                geoWrapAround?: boolean | undefined;
                geoPlacementType?: PlacementType | undefined;
                geoPlacementFunction?: string | undefined;
                networkType?: NetworkType | undefined;
                networkFunction?: string | undefined;
            } & {
                query?: {
                    offset?: number | undefined;
                    properties?: string[] | undefined;
                    limit?: number | undefined;
                    skipGeometry?: boolean | undefined;
                    propertyFilters?: Record<string, {
                        operator?: string | undefined;
                        value: string;
                    }> | undefined;
                } | undefined;
                apiId?: string | undefined;
                collectionId?: string | undefined;
                dataTransform?: {
                    keyProperty?: string | undefined;
                    valueProperties?: string[] | undefined;
                } | undefined;
            } & {
                modelId?: string | undefined;
                modelVersionId?: string | undefined;
                importedFolderId?: string | undefined;
            })[];
        } & {}> | undefined;
        id?: string | Partial<{
            $gt: string;
            $gte: string;
            $lt: string;
            $lte: string;
            $ne: string;
            $in: string | string[];
            $nin: string | string[];
        } & {}> | undefined;
        height?: number | Partial<{
            $gt?: number | null | undefined;
            $gte?: number | null | undefined;
            $lt?: number | null | undefined;
            $lte?: number | null | undefined;
            $ne?: number | null | undefined;
            $in: number | (number | null)[] | null;
            $nin: number | (number | null)[] | null;
        } & {}> | null | undefined;
        width?: number | Partial<{
            $gt?: number | null | undefined;
            $gte?: number | null | undefined;
            $lt?: number | null | undefined;
            $lte?: number | null | undefined;
            $ne?: number | null | undefined;
            $in: number | (number | null)[] | null;
            $nin: number | (number | null)[] | null;
        } & {}> | null | undefined;
        position?: {
            x: number;
            y: number;
        } | Partial<{
            $gt: {
                x: number;
                y: number;
            };
            $gte: {
                x: number;
                y: number;
            };
            $lt: {
                x: number;
                y: number;
            };
            $lte: {
                x: number;
                y: number;
            };
            $ne: {
                x: number;
                y: number;
            };
            $in: {
                x: number;
                y: number;
            } | {
                x: number;
                y: number;
            }[];
            $nin: {
                x: number;
                y: number;
            } | {
                x: number;
                y: number;
            }[];
        } & {}> | undefined;
        parentId?: string | Partial<{
            $gt?: string | null | undefined;
            $gte?: string | null | undefined;
            $lt?: string | null | undefined;
            $lte?: string | null | undefined;
            $ne?: string | null | undefined;
            $in: string | (string | null)[] | null;
            $nin: string | (string | null)[] | null;
        } & {}> | null | undefined;
        modelsVersionsId?: string | Partial<{
            $gt: string;
            $gte: string;
            $lt: string;
            $lte: string;
            $ne: string;
            $in: string | string[];
            $nin: string | string[];
        } & {}> | undefined;
        isParameter?: boolean | Partial<{
            $gt: boolean;
            $gte: boolean;
            $lt: boolean;
            $lte: boolean;
            $ne: boolean;
            $in: boolean | boolean[];
            $nin: boolean | boolean[];
        } & {}> | undefined;
        isOutputParameter?: boolean | Partial<{
            $gt: boolean;
            $gte: boolean;
            $lt: boolean;
            $lte: boolean;
            $ne: boolean;
            $in: boolean | boolean[];
            $nin: boolean | boolean[];
        } & {}> | undefined;
        ghostParentId?: string | Partial<{
            $gt?: string | null | undefined;
            $gte?: string | null | undefined;
            $lt?: string | null | undefined;
            $lte?: string | null | undefined;
            $ne?: string | null | undefined;
            $in: string | (string | null)[] | null;
            $nin: string | (string | null)[] | null;
        } & {}> | null | undefined;
    }[];
}> & {
    name?: string | Partial<{
        $gt?: string | null | undefined;
        $gte?: string | null | undefined;
        $lt?: string | null | undefined;
        $lte?: string | null | undefined;
        $ne?: string | null | undefined;
        $in: string | (string | null)[] | null;
        $nin: string | (string | null)[] | null;
    } & {}> | null | undefined;
    type?: NodeType | Partial<{
        $gt: NodeType;
        $gte: NodeType;
        $lt: NodeType;
        $lte: NodeType;
        $ne: NodeType;
        $in: NodeType | NodeType[];
        $nin: NodeType | NodeType[];
    } & {}> | undefined;
    data?: ({
        value?: string | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
    } & {
        type?: StockTypeType | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        initial?: string | undefined;
        delay?: string | undefined;
        nonNegative?: boolean | undefined;
    } & {
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        nonNegative?: boolean | undefined;
        rate?: string | undefined;
    } & {
        values?: {
            x: number;
            y: number;
        }[] | undefined;
        units?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        interpolation?: "Linear" | "Discrete" | undefined;
    } & {
        startActive?: string | undefined;
        residency?: string | undefined;
    } & {
        repeat?: boolean | undefined;
        value?: string | undefined;
        action?: string | undefined;
        recalculate?: boolean | undefined;
        trigger?: TriggerType | undefined;
    } & {
        repeat?: boolean | undefined;
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        value?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        recalculate?: boolean | undefined;
        trigger?: TriggerType | undefined;
    } & {
        populationSize?: number | undefined;
        geoUnits?: string | undefined;
        geoWidth?: string | undefined;
        geoHeight?: string | undefined;
        geoWrapAround?: boolean | undefined;
        geoPlacementType?: PlacementType | undefined;
        geoPlacementFunction?: string | undefined;
        networkType?: NetworkType | undefined;
        networkFunction?: string | undefined;
    } & {
        query?: {
            offset?: number | undefined;
            properties?: string[] | undefined;
            limit?: number | undefined;
            skipGeometry?: boolean | undefined;
            propertyFilters?: Record<string, {
                operator?: string | undefined;
                value: string;
            }> | undefined;
        } | undefined;
        apiId?: string | undefined;
        collectionId?: string | undefined;
        dataTransform?: {
            keyProperty?: string | undefined;
            valueProperties?: string[] | undefined;
        } | undefined;
    } & {
        modelId?: string | undefined;
        modelVersionId?: string | undefined;
        importedFolderId?: string | undefined;
    }) | Partial<{
        $gt: {
            value?: string | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
        } & {
            type?: StockTypeType | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            initial?: string | undefined;
            delay?: string | undefined;
            nonNegative?: boolean | undefined;
        } & {
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            nonNegative?: boolean | undefined;
            rate?: string | undefined;
        } & {
            values?: {
                x: number;
                y: number;
            }[] | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            interpolation?: "Linear" | "Discrete" | undefined;
        } & {
            startActive?: string | undefined;
            residency?: string | undefined;
        } & {
            repeat?: boolean | undefined;
            value?: string | undefined;
            action?: string | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            repeat?: boolean | undefined;
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            value?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            populationSize?: number | undefined;
            geoUnits?: string | undefined;
            geoWidth?: string | undefined;
            geoHeight?: string | undefined;
            geoWrapAround?: boolean | undefined;
            geoPlacementType?: PlacementType | undefined;
            geoPlacementFunction?: string | undefined;
            networkType?: NetworkType | undefined;
            networkFunction?: string | undefined;
        } & {
            query?: {
                offset?: number | undefined;
                properties?: string[] | undefined;
                limit?: number | undefined;
                skipGeometry?: boolean | undefined;
                propertyFilters?: Record<string, {
                    operator?: string | undefined;
                    value: string;
                }> | undefined;
            } | undefined;
            apiId?: string | undefined;
            collectionId?: string | undefined;
            dataTransform?: {
                keyProperty?: string | undefined;
                valueProperties?: string[] | undefined;
            } | undefined;
        } & {
            modelId?: string | undefined;
            modelVersionId?: string | undefined;
            importedFolderId?: string | undefined;
        };
        $gte: {
            value?: string | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
        } & {
            type?: StockTypeType | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            initial?: string | undefined;
            delay?: string | undefined;
            nonNegative?: boolean | undefined;
        } & {
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            nonNegative?: boolean | undefined;
            rate?: string | undefined;
        } & {
            values?: {
                x: number;
                y: number;
            }[] | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            interpolation?: "Linear" | "Discrete" | undefined;
        } & {
            startActive?: string | undefined;
            residency?: string | undefined;
        } & {
            repeat?: boolean | undefined;
            value?: string | undefined;
            action?: string | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            repeat?: boolean | undefined;
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            value?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            populationSize?: number | undefined;
            geoUnits?: string | undefined;
            geoWidth?: string | undefined;
            geoHeight?: string | undefined;
            geoWrapAround?: boolean | undefined;
            geoPlacementType?: PlacementType | undefined;
            geoPlacementFunction?: string | undefined;
            networkType?: NetworkType | undefined;
            networkFunction?: string | undefined;
        } & {
            query?: {
                offset?: number | undefined;
                properties?: string[] | undefined;
                limit?: number | undefined;
                skipGeometry?: boolean | undefined;
                propertyFilters?: Record<string, {
                    operator?: string | undefined;
                    value: string;
                }> | undefined;
            } | undefined;
            apiId?: string | undefined;
            collectionId?: string | undefined;
            dataTransform?: {
                keyProperty?: string | undefined;
                valueProperties?: string[] | undefined;
            } | undefined;
        } & {
            modelId?: string | undefined;
            modelVersionId?: string | undefined;
            importedFolderId?: string | undefined;
        };
        $lt: {
            value?: string | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
        } & {
            type?: StockTypeType | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            initial?: string | undefined;
            delay?: string | undefined;
            nonNegative?: boolean | undefined;
        } & {
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            nonNegative?: boolean | undefined;
            rate?: string | undefined;
        } & {
            values?: {
                x: number;
                y: number;
            }[] | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            interpolation?: "Linear" | "Discrete" | undefined;
        } & {
            startActive?: string | undefined;
            residency?: string | undefined;
        } & {
            repeat?: boolean | undefined;
            value?: string | undefined;
            action?: string | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            repeat?: boolean | undefined;
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            value?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            populationSize?: number | undefined;
            geoUnits?: string | undefined;
            geoWidth?: string | undefined;
            geoHeight?: string | undefined;
            geoWrapAround?: boolean | undefined;
            geoPlacementType?: PlacementType | undefined;
            geoPlacementFunction?: string | undefined;
            networkType?: NetworkType | undefined;
            networkFunction?: string | undefined;
        } & {
            query?: {
                offset?: number | undefined;
                properties?: string[] | undefined;
                limit?: number | undefined;
                skipGeometry?: boolean | undefined;
                propertyFilters?: Record<string, {
                    operator?: string | undefined;
                    value: string;
                }> | undefined;
            } | undefined;
            apiId?: string | undefined;
            collectionId?: string | undefined;
            dataTransform?: {
                keyProperty?: string | undefined;
                valueProperties?: string[] | undefined;
            } | undefined;
        } & {
            modelId?: string | undefined;
            modelVersionId?: string | undefined;
            importedFolderId?: string | undefined;
        };
        $lte: {
            value?: string | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
        } & {
            type?: StockTypeType | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            initial?: string | undefined;
            delay?: string | undefined;
            nonNegative?: boolean | undefined;
        } & {
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            nonNegative?: boolean | undefined;
            rate?: string | undefined;
        } & {
            values?: {
                x: number;
                y: number;
            }[] | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            interpolation?: "Linear" | "Discrete" | undefined;
        } & {
            startActive?: string | undefined;
            residency?: string | undefined;
        } & {
            repeat?: boolean | undefined;
            value?: string | undefined;
            action?: string | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            repeat?: boolean | undefined;
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            value?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            populationSize?: number | undefined;
            geoUnits?: string | undefined;
            geoWidth?: string | undefined;
            geoHeight?: string | undefined;
            geoWrapAround?: boolean | undefined;
            geoPlacementType?: PlacementType | undefined;
            geoPlacementFunction?: string | undefined;
            networkType?: NetworkType | undefined;
            networkFunction?: string | undefined;
        } & {
            query?: {
                offset?: number | undefined;
                properties?: string[] | undefined;
                limit?: number | undefined;
                skipGeometry?: boolean | undefined;
                propertyFilters?: Record<string, {
                    operator?: string | undefined;
                    value: string;
                }> | undefined;
            } | undefined;
            apiId?: string | undefined;
            collectionId?: string | undefined;
            dataTransform?: {
                keyProperty?: string | undefined;
                valueProperties?: string[] | undefined;
            } | undefined;
        } & {
            modelId?: string | undefined;
            modelVersionId?: string | undefined;
            importedFolderId?: string | undefined;
        };
        $ne: {
            value?: string | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
        } & {
            type?: StockTypeType | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            initial?: string | undefined;
            delay?: string | undefined;
            nonNegative?: boolean | undefined;
        } & {
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            nonNegative?: boolean | undefined;
            rate?: string | undefined;
        } & {
            values?: {
                x: number;
                y: number;
            }[] | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            interpolation?: "Linear" | "Discrete" | undefined;
        } & {
            startActive?: string | undefined;
            residency?: string | undefined;
        } & {
            repeat?: boolean | undefined;
            value?: string | undefined;
            action?: string | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            repeat?: boolean | undefined;
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            value?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            populationSize?: number | undefined;
            geoUnits?: string | undefined;
            geoWidth?: string | undefined;
            geoHeight?: string | undefined;
            geoWrapAround?: boolean | undefined;
            geoPlacementType?: PlacementType | undefined;
            geoPlacementFunction?: string | undefined;
            networkType?: NetworkType | undefined;
            networkFunction?: string | undefined;
        } & {
            query?: {
                offset?: number | undefined;
                properties?: string[] | undefined;
                limit?: number | undefined;
                skipGeometry?: boolean | undefined;
                propertyFilters?: Record<string, {
                    operator?: string | undefined;
                    value: string;
                }> | undefined;
            } | undefined;
            apiId?: string | undefined;
            collectionId?: string | undefined;
            dataTransform?: {
                keyProperty?: string | undefined;
                valueProperties?: string[] | undefined;
            } | undefined;
        } & {
            modelId?: string | undefined;
            modelVersionId?: string | undefined;
            importedFolderId?: string | undefined;
        };
        $in: ({
            value?: string | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
        } & {
            type?: StockTypeType | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            initial?: string | undefined;
            delay?: string | undefined;
            nonNegative?: boolean | undefined;
        } & {
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            nonNegative?: boolean | undefined;
            rate?: string | undefined;
        } & {
            values?: {
                x: number;
                y: number;
            }[] | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            interpolation?: "Linear" | "Discrete" | undefined;
        } & {
            startActive?: string | undefined;
            residency?: string | undefined;
        } & {
            repeat?: boolean | undefined;
            value?: string | undefined;
            action?: string | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            repeat?: boolean | undefined;
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            value?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            populationSize?: number | undefined;
            geoUnits?: string | undefined;
            geoWidth?: string | undefined;
            geoHeight?: string | undefined;
            geoWrapAround?: boolean | undefined;
            geoPlacementType?: PlacementType | undefined;
            geoPlacementFunction?: string | undefined;
            networkType?: NetworkType | undefined;
            networkFunction?: string | undefined;
        } & {
            query?: {
                offset?: number | undefined;
                properties?: string[] | undefined;
                limit?: number | undefined;
                skipGeometry?: boolean | undefined;
                propertyFilters?: Record<string, {
                    operator?: string | undefined;
                    value: string;
                }> | undefined;
            } | undefined;
            apiId?: string | undefined;
            collectionId?: string | undefined;
            dataTransform?: {
                keyProperty?: string | undefined;
                valueProperties?: string[] | undefined;
            } | undefined;
        } & {
            modelId?: string | undefined;
            modelVersionId?: string | undefined;
            importedFolderId?: string | undefined;
        }) | ({
            value?: string | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
        } & {
            type?: StockTypeType | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            initial?: string | undefined;
            delay?: string | undefined;
            nonNegative?: boolean | undefined;
        } & {
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            nonNegative?: boolean | undefined;
            rate?: string | undefined;
        } & {
            values?: {
                x: number;
                y: number;
            }[] | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            interpolation?: "Linear" | "Discrete" | undefined;
        } & {
            startActive?: string | undefined;
            residency?: string | undefined;
        } & {
            repeat?: boolean | undefined;
            value?: string | undefined;
            action?: string | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            repeat?: boolean | undefined;
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            value?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            populationSize?: number | undefined;
            geoUnits?: string | undefined;
            geoWidth?: string | undefined;
            geoHeight?: string | undefined;
            geoWrapAround?: boolean | undefined;
            geoPlacementType?: PlacementType | undefined;
            geoPlacementFunction?: string | undefined;
            networkType?: NetworkType | undefined;
            networkFunction?: string | undefined;
        } & {
            query?: {
                offset?: number | undefined;
                properties?: string[] | undefined;
                limit?: number | undefined;
                skipGeometry?: boolean | undefined;
                propertyFilters?: Record<string, {
                    operator?: string | undefined;
                    value: string;
                }> | undefined;
            } | undefined;
            apiId?: string | undefined;
            collectionId?: string | undefined;
            dataTransform?: {
                keyProperty?: string | undefined;
                valueProperties?: string[] | undefined;
            } | undefined;
        } & {
            modelId?: string | undefined;
            modelVersionId?: string | undefined;
            importedFolderId?: string | undefined;
        })[];
        $nin: ({
            value?: string | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
        } & {
            type?: StockTypeType | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            initial?: string | undefined;
            delay?: string | undefined;
            nonNegative?: boolean | undefined;
        } & {
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            nonNegative?: boolean | undefined;
            rate?: string | undefined;
        } & {
            values?: {
                x: number;
                y: number;
            }[] | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            interpolation?: "Linear" | "Discrete" | undefined;
        } & {
            startActive?: string | undefined;
            residency?: string | undefined;
        } & {
            repeat?: boolean | undefined;
            value?: string | undefined;
            action?: string | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            repeat?: boolean | undefined;
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            value?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            populationSize?: number | undefined;
            geoUnits?: string | undefined;
            geoWidth?: string | undefined;
            geoHeight?: string | undefined;
            geoWrapAround?: boolean | undefined;
            geoPlacementType?: PlacementType | undefined;
            geoPlacementFunction?: string | undefined;
            networkType?: NetworkType | undefined;
            networkFunction?: string | undefined;
        } & {
            query?: {
                offset?: number | undefined;
                properties?: string[] | undefined;
                limit?: number | undefined;
                skipGeometry?: boolean | undefined;
                propertyFilters?: Record<string, {
                    operator?: string | undefined;
                    value: string;
                }> | undefined;
            } | undefined;
            apiId?: string | undefined;
            collectionId?: string | undefined;
            dataTransform?: {
                keyProperty?: string | undefined;
                valueProperties?: string[] | undefined;
            } | undefined;
        } & {
            modelId?: string | undefined;
            modelVersionId?: string | undefined;
            importedFolderId?: string | undefined;
        }) | ({
            value?: string | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
        } & {
            type?: StockTypeType | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            initial?: string | undefined;
            delay?: string | undefined;
            nonNegative?: boolean | undefined;
        } & {
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            nonNegative?: boolean | undefined;
            rate?: string | undefined;
        } & {
            values?: {
                x: number;
                y: number;
            }[] | undefined;
            units?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            interpolation?: "Linear" | "Discrete" | undefined;
        } & {
            startActive?: string | undefined;
            residency?: string | undefined;
        } & {
            repeat?: boolean | undefined;
            value?: string | undefined;
            action?: string | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            repeat?: boolean | undefined;
            direction?: "left" | "top" | "bottom" | "right" | undefined;
            value?: string | undefined;
            constraints?: Partial<{
                max?: number | undefined;
                min?: number | undefined;
            }> | undefined;
            recalculate?: boolean | undefined;
            trigger?: TriggerType | undefined;
        } & {
            populationSize?: number | undefined;
            geoUnits?: string | undefined;
            geoWidth?: string | undefined;
            geoHeight?: string | undefined;
            geoWrapAround?: boolean | undefined;
            geoPlacementType?: PlacementType | undefined;
            geoPlacementFunction?: string | undefined;
            networkType?: NetworkType | undefined;
            networkFunction?: string | undefined;
        } & {
            query?: {
                offset?: number | undefined;
                properties?: string[] | undefined;
                limit?: number | undefined;
                skipGeometry?: boolean | undefined;
                propertyFilters?: Record<string, {
                    operator?: string | undefined;
                    value: string;
                }> | undefined;
            } | undefined;
            apiId?: string | undefined;
            collectionId?: string | undefined;
            dataTransform?: {
                keyProperty?: string | undefined;
                valueProperties?: string[] | undefined;
            } | undefined;
        } & {
            modelId?: string | undefined;
            modelVersionId?: string | undefined;
            importedFolderId?: string | undefined;
        })[];
    } & {}> | undefined;
    id?: string | Partial<{
        $gt: string;
        $gte: string;
        $lt: string;
        $lte: string;
        $ne: string;
        $in: string | string[];
        $nin: string | string[];
    } & {}> | undefined;
    height?: number | Partial<{
        $gt?: number | null | undefined;
        $gte?: number | null | undefined;
        $lt?: number | null | undefined;
        $lte?: number | null | undefined;
        $ne?: number | null | undefined;
        $in: number | (number | null)[] | null;
        $nin: number | (number | null)[] | null;
    } & {}> | null | undefined;
    width?: number | Partial<{
        $gt?: number | null | undefined;
        $gte?: number | null | undefined;
        $lt?: number | null | undefined;
        $lte?: number | null | undefined;
        $ne?: number | null | undefined;
        $in: number | (number | null)[] | null;
        $nin: number | (number | null)[] | null;
    } & {}> | null | undefined;
    position?: {
        x: number;
        y: number;
    } | Partial<{
        $gt: {
            x: number;
            y: number;
        };
        $gte: {
            x: number;
            y: number;
        };
        $lt: {
            x: number;
            y: number;
        };
        $lte: {
            x: number;
            y: number;
        };
        $ne: {
            x: number;
            y: number;
        };
        $in: {
            x: number;
            y: number;
        } | {
            x: number;
            y: number;
        }[];
        $nin: {
            x: number;
            y: number;
        } | {
            x: number;
            y: number;
        }[];
    } & {}> | undefined;
    parentId?: string | Partial<{
        $gt?: string | null | undefined;
        $gte?: string | null | undefined;
        $lt?: string | null | undefined;
        $lte?: string | null | undefined;
        $ne?: string | null | undefined;
        $in: string | (string | null)[] | null;
        $nin: string | (string | null)[] | null;
    } & {}> | null | undefined;
    modelsVersionsId?: string | Partial<{
        $gt: string;
        $gte: string;
        $lt: string;
        $lte: string;
        $ne: string;
        $in: string | string[];
        $nin: string | string[];
    } & {}> | undefined;
    isParameter?: boolean | Partial<{
        $gt: boolean;
        $gte: boolean;
        $lt: boolean;
        $lte: boolean;
        $ne: boolean;
        $in: boolean | boolean[];
        $nin: boolean | boolean[];
    } & {}> | undefined;
    isOutputParameter?: boolean | Partial<{
        $gt: boolean;
        $gte: boolean;
        $lt: boolean;
        $lte: boolean;
        $ne: boolean;
        $in: boolean | boolean[];
        $nin: boolean | boolean[];
    } & {}> | undefined;
    ghostParentId?: string | Partial<{
        $gt?: string | null | undefined;
        $gte?: string | null | undefined;
        $lt?: string | null | undefined;
        $lte?: string | null | undefined;
        $ne?: string | null | undefined;
        $in: string | (string | null)[] | null;
        $nin: string | (string | null)[] | null;
    } & {}> | null | undefined;
} & {}, HookContext<NodesService<import("./nodes.class.js").NodesParams>>>;
