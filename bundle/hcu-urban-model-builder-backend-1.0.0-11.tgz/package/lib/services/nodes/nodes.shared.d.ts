import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client.js';
import type { Nodes, NodesData, NodesPatch, NodesQuery, NodesService } from './nodes.class.js';
export { Nodes, NodesData, NodesPatch, NodesQuery };
export declare enum NodeType {
    Stock = 0,
    Variable = 1,
    Flow = 2,
    Converter = 3,
    State = 4,
    Transition = 5,
    Action = 6,
    Population = 7,
    Agent = 8,
    Folder = 9,
    Ghost = 10,
    OgcApiFeatures = 11
}
export type NodesClientService = Pick<NodesService<Params<NodesQuery>>, (typeof nodesMethods)[number]>;
export declare const nodesPath = "nodes";
export declare const nodesMethods: Array<keyof NodesService>;
export declare const nodesClient: (client: ClientApplication) => void;
declare module '../../client.js' {
    interface ServiceTypes {
        [nodesPath]: NodesClientService;
    }
}
