import { AxiosInstance } from 'axios';
export type Feature = {
    id: number;
    type: 'Feature';
    geometry?: {
        type: string;
        coordinates: any;
    };
    properties: Record<string, any> | null;
};
type FeaturesResponse = {
    numberReturned: number;
    numberMatched: number;
    features: Feature[];
};
type Api = {
    id: string;
    title: string;
    description: string;
};
type Collection = {
    id: string;
    title: string;
};
type Property = {
    type?: string;
    title: string;
    format?: string;
    'x-ogc-role'?: string;
};
type PropertyFilter = {
    operator?: string;
    value: string;
};
type FilterQuery = {
    limit?: number;
    offset?: number;
    skipGeometry?: boolean;
    selectedProperties?: string[];
    properties?: string[];
    filter?: string;
    propertyFilters?: Record<string, PropertyFilter>;
    [key: string]: any;
};
export declare class OgcApiFeaturesClient {
    client: AxiosInstance;
    private propertiesSchemaCache;
    constructor();
    getApis(): Promise<Api[]>;
    getCollections(apiId: string): Promise<Collection[]>;
    fetchFeatures(apiId: string, collectionId: string, query?: FilterQuery): Promise<FeaturesResponse>;
    getQueryableProperties(apiId: string, collectionId: string): Promise<Record<string, Property>>;
    getPropertiesSchema(apiId: string, collectionId: string): Promise<Record<string, Property>>;
    /**
     * The API only accepts known query parameters and property names (unknown ones are rejected with 400).
     * Since the geometry is treated as a regular property, it has to be requested explicitly via `properties`.
     */
    private serializeFeatureQuery;
}
export declare function isGeometryProperty(property: Property): boolean;
export {};
