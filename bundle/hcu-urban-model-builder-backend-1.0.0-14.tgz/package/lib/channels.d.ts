import '@feathersjs/transport-commons';
import type { Application } from './declarations.js';
export declare const channels: (app: Application) => void;
