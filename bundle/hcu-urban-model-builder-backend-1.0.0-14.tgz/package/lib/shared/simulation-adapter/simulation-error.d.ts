import { FeathersError } from '@feathersjs/errors';
export declare class SimulationError extends FeathersError {
    constructor(message: string, data?: {
        nodeId: string | null;
        simulationErrorCode?: string;
    });
}
