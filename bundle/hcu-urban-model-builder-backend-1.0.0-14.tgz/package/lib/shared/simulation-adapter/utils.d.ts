import { Feature } from './ogc-api-features-client.js';
export declare const GEOMETRY_KEY = "__geometry__";
export declare function transformFeatures(features: Feature[], key?: string, value?: string[], pretty?: boolean): string;
export declare function transformData(data: Feature[], keyProperty?: string, valueProperties?: string[]): any[] | Record<string, any>;
export declare function toSimulationVectorString(json: any, pretty?: boolean): string;
