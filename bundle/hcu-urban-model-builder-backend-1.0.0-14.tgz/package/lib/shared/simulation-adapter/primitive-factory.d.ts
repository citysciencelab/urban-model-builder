import { Model } from 'simulation';
import { Nodes } from '../../client.js';
export declare const primitiveFactory: (model: Model, node: Nodes) => Promise<import("simulation/blocks").Stock | import("simulation/blocks").Variable | import("simulation/blocks").Flow | import("simulation/blocks").Converter | import("simulation/blocks").State | import("simulation/blocks").Transition | import("simulation/blocks").Action | import("simulation/blocks").Population | import("simulation/blocks").Agent | import("simulation/blocks").Folder>;
