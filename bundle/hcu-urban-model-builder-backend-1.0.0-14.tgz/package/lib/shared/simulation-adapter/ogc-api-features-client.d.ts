import { AxiosInstance } from 'axios';
export type Feature = {
    id: number;
    type: 'Feature';
    geometry?: {
        type: string;
        coordinates: any;
    };
    properties: Record<string, any> | null;
};
type FeaturesResponse = {
    numberReturned: number;
    numberMatched: number;
    features: Feature[];
};
type Api = {
    id: string;
    title: string;
    description: string;
};
type Collection = {
    id: string;
    title: string;
};
type Property = {
    type: string;
    title: string;
};
type PropertyFilter = {
    operator?: string;
    value: string;
};
type FilterQuery = {
    limit?: number;
    offset?: number;
    skipGeometry?: boolean;
    selectedProperties?: string[];
    propertyFilters?: Record<string, PropertyFilter>;
    [key: string]: any;
};
export declare class OgcApiFeaturesClient {
    client: AxiosInstance;
    constructor();
    getApis(): Promise<Api[]>;
    getCollections(apiId: string): Promise<Collection[]>;
    fetchFeatures(apiId: string, collectionId: string, query?: FilterQuery): Promise<FeaturesResponse>;
    getQueryableProperties(apiId: string, collectionId: string): Promise<Record<string, Property>>;
    getPropertiesSchema(apiId: string, collectionId: string): Promise<Record<string, Property>>;
    private serializeFeatureQuery;
}
export {};
