import type { Application } from '../declarations.js';
export declare const findAllNodes: (app: Application, modelsVersionsId: string) => Promise<{
    name?: string | null | undefined;
    height?: number | null | undefined;
    width?: number | null | undefined;
    description?: string | null | undefined;
    parentId?: string | null | undefined;
    parameterMin?: number | null | undefined;
    parameterMax?: number | null | undefined;
    parameterStep?: number | null | undefined;
    parameterType?: import("../client.js").ParameterTypes | null | undefined;
    parameterOptions?: {
        data: {
            value: number;
            label: string;
        }[];
    } | null | undefined;
    ghostParentId?: string | null | undefined;
    type: import("../client.js").NodeType;
    data: {
        value?: string | undefined;
        units?: string | undefined;
        chartColor?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
    } & {
        type?: import("simulation/types").StockTypeType | undefined;
        units?: string | undefined;
        chartColor?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        initial?: string | undefined;
        delay?: string | undefined;
        nonNegative?: boolean | undefined;
    } & {
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        units?: string | undefined;
        chartColor?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        nonNegative?: boolean | undefined;
        rate?: string | undefined;
    } & {
        values?: {
            x: number;
            y: number;
        }[] | undefined;
        units?: string | undefined;
        chartColor?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        interpolation?: "Linear" | "Discrete" | undefined;
    } & {
        startActive?: string | undefined;
        residency?: string | undefined;
    } & {
        repeat?: boolean | undefined;
        value?: string | undefined;
        action?: string | undefined;
        recalculate?: boolean | undefined;
        trigger?: import("simulation/types").TriggerType | undefined;
    } & {
        repeat?: boolean | undefined;
        direction?: "left" | "top" | "bottom" | "right" | undefined;
        value?: string | undefined;
        constraints?: Partial<{
            max?: number | undefined;
            min?: number | undefined;
        }> | undefined;
        recalculate?: boolean | undefined;
        trigger?: import("simulation/types").TriggerType | undefined;
    } & {
        populationSize?: number | undefined;
        geoUnits?: string | undefined;
        geoWidth?: string | undefined;
        geoHeight?: string | undefined;
        geoWrapAround?: boolean | undefined;
        geoPlacementType?: import("simulation/types").PlacementType | undefined;
        geoPlacementFunction?: string | undefined;
        networkType?: import("simulation/types").NetworkType | undefined;
        networkFunction?: string | undefined;
    } & {
        query?: {
            offset?: number | undefined;
            properties?: string[] | undefined;
            limit?: number | undefined;
            skipGeometry?: boolean | undefined;
            propertyFilters?: Record<string, {
                operator?: string | undefined;
                value: string;
            }> | undefined;
        } | undefined;
        apiId?: string | undefined;
        collectionId?: string | undefined;
        dataTransform?: {
            keyProperty?: string | undefined;
            valueProperties?: string[] | undefined;
        } | undefined;
    } & {
        modelId?: string | undefined;
        modelVersionId?: string | undefined;
        importedFolderId?: string | undefined;
        inputs?: {
            internalNodeId?: string | undefined;
            name: string;
            id: string;
            defaultValue: string;
        }[] | undefined;
        outputs?: {
            internalNodeId?: string | undefined;
            name: string;
            id: string;
        }[] | undefined;
        isSubModelInternal?: boolean | undefined;
        subModelInstanceId?: string | undefined;
        sourceNodeId?: string | undefined;
        isSubModelOutput?: boolean | undefined;
    } & {
        collapsed?: boolean | undefined;
    };
    id: string;
    position: {
        x: number;
        y: number;
    };
    modelsVersionsId: string;
    isParameter: boolean;
    isOutputParameter: boolean;
}[]>;
export declare const findAllEdges: (app: Application, modelsVersionsId: string) => Promise<{
    points?: {
        data: {
            id: string;
            x: number;
            y: number;
        }[];
    } | null | undefined;
    isReference?: boolean | undefined;
    type: import("../client.js").EdgeType;
    id: string;
    modelsVersionsId: string;
    sourceId: string;
    targetId: string;
    sourceHandle: string;
    targetHandle: string;
}[]>;
export declare const findAllScenarios: (app: Application, modelsVersionsId: string) => Promise<{
    updatedAt?: string | null | undefined;
    deletedAt?: string | null | undefined;
    name: string;
    id: string;
    modelsVersionsId: string;
    createdAt: string;
    isDefault: boolean;
}[]>;
export declare const findAllScenarioValues: (app: Application, scenariosId: string) => Promise<{
    updatedAt?: string | null | undefined;
    deletedAt?: string | null | undefined;
    id: string;
    value: number;
    nodesId: string;
    scenariosId: string;
    createdAt: string;
}[]>;
