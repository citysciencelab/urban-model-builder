import type { Knex } from 'knex';
import type { Application } from './declarations.js';
declare module './declarations.js' {
    interface Configuration {
        postgresqlClient: Knex;
    }
}
export declare const postgresql: (app: Application) => void;
