import { DefaultJobOptions, Job } from 'bullmq';
import { Logger } from 'winston';
import { JobQueueAdapter } from './base.js';
interface BullMqJobQueueAdapterConfig {
}
export declare class BullMqJobQueueAdapter extends JobQueueAdapter<BullMqJobQueueAdapterConfig> {
    private connection;
    private workers;
    readonly defaultJobOptions: DefaultJobOptions;
    constructor(logger: Logger, config: BullMqJobQueueAdapterConfig);
    start(): Promise<void>;
    stop(): Promise<void>;
    receive(queueName: string, callback: (data: any) => Promise<any>): Promise<void>;
    send(queueName: string, data: any): Promise<string | undefined>;
    schedule(queueName: string, cronPattern: string): Promise<void>;
    private unscheduleAllExceptForCurrentCron;
    private addNewJob;
    getJobs(queueName: string): Promise<Job[]>;
    getJob(queueName: string, jobId: string): Promise<any>;
}
export {};
