import { Logger } from 'winston';
export declare abstract class JobQueueAdapter<Config extends Record<string, any>> {
    protected logger: Logger;
    config: Config;
    constructor(logger: Logger, config: Config);
    abstract start(): Promise<void>;
    abstract stop(): Promise<void>;
    abstract receive(queueName: string, callback: (data: any) => Promise<any>): Promise<void>;
    abstract send(queueName: string, data: any): Promise<String | undefined>;
    abstract schedule(queueName: string, cronPattern: string): Promise<void>;
}
