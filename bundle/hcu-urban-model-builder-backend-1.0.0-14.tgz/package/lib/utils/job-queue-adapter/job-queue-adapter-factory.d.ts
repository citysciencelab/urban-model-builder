import { BullMqJobQueueAdapter } from './bullmq.js';
declare const adaptersMap: {
    bullmq: typeof BullMqJobQueueAdapter;
};
type AdaptersMap = typeof adaptersMap;
type AdapterNames = keyof AdaptersMap;
type Values = typeof adaptersMap[AdapterNames];
export default function jobQueueAdapterFactory<K extends AdapterNames, V extends InstanceType<Values>>(adapterName: K, logger: any, adapterConfig: V['config']): BullMqJobQueueAdapter;
export {};
