import { HookContext } from '../declarations.js';
export declare function ensureUserId(context: HookContext): any;
