import { Params } from '@feathersjs/feathers';
export declare function isServerCall(params?: Params): boolean;
