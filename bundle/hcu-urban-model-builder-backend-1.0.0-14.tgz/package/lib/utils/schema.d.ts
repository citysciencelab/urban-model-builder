import { TSchema } from '@feathersjs/typebox';
export declare const Nullable: <T extends TSchema>(schema: T) => import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, T]>>;
export declare const Literals: <T extends string>(...values: T[]) => import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<T>[]>;
