import { Application, ServiceTypes } from '../declarations.js';
export declare function touchParent<L extends keyof ServiceTypes, M extends keyof ServiceTypes>(app: Application, serviceName: keyof ServiceTypes, parentServiceName: L, foreignKey: string): void;
