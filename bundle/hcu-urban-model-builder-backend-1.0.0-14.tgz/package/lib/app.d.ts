import { type Application } from './declarations.js';
declare const app: Application;
export { app };
