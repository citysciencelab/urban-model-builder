import type { HookContext } from '../declarations.js';
export declare const permissionFilter: (context: HookContext) => Promise<HookContext | undefined>;
