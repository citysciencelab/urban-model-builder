import { HookContext } from '../declarations.js';
declare const _default: ({ skipForFind }?: {
    skipForFind?: boolean | undefined;
}) => (context: HookContext) => Promise<HookContext>;
export default _default;
