import type { HookContext } from '../declarations.js';
export declare const initModelsUsers: (context: HookContext) => Promise<void>;
