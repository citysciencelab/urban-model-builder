import type { HookContext, ServiceNamesWithGet } from '../declarations.ts';
import { Roles } from '../client.js';
export declare const checkModelPermission: (fkIdField: string, fkServiceName: ServiceNamesWithGet, minRole: Roles) => (context: HookContext) => Promise<HookContext | undefined>;
