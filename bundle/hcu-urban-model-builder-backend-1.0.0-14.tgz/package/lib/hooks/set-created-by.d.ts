import type { HookContext } from '../declarations.js';
export declare const setCreatedBy: (context: HookContext) => Promise<HookContext>;
