import type { HookContext, ServiceNamesWithGet } from '../declarations.js';
export declare const checkModelVersionState: (fkIdField: string, fkServiceName: ServiceNamesWithGet) => (context: HookContext) => Promise<void>;
