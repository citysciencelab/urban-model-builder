import { HookContext } from '../declarations.js';
import { Roles } from '../client.js';
export declare const addModelPermissionFilterQuery: (minRequiredRole: Roles) => (context: HookContext) => void;
