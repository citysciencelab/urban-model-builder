import { HookContext, NextFunction, ServiceTypes } from '../../declarations.js';
export declare function emitRemovedEventsForCascadingRemove(): (context: HookContext<ServiceTypes["nodes"]>, next: NextFunction) => Promise<void>;
