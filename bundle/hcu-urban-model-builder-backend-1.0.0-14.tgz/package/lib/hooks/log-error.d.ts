import type { HookContext, NextFunction } from '../declarations.js';
export declare const logError: (context: HookContext, next: NextFunction) => Promise<void>;
