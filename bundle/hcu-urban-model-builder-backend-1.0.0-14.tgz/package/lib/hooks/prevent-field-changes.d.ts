import { type HookContext } from '../declarations.js';
/**
 * Rejects a patch that changes one of `fields`. The permission and version
 * state checks look at the record as it was before the patch, so a field they
 * depend on (e.g. which scenario a value belongs to) must not be moved by it.
 * Sending the unchanged value is fine, since the client sends whole records.
 */
export declare const preventFieldChanges: (fields: string[]) => (context: HookContext) => Promise<void>;
