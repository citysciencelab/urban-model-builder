import { HookContext, NextFunction } from '../declarations.js';
export declare const errorHandler: (context: HookContext, next: NextFunction) => Promise<void>;
