import type { HookContext } from '../../declarations.ts';
export declare const checkScenarioValueModelVersionState: (scenarioIdField: string) => (context: HookContext) => Promise<void>;
