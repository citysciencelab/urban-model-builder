import { HookContext } from '../../declarations.js';
import { Roles } from '../../client.js';
import { ScenarioValuesService } from '../../services/scenarios-values/scenarios-values.class.js';
export declare const addScenarioValuesModelPermissionFilterQuery: (minRequiredRole: Roles) => (context: HookContext<ScenarioValuesService>) => void;
