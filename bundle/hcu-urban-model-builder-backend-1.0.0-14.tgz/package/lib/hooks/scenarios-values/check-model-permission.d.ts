import type { HookContext } from '../../declarations.ts';
import { Roles } from '../../client.js';
export declare const checkScenarioValuePermission: (scenarioIdField: string, minRole: Roles, namedScenarioMinRole?: Roles) => (context: HookContext) => Promise<void>;
