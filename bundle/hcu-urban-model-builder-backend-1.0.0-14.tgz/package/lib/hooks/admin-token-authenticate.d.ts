import type { HookContext } from '../declarations.js';
export declare const adminTokenAuthenticate: (context: HookContext) => Promise<HookContext>;
