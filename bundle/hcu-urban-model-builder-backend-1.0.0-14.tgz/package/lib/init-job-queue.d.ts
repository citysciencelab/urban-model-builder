import { Application } from './declarations.js';
export default function (app: Application): Promise<void>;
