import type { Paginated, Params } from '@feathersjs/feathers';
import type { Application } from '../../../declarations.js';
import type { AdminPublicModelVersions, AdminPublicModelVersionsQuery } from './public-model-versions.schema.js';
export type { AdminPublicModelVersions, AdminPublicModelVersionsQuery };
export interface AdminPublicModelVersionsServiceOptions {
    app: Application;
}
export interface AdminPublicModelVersionsParams extends Params<AdminPublicModelVersionsQuery> {
}
export declare class AdminPublicModelVersionsService {
    options: AdminPublicModelVersionsServiceOptions;
    private app;
    constructor(options: AdminPublicModelVersionsServiceOptions);
    find(params?: AdminPublicModelVersionsParams): Promise<Paginated<AdminPublicModelVersions>>;
}
export declare const getOptions: (app: Application) => {
    app: Application;
};
