import type { Application } from '../../../../declarations.js';
import { AdminPublicModelVersionsUnapproveService } from './unapprove.class.js';
import { adminPublicModelVersionsUnapprovePath } from './unapprove.shared.js';
export * from './unapprove.class.js';
export * from './unapprove.schema.js';
export declare const adminPublicModelVersionsUnapprove: (app: Application) => void;
declare module '../../../../declarations.js' {
    interface ServiceTypes {
        [adminPublicModelVersionsUnapprovePath]: AdminPublicModelVersionsUnapproveService;
    }
}
