import type { ClientApplication } from '../../../../client.js';
import type { AdminPublicModelVersionsUnapprove, AdminPublicModelVersionsUnapprovePatch, AdminPublicModelVersionsUnapproveQuery, AdminPublicModelVersionsUnapproveService } from './unapprove.class.js';
export type { AdminPublicModelVersionsUnapprove, AdminPublicModelVersionsUnapprovePatch, AdminPublicModelVersionsUnapproveQuery };
export type AdminPublicModelVersionsUnapproveClientService = Pick<AdminPublicModelVersionsUnapproveService, (typeof adminPublicModelVersionsUnapproveMethods)[number]>;
export declare const adminPublicModelVersionsUnapprovePath = "admin/public-model-versions/unapprove";
export declare const adminPublicModelVersionsUnapproveMethods: Array<keyof AdminPublicModelVersionsUnapproveService>;
export declare const adminPublicModelVersionsUnapproveClient: (client: ClientApplication) => void;
declare module '../../../../client.js' {
    interface ServiceTypes {
        [adminPublicModelVersionsUnapprovePath]: AdminPublicModelVersionsUnapproveClientService;
    }
}
