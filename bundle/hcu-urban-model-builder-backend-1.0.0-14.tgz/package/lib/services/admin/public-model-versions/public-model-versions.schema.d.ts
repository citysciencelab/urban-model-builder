import type { Static } from '@feathersjs/typebox';
import type { HookContext } from '../../../declarations.js';
import type { AdminPublicModelVersionsService } from './public-model-versions.class.js';
export declare const adminPublicModelVersionsSchema: import("@sinclair/typebox").TOmit<import("@sinclair/typebox").TObject<{
    id: import("@sinclair/typebox").TString<string>;
    modelId: import("@sinclair/typebox").TString<"uuid">;
    parentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
    majorVersion: import("@sinclair/typebox").TNumber;
    minorVersion: import("@sinclair/typebox").TNumber;
    draftVersion: import("@sinclair/typebox").TNumber;
    notes: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    timeUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months">[]>]>>;
    timeStart: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    timeLength: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    timeStep: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    isLatest: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TBoolean]>>;
    algorithm: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<import("simulation").AlgorithmType>[]>]>>;
    globals: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    customUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TObject<{
        data: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
    }>]>>;
    createdBy: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
    publishedBy: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
    publishedAt: import("@sinclair/typebox").TString<"date-time">;
    createdAt: import("@sinclair/typebox").TString<"date-time">;
    updatedAt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
    deletedAt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
    role: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    publishedToUMPAt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
    publishedToUMPApprovedAt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
}>, []>;
export type AdminPublicModelVersions = Static<typeof adminPublicModelVersionsSchema>;
export declare const adminPublicModelVersionsValidator: import("@feathersjs/schema").Validator<any, any>;
export declare const adminPublicModelVersionsResolver: import("@feathersjs/schema").Resolver<Omit<{
    role?: number | null | undefined;
    algorithm?: import("simulation").AlgorithmType | null | undefined;
    parentId?: string | null | undefined;
    updatedAt?: string | null | undefined;
    deletedAt?: string | null | undefined;
    notes?: string | null | undefined;
    timeUnits?: "Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months" | null | undefined;
    timeStart?: number | null | undefined;
    timeLength?: number | null | undefined;
    timeStep?: number | null | undefined;
    isLatest?: boolean | null | undefined;
    globals?: string | null | undefined;
    customUnits?: {
        data: Record<string, string[]>;
    } | null | undefined;
    createdBy?: string | null | undefined;
    publishedBy?: string | null | undefined;
    publishedToUMPAt?: string | null | undefined;
    publishedToUMPApprovedAt?: string | null | undefined;
    id: string;
    modelId: string;
    createdAt: string;
    majorVersion: number;
    minorVersion: number;
    draftVersion: number;
    publishedAt: string;
}, never>, HookContext<AdminPublicModelVersionsService>>;
export declare const adminPublicModelVersionsExternalResolver: import("@feathersjs/schema").Resolver<Omit<{
    role?: number | null | undefined;
    algorithm?: import("simulation").AlgorithmType | null | undefined;
    parentId?: string | null | undefined;
    updatedAt?: string | null | undefined;
    deletedAt?: string | null | undefined;
    notes?: string | null | undefined;
    timeUnits?: "Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months" | null | undefined;
    timeStart?: number | null | undefined;
    timeLength?: number | null | undefined;
    timeStep?: number | null | undefined;
    isLatest?: boolean | null | undefined;
    globals?: string | null | undefined;
    customUnits?: {
        data: Record<string, string[]>;
    } | null | undefined;
    createdBy?: string | null | undefined;
    publishedBy?: string | null | undefined;
    publishedToUMPAt?: string | null | undefined;
    publishedToUMPApprovedAt?: string | null | undefined;
    id: string;
    modelId: string;
    createdAt: string;
    majorVersion: number;
    minorVersion: number;
    draftVersion: number;
    publishedAt: string;
}, never>, HookContext<AdminPublicModelVersionsService>>;
export declare const adminPublicModelVersionsQueryProperties: import("@sinclair/typebox").TPick<import("@sinclair/typebox").TOmit<import("@sinclair/typebox").TObject<{
    id: import("@sinclair/typebox").TString<string>;
    modelId: import("@sinclair/typebox").TString<"uuid">;
    parentId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
    majorVersion: import("@sinclair/typebox").TNumber;
    minorVersion: import("@sinclair/typebox").TNumber;
    draftVersion: import("@sinclair/typebox").TNumber;
    notes: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    timeUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"Years" | "Weeks" | "Days" | "Hours" | "Minutes" | "Seconds" | "Months">[]>]>>;
    timeStart: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    timeLength: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    timeStep: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    isLatest: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TBoolean]>>;
    algorithm: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<import("simulation").AlgorithmType>[]>]>>;
    globals: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    customUnits: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TObject<{
        data: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString<string>, import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
    }>]>>;
    createdBy: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
    publishedBy: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"uuid">]>>;
    publishedAt: import("@sinclair/typebox").TString<"date-time">;
    createdAt: import("@sinclair/typebox").TString<"date-time">;
    updatedAt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
    deletedAt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
    role: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TNumber]>>;
    publishedToUMPAt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
    publishedToUMPApprovedAt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
}>, []>, ["publishedToUMPApprovedAt"]>;
export declare const adminPublicModelVersionsQuerySchema: import("@sinclair/typebox").TIntersect<[import("@sinclair/typebox").TIntersect<[import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TObject<{
    $limit: import("@sinclair/typebox").TNumber;
    $skip: import("@sinclair/typebox").TNumber;
    $sort: import("@sinclair/typebox").TObject<{
        publishedToUMPApprovedAt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
    }>;
    $select: import("@sinclair/typebox").TUnsafe<"publishedToUMPApprovedAt"[]>;
    $and: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        publishedToUMPApprovedAt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[import("@sinclair/typebox").TObject<{
            $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
            $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
            $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
            $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
            $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
            $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>>;
            $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>>;
        }>, import("@sinclair/typebox").TObject<{
            [key: string]: import("@sinclair/typebox").TSchema;
        } | undefined>]>>]>>;
    }>>, import("@sinclair/typebox").TObject<{
        $or: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
            publishedToUMPApprovedAt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[import("@sinclair/typebox").TObject<{
                $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
                $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
                $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
                $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
                $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
                $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>>;
                $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>>;
            }>, import("@sinclair/typebox").TObject<{
                [key: string]: import("@sinclair/typebox").TSchema;
            } | undefined>]>>]>>;
        }>>>;
    }>]>>;
    $or: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        publishedToUMPApprovedAt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[import("@sinclair/typebox").TObject<{
            $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
            $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
            $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
            $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
            $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
            $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>>;
            $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>>;
        }>, import("@sinclair/typebox").TObject<{
            [key: string]: import("@sinclair/typebox").TSchema;
        } | undefined>]>>]>>;
    }>>>;
}>>, import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
    publishedToUMPApprovedAt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TIntersect<[import("@sinclair/typebox").TObject<{
        $gt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
        $gte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
        $lt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
        $lte: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
        $ne: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>;
        $in: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>>;
        $nin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>> | import("@sinclair/typebox").TArray<import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<"date-time">]>>>;
    }>, import("@sinclair/typebox").TObject<{
        [key: string]: import("@sinclair/typebox").TSchema;
    } | undefined>]>>]>>;
}>>]>, import("@sinclair/typebox").TObject<{}>]>;
export type AdminPublicModelVersionsQuery = Static<typeof adminPublicModelVersionsQuerySchema>;
export declare const adminPublicModelVersionsQueryValidator: import("@feathersjs/schema").Validator<any, any>;
export declare const adminPublicModelVersionsQueryResolver: import("@feathersjs/schema").Resolver<Partial<{
    $limit: number;
    $skip: number;
    $sort: {
        publishedToUMPApprovedAt?: number | undefined;
    };
    $select: "publishedToUMPApprovedAt"[];
    $and: ({
        publishedToUMPApprovedAt?: string | Partial<{
            $gt?: string | null | undefined;
            $gte?: string | null | undefined;
            $lt?: string | null | undefined;
            $lte?: string | null | undefined;
            $ne?: string | null | undefined;
            $in: string | (string | null)[] | null;
            $nin: string | (string | null)[] | null;
        } & {}> | null | undefined;
    } | {
        $or: {
            publishedToUMPApprovedAt?: string | Partial<{
                $gt?: string | null | undefined;
                $gte?: string | null | undefined;
                $lt?: string | null | undefined;
                $lte?: string | null | undefined;
                $ne?: string | null | undefined;
                $in: string | (string | null)[] | null;
                $nin: string | (string | null)[] | null;
            } & {}> | null | undefined;
        }[];
    })[];
    $or: {
        publishedToUMPApprovedAt?: string | Partial<{
            $gt?: string | null | undefined;
            $gte?: string | null | undefined;
            $lt?: string | null | undefined;
            $lte?: string | null | undefined;
            $ne?: string | null | undefined;
            $in: string | (string | null)[] | null;
            $nin: string | (string | null)[] | null;
        } & {}> | null | undefined;
    }[];
}> & {
    publishedToUMPApprovedAt?: string | Partial<{
        $gt?: string | null | undefined;
        $gte?: string | null | undefined;
        $lt?: string | null | undefined;
        $lte?: string | null | undefined;
        $ne?: string | null | undefined;
        $in: string | (string | null)[] | null;
        $nin: string | (string | null)[] | null;
    } & {}> | null | undefined;
} & {}, HookContext<AdminPublicModelVersionsService>>;
