import type { ClientApplication } from '../../../client.js';
import type { AdminPublicModelVersions, AdminPublicModelVersionsQuery, AdminPublicModelVersionsService } from './public-model-versions.class.js';
export type { AdminPublicModelVersions, AdminPublicModelVersionsQuery };
export type AdminPublicModelVersionsClientService = Pick<AdminPublicModelVersionsService, (typeof adminPublicModelVersionsMethods)[number]>;
export declare const adminPublicModelVersionsPath = "admin/public-model-versions";
export declare const adminPublicModelVersionsMethods: Array<keyof AdminPublicModelVersionsService>;
export declare const adminPublicModelVersionsClient: (client: ClientApplication) => void;
declare module '../../../client.js' {
    interface ServiceTypes {
        [adminPublicModelVersionsPath]: AdminPublicModelVersionsClientService;
    }
}
