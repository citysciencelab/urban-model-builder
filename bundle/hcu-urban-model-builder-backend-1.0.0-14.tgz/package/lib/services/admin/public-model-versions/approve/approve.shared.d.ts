import type { ClientApplication } from '../../../../client.js';
import type { AdminPublicModelVersionsApprove, AdminPublicModelVersionsApprovePatch, AdminPublicModelVersionsApproveQuery, AdminPublicModelVersionsApproveService } from './approve.class.js';
export type { AdminPublicModelVersionsApprove, AdminPublicModelVersionsApprovePatch, AdminPublicModelVersionsApproveQuery };
export type AdminPublicModelVersionsApproveClientService = Pick<AdminPublicModelVersionsApproveService, (typeof adminPublicModelVersionsApproveMethods)[number]>;
export declare const adminPublicModelVersionsApprovePath = "admin/public-model-versions/approve";
export declare const adminPublicModelVersionsApproveMethods: Array<keyof AdminPublicModelVersionsApproveService>;
export declare const adminPublicModelVersionsApproveClient: (client: ClientApplication) => void;
declare module '../../../../client.js' {
    interface ServiceTypes {
        [adminPublicModelVersionsApprovePath]: AdminPublicModelVersionsApproveClientService;
    }
}
