import type { Application } from '../../../../declarations.js';
import { AdminPublicModelVersionsApproveService } from './approve.class.js';
import { adminPublicModelVersionsApprovePath } from './approve.shared.js';
export * from './approve.class.js';
export * from './approve.schema.js';
export declare const adminPublicModelVersionsApprove: (app: Application) => void;
declare module '../../../../declarations.js' {
    interface ServiceTypes {
        [adminPublicModelVersionsApprovePath]: AdminPublicModelVersionsApproveService;
    }
}
