import type { Application } from '../../../declarations.js';
import { AdminPublicModelVersionsService } from './public-model-versions.class.js';
import { adminPublicModelVersionsPath } from './public-model-versions.shared.js';
export * from './public-model-versions.class.js';
export * from './public-model-versions.schema.js';
export declare const adminPublicModelVersions: (app: Application) => void;
declare module '../../../declarations.js' {
    interface ServiceTypes {
        [adminPublicModelVersionsPath]: AdminPublicModelVersionsService;
    }
}
