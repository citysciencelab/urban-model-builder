import { type Application } from '../../declarations.js';
import { ScenariosService } from './scenarios.class.js';
import { scenariosPath } from './scenarios.shared.js';
export * from './scenarios.class.js';
export * from './scenarios.schema.js';
export declare const scenarios: (app: Application) => void;
declare module '../../declarations.js' {
    interface ServiceTypes {
        [scenariosPath]: ScenariosService;
    }
}
