import type { Params } from '@feathersjs/feathers';
import { KnexService } from '@feathersjs/knex';
import type { KnexAdapterParams, KnexAdapterOptions } from '@feathersjs/knex';
import type { Application } from '../../declarations.js';
import type { Scenarios, ScenariosData, ScenariosPatch, ScenariosQuery } from './scenarios.schema.js';
export type { Scenarios, ScenariosData, ScenariosPatch, ScenariosQuery };
export interface ScenariosParams extends KnexAdapterParams<ScenariosQuery> {
}
export declare class ScenariosService<ServiceParams extends Params = ScenariosParams> extends KnexService<Scenarios, ScenariosData, ScenariosParams, ScenariosPatch> {
    _findDefaultForModelVersion(modelsVersionsId: string): Promise<false | {
        updatedAt?: string | null | undefined;
        deletedAt?: string | null | undefined;
        name: string;
        id: string;
        modelsVersionsId: string;
        createdAt: string;
        isDefault: boolean;
    }>;
}
export declare const getOptions: (app: Application) => KnexAdapterOptions;
