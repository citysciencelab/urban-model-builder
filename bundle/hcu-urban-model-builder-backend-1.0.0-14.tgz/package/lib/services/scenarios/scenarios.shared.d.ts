import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client.js';
import type { Scenarios, ScenariosData, ScenariosPatch, ScenariosQuery, ScenariosService } from './scenarios.class.js';
export type { Scenarios, ScenariosData, ScenariosPatch, ScenariosQuery };
export type ScenariosClientService = Pick<ScenariosService<Params<ScenariosQuery>>, (typeof scenariosMethods)[number]>;
export declare const scenariosPath = "scenarios";
export declare const scenariosMethods: Array<keyof ScenariosService>;
export declare const scenariosClient: (client: ClientApplication) => void;
declare module '../../client.js' {
    interface ServiceTypes {
        [scenariosPath]: ScenariosClientService;
    }
}
