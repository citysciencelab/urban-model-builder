import type { Application } from '../../declarations.js';
import { ModelsUsersService } from './models-users.class.js';
import { modelsUsersPath } from './models-users.shared.js';
export * from './models-users.class.js';
export * from './models-users.schema.js';
export declare const modelsUsers: (app: Application) => void;
declare module '../../declarations.js' {
    interface ServiceTypes {
        [modelsUsersPath]: ModelsUsersService;
    }
}
