import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client.js';
import type { ModelsUsers, ModelsUsersData, ModelsUsersPatch, ModelsUsersQuery, ModelsUsersService } from './models-users.class.js';
export type { ModelsUsers, ModelsUsersData, ModelsUsersPatch, ModelsUsersQuery };
export type ModelsUsersClientService = Pick<ModelsUsersService<Params<ModelsUsersQuery>>, (typeof modelsUsersMethods)[number]>;
export declare const modelsUsersPath = "models-users";
export declare const modelsUsersMethods: Array<keyof ModelsUsersService>;
export declare const modelsUsersClient: (client: ClientApplication) => void;
declare module '../../client.js' {
    interface ServiceTypes {
        [modelsUsersPath]: ModelsUsersClientService;
    }
}
