import type { Params } from '@feathersjs/feathers';
import { KnexService } from '@feathersjs/knex';
import type { KnexAdapterParams, KnexAdapterOptions } from '@feathersjs/knex';
import type { Application } from '../../declarations.js';
import type { ModelsUsers, ModelsUsersData, ModelsUsersPatch, ModelsUsersQuery } from './models-users.schema.js';
export type { ModelsUsers, ModelsUsersData, ModelsUsersPatch, ModelsUsersQuery };
export interface ModelsUsersParams extends KnexAdapterParams<ModelsUsersQuery> {
}
export declare class ModelsUsersService<ServiceParams extends Params = ModelsUsersParams> extends KnexService<ModelsUsers, ModelsUsersData, ModelsUsersParams, ModelsUsersPatch> {
}
export declare const getOptions: (app: Application) => KnexAdapterOptions;
