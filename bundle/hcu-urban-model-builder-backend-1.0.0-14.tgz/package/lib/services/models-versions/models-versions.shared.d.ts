import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client.js';
import type { ModelsVersions, ModelsVersionsData, ModelsVersionsPatch, ModelsVersionsQuery, ModelsVersionsService } from './models-versions.class.js';
export type { ModelsVersions, ModelsVersionsData, ModelsVersionsPatch, ModelsVersionsQuery };
export type ModelsVersionsClientService = Pick<ModelsVersionsService<Params<ModelsVersionsQuery>>, (typeof modelsVersionsMethods)[number]>;
export declare const modelsVersionsPath = "models-versions";
export declare const modelsVersionsMethods: Array<keyof ModelsVersionsService>;
export declare const modelsVersionsClient: (client: ClientApplication) => void;
declare module '../../client.js' {
    interface ServiceTypes {
        [modelsVersionsPath]: ModelsVersionsClientService;
    }
}
