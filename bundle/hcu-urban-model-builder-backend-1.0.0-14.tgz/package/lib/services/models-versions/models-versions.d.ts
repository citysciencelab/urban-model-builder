import { type Application } from '../../declarations.js';
import { ModelsVersionsService } from './models-versions.class.js';
import { modelsVersionsPath } from './models-versions.shared.js';
export * from './models-versions.class.js';
export * from './models-versions.schema.js';
export declare const modelsVersions: (app: Application) => void;
declare module '../../declarations.js' {
    interface ServiceTypes {
        [modelsVersionsPath]: ModelsVersionsService;
    }
}
