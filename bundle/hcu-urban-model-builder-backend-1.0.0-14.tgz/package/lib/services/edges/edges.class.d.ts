import type { Params } from '@feathersjs/feathers';
import { KnexAdapterOptions, KnexAdapterParams, KnexService } from '@feathersjs/knex';
import type { Application } from '../../declarations.js';
import type { Edges, EdgesData, EdgesPatch, EdgesQuery } from './edges.schema.js';
export type { Edges, EdgesData, EdgesPatch, EdgesQuery };
export interface EdgesParams extends KnexAdapterParams<EdgesQuery> {
}
export declare class EdgesService<ServiceParams extends Params = EdgesParams> extends KnexService<Edges, EdgesData, ServiceParams, EdgesPatch> {
}
export declare const getOptions: (app: Application) => KnexAdapterOptions;
