import { type Application } from '../../declarations.js';
import { EdgesService } from './edges.class.js';
import { edgesPath } from './edges.shared.js';
export * from './edges.class.js';
export * from './edges.schema.js';
export declare const edges: (app: Application) => void;
declare module '../../declarations.js' {
    interface ServiceTypes {
        [edgesPath]: EdgesService;
    }
}
