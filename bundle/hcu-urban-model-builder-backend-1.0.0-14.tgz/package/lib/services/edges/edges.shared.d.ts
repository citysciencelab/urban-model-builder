import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client.js';
import type { Edges, EdgesData, EdgesPatch, EdgesQuery, EdgesService } from './edges.class.js';
export type { Edges, EdgesData, EdgesPatch, EdgesQuery };
export declare enum EdgeType {
    Link = 0,
    Flow = 1,
    Transition = 2,
    AgentPopulation = 3
}
export type EdgesClientService = Pick<EdgesService<Params<EdgesQuery>>, (typeof edgesMethods)[number]>;
export declare const edgesPath = "edges";
export declare const edgesMethods: Array<keyof EdgesService>;
export declare const edgesClient: (client: ClientApplication) => void;
declare module '../../client.js' {
    interface ServiceTypes {
        [edgesPath]: EdgesClientService;
    }
}
