import type { Static } from '@feathersjs/typebox';
import type { HookContext } from '../../../declarations.js';
import type { ProcessesService } from './processes.class.js';
export declare const processesSchema: import("@sinclair/typebox").TObject<{
    processes: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        id: import("@sinclair/typebox").TString<"uuid">;
        title: import("@sinclair/typebox").TString<string>;
        description: import("@sinclair/typebox").TString<string>;
        version: import("@sinclair/typebox").TString<string>;
        jobControlOptions: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>;
        links: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
            href: import("@sinclair/typebox").TString<string>;
        }>>;
    }>>;
    links: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        href: import("@sinclair/typebox").TString<string>;
    }>>;
}>;
export declare const processesDetailSchema: import("@sinclair/typebox").TObject<{
    inputs: import("@sinclair/typebox").TAny;
    outputs: import("@sinclair/typebox").TAny;
    links: import("@sinclair/typebox").TAny;
    id: import("@sinclair/typebox").TString<"uuid">;
    title: import("@sinclair/typebox").TString<string>;
    description: import("@sinclair/typebox").TString<string>;
    version: import("@sinclair/typebox").TString<string>;
    jobControlOptions: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>;
}>;
export type Processes = Static<typeof processesSchema>;
export type ProcessesDetails = Static<typeof processesDetailSchema>;
export declare const processesValidator: import("@feathersjs/schema").Validator<any, any>;
export declare const processesResolver: import("@feathersjs/schema").Resolver<{
    links: {
        href: string;
    }[];
    processes: {
        id: string;
        title: string;
        description: string;
        version: string;
        links: {
            href: string;
        }[];
        jobControlOptions: string[];
    }[];
}, HookContext<ProcessesService<import("./processes.class.js").ProcessesParams>>>;
export declare const processesExternalResolver: import("@feathersjs/schema").Resolver<{
    links: {
        href: string;
    }[];
    processes: {
        id: string;
        title: string;
        description: string;
        version: string;
        links: {
            href: string;
        }[];
        jobControlOptions: string[];
    }[];
}, HookContext<ProcessesService<import("./processes.class.js").ProcessesParams>>>;
