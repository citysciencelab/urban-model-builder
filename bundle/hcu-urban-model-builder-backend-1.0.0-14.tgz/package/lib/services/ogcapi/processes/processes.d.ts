import type { Application } from '../../../declarations.js';
import { ProcessesService } from './processes.class.js';
import { processesPath } from './processes.shared.js';
export * from './processes.class.js';
export * from './processes.schema.js';
export declare const processes: (app: Application) => void;
declare module '../../../declarations.js' {
    interface ServiceTypes {
        [processesPath]: ProcessesService;
    }
}
