import type { Params } from '@feathersjs/feathers';
import type { Application } from '../../../declarations.js';
import type { Processes, ProcessesDetails } from './processes.schema.js';
export type { Processes, ProcessesDetails };
export interface ProcessesServiceOptions {
    app: Application;
}
export interface ProcessesParams extends Params {
}
export declare class ProcessesService<ServiceParams extends ProcessesParams = ProcessesParams> {
    options: ProcessesServiceOptions;
    app: Application;
    constructor(options: ProcessesServiceOptions);
    find(_params?: ServiceParams): Promise<Processes>;
    get(id: string, _params?: ServiceParams): Promise<ProcessesDetails>;
}
export declare const getOptions: (app: Application) => {
    app: Application;
};
