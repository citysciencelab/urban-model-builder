import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../../client.js';
import type { Processes, ProcessesService } from './processes.class.js';
export type { Processes };
export type ProcessesClientService = Pick<ProcessesService<Params>, (typeof processesMethods)[number]>;
export declare const processesPath = "ogcapi/processes";
export declare const processesMethods: Array<keyof ProcessesService>;
export declare const processesClient: (client: ClientApplication) => void;
declare module '../../../client.js' {
    interface ServiceTypes {
        [processesPath]: ProcessesClientService;
    }
}
