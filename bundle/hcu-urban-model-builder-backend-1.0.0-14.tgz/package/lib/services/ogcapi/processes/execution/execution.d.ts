import type { Application } from '../../../../declarations.js';
import { ProcessesExecutionService } from './execution.class.js';
import { processesExecutionPath } from './execution.shared.js';
export * from './execution.class.js';
export declare const processesExecution: (app: Application) => void;
declare module '../../../../declarations.js' {
    interface ServiceTypes {
        [processesExecutionPath]: ProcessesExecutionService;
    }
}
