import type { Id, Params, ServiceInterface } from '@feathersjs/feathers';
import type { Application } from '../../../../declarations.js';
type ProcessesExecution = any;
type ProcessesExecutionData = Record<string, number>;
export type { ProcessesExecution, ProcessesExecutionData };
export interface ProcessesExecutionServiceOptions {
    app: Application;
}
export interface ProcessesExecutionParams extends Params {
}
export declare class ProcessesExecutionService<ServiceParams extends ProcessesExecutionParams = ProcessesExecutionParams> implements ServiceInterface<ProcessesExecution, ProcessesExecutionData, ServiceParams> {
    options: ProcessesExecutionServiceOptions;
    app: Application;
    constructor(options: ProcessesExecutionServiceOptions);
    protected getProcessId(params?: ServiceParams): string;
    get(id: Id, params?: ServiceParams): Promise<ProcessesExecution>;
    create(data: ProcessesExecutionData, params?: ServiceParams): Promise<ProcessesExecution>;
}
export declare const getOptions: (app: Application) => {
    app: Application;
};
