import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../../../client.js';
import type { ProcessesExecution, ProcessesExecutionData, ProcessesExecutionService } from './execution.class.js';
export type { ProcessesExecution, ProcessesExecutionData };
export type ProcessesExecutionClientService = Pick<ProcessesExecutionService<Params>, (typeof processesExecutionMethods)[number]>;
export declare const processesExecutionPath = "ogcapi/processes/:processId/execution";
export declare const processesExecutionMethods: Array<keyof ProcessesExecutionService>;
export declare const ogcapiProcessesExecutionClient: (client: ClientApplication) => void;
declare module '../../../../client.js' {
    interface ServiceTypes {
        [processesExecutionPath]: ProcessesExecutionClientService;
    }
}
