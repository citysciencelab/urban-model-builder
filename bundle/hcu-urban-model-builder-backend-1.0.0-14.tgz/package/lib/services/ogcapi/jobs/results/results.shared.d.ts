import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../../../client.js';
import type { JobResults, JobResultsData, JobResultsPatch, JobResultsQuery, JobResultsService } from './results.class.js';
export type { JobResults, JobResultsData, JobResultsPatch, JobResultsQuery };
export type JobResultsClientService = Pick<JobResultsService<Params<JobResultsQuery>>, (typeof resultsMethods)[number]>;
export declare const resultsPath = "ogcapi/jobs/:jobId/results";
export declare const resultsMethods: Array<keyof JobResultsService>;
export declare const resultsClient: (client: ClientApplication) => void;
declare module '../../../../client.js' {
    interface ServiceTypes {
        [resultsPath]: JobResultsClientService;
    }
}
