import type { Application } from '../../../../declarations.js';
import { JobResultsService } from './results.class.js';
import { resultsPath } from './results.shared.js';
export * from './results.class.js';
export declare const jobResults: (app: Application) => void;
declare module '../../../../declarations.js' {
    interface ServiceTypes {
        [resultsPath]: JobResultsService;
    }
}
