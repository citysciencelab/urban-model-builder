import type { Id, Params } from '@feathersjs/feathers';
import type { Application } from '../../../../declarations.js';
type JobResults = any;
type JobResultsData = any;
type JobResultsPatch = any;
type JobResultsQuery = any;
export type { JobResults, JobResultsData, JobResultsPatch, JobResultsQuery };
export interface JobResultsServiceOptions {
    app: Application;
}
export interface JobResultsParams extends Params<JobResultsQuery> {
}
export declare class JobResultsService<ServiceParams extends JobResultsParams = JobResultsParams> {
    options: JobResultsServiceOptions;
    constructor(options: JobResultsServiceOptions);
    protected getJobId(params?: ServiceParams): number;
    get(id: Id, params?: ServiceParams): Promise<JobResults>;
    find(_params?: ServiceParams): Promise<JobResults[]>;
}
export declare const getOptions: (app: Application) => {
    app: Application;
};
