import type { Application } from '../../../declarations.js';
import { JobsService } from './jobs.class.js';
import { jobsPath } from './jobs.shared.js';
export * from './jobs.class.js';
export declare const jobs: (app: Application) => void;
declare module '../../../declarations.js' {
    interface ServiceTypes {
        [jobsPath]: JobsService;
    }
}
