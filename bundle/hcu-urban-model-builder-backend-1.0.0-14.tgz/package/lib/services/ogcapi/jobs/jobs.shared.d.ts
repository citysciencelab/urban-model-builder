import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../../client.js';
import type { Jobs, JobsData, JobsPatch, JobsQuery, JobsService } from './jobs.class.js';
export type { Jobs, JobsData, JobsPatch, JobsQuery };
export type JobsClientService = Pick<JobsService<Params<JobsQuery>>, (typeof jobsMethods)[number]>;
export declare const jobsPath = "ogcapi/jobs";
export declare const jobsMethods: Array<keyof JobsService>;
export declare const jobsClient: (client: ClientApplication) => void;
declare module '../../../client.js' {
    interface ServiceTypes {
        [jobsPath]: JobsClientService;
    }
}
