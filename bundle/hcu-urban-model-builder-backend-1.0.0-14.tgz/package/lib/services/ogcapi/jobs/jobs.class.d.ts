import type { Params } from '@feathersjs/feathers';
import type { Application } from '../../../declarations.js';
type Jobs = any;
type JobsData = {
    jobs: any[];
    links: any[];
};
type JobsPatch = any;
type JobsQuery = any;
export type { Jobs, JobsData, JobsPatch, JobsQuery };
export interface JobsServiceOptions {
    app: Application;
}
export interface JobsParams extends Params<JobsQuery> {
}
export declare class JobsService<ServiceParams extends JobsParams = JobsParams> {
    options: JobsServiceOptions;
    constructor(options: JobsServiceOptions);
    private prepareJobData;
    private mapStatus;
    find(_params?: ServiceParams): Promise<JobsData>;
    get(id: Number, _params?: ServiceParams): Promise<Jobs>;
    remove(id: Number, _params?: ServiceParams): Promise<Jobs>;
}
export declare const getOptions: (app: Application) => {
    app: Application;
};
