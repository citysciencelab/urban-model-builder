import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client.js';
import type { Models, ModelsData, ModelsPatch, ModelsQuery, ModelsService } from './models.class.js';
export type { Models, ModelsData, ModelsPatch, ModelsQuery };
export type ModelsClientService = Pick<ModelsService<Params<ModelsQuery>>, (typeof modelsMethods)[number]>;
export declare const modelsPath = "models";
export declare const modelsMethods: Array<keyof ModelsService>;
export declare const modelsClient: (client: ClientApplication) => void;
declare module '../../client.js' {
    interface ServiceTypes {
        [modelsPath]: ModelsClientService;
    }
}
