import type { Application } from '../../declarations.js';
import { ModelsService } from './models.class.js';
import { modelsPath } from './models.shared.js';
export * from './models.class.js';
export * from './models.schema.js';
export declare const models: (app: Application) => void;
declare module '../../declarations.js' {
    interface ServiceTypes {
        [modelsPath]: ModelsService;
    }
}
