import type { HookContext } from '../../../declarations.js';
export declare const checkPublishPermissionsAndState: (context: HookContext) => Promise<void>;
