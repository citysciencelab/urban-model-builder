import type { HookContext } from '../../../declarations.js';
export declare const checkClonePermissionsAndState: (context: HookContext) => Promise<void>;
