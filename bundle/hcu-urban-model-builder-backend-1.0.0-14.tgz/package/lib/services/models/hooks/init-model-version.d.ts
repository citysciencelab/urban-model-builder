import { HookContext } from '../../../declarations.js';
export declare const initModelVersion: (context: HookContext) => Promise<HookContext>;
