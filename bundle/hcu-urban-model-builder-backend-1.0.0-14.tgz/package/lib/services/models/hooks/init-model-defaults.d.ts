import { HookContext } from '../../../declarations.js';
export declare const initModelDefaults: (context: HookContext) => Promise<HookContext>;
