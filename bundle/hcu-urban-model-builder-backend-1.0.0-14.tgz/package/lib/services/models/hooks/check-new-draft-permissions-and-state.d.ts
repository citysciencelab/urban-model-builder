import type { HookContext } from '../../../declarations.js';
export declare const checkNewDraftPermissionsAndState: (context: HookContext) => Promise<void>;
