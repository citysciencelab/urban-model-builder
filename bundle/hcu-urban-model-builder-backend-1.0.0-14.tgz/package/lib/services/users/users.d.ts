import type { Application } from '../../declarations.js';
import { UserService } from './users.class.js';
import { userPath } from './users.shared.js';
export * from './users.class.js';
export * from './users.schema.js';
export declare const user: (app: Application) => void;
declare module '../../declarations.js' {
    interface ServiceTypes {
        [userPath]: UserService;
    }
}
