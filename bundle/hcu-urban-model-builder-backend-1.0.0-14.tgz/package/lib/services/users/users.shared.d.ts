import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client.js';
import type { User, UserData, UserPatch, UserQuery, UserService } from './users.class.js';
export type { User, UserData, UserPatch, UserQuery };
export type UserClientService = Pick<UserService<Params<UserQuery>>, (typeof userMethods)[number]>;
export declare const userPath = "users";
export declare const userMethods: Array<keyof UserService>;
export declare const userClient: (client: ClientApplication) => void;
declare module '../../client.js' {
    interface ServiceTypes {
        [userPath]: UserClientService;
    }
}
