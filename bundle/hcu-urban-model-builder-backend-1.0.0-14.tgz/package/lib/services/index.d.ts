import type { Application } from '../declarations.js';
export declare const services: (app: Application) => void;
