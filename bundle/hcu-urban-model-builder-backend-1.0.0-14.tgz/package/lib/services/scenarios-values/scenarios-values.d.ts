import { type Application } from '../../declarations.js';
import { ScenarioValuesService } from './scenarios-values.class.js';
import { scenarioValuesPath } from './scenarios-values.shared.js';
export * from './scenarios-values.class.js';
export * from './scenarios-values.schema.js';
export declare const scenarioValues: (app: Application) => void;
declare module '../../declarations.js' {
    interface ServiceTypes {
        [scenarioValuesPath]: ScenarioValuesService;
    }
}
