import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client.js';
import type { ScenarioValues, ScenarioValuesData, ScenarioValuesPatch, ScenarioValuesQuery, ScenarioValuesService } from './scenarios-values.class.js';
export type { ScenarioValues, ScenarioValuesData, ScenarioValuesPatch, ScenarioValuesQuery };
export type ScenarioValuesClientService = Pick<ScenarioValuesService<Params<ScenarioValuesQuery>>, (typeof scenarioValuesMethods)[number]>;
export declare const scenarioValuesPath = "scenarios-values";
export declare const scenarioValuesMethods: Array<keyof ScenarioValuesService>;
export declare const scenarioValuesClient: (client: ClientApplication) => void;
declare module '../../client.js' {
    interface ServiceTypes {
        [scenarioValuesPath]: ScenarioValuesClientService;
    }
}
