import type { Params } from '@feathersjs/feathers';
import { KnexService } from '@feathersjs/knex';
import type { KnexAdapterParams, KnexAdapterOptions } from '@feathersjs/knex';
import type { Application } from '../../declarations.js';
import type { ScenarioValues, ScenarioValuesData, ScenarioValuesPatch, ScenarioValuesQuery } from './scenarios-values.schema.js';
export type { ScenarioValues, ScenarioValuesData, ScenarioValuesPatch, ScenarioValuesQuery };
export interface ScenarioValuesParams extends KnexAdapterParams<ScenarioValuesQuery> {
}
export declare class ScenarioValuesService<ServiceParams extends Params = ScenarioValuesParams> extends KnexService<ScenarioValues, ScenarioValuesData, ScenarioValuesParams, ScenarioValuesPatch> {
}
export declare const getOptions: (app: Application) => KnexAdapterOptions;
