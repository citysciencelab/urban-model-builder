import type { Params } from '@feathersjs/feathers';
import { KnexAdapterOptions, KnexAdapterParams, KnexService } from '@feathersjs/knex';
import type { Application } from '../../declarations.js';
import type { Nodes, NodesData, NodesPatch, NodesQuery } from './nodes.schema.js';
export type { Nodes, NodesData, NodesPatch, NodesQuery };
export interface NodesParams extends KnexAdapterParams<NodesQuery> {
}
export declare class NodesService<ServiceParams extends Params = NodesParams> extends KnexService<Nodes, NodesData, ServiceParams, NodesPatch> {
}
export declare const getOptions: (app: Application) => KnexAdapterOptions;
