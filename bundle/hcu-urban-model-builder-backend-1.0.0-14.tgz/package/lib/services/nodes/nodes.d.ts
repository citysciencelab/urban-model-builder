import { type Application } from '../../declarations.js';
import { NodesService } from './nodes.class.js';
import { nodesPath } from './nodes.shared.js';
export * from './nodes.class.js';
export * from './nodes.schema.js';
export declare const nodes: (app: Application) => void;
declare module '../../declarations.js' {
    interface ServiceTypes {
        [nodesPath]: NodesService;
    }
}
