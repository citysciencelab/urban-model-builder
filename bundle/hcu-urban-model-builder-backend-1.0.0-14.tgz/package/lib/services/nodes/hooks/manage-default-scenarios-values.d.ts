import { HookContext } from '../../../declarations.js';
export declare const manageDefaultScenariosValues: (context: HookContext) => Promise<void>;
