import { AuthenticationService } from '@feathersjs/authentication';
import type { Application } from './declarations.js';
declare module './declarations.js' {
    interface ServiceTypes {
        authentication: AuthenticationService;
    }
}
export declare const authentication: (app: Application) => void;
