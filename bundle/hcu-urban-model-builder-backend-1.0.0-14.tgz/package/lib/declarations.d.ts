import { HookContext as FeathersHookContext, NextFunction, ServiceMethods } from '@feathersjs/feathers';
import { Application as FeathersApplication } from '@feathersjs/koa';
import { ApplicationConfiguration } from './configuration.js';
import { User } from './services/users/users.js';
import { ServiceSwaggerOptions } from 'feathers-swagger';
export type { NextFunction };
export interface Configuration extends ApplicationConfiguration {
    jobQueue: any;
}
export interface ServiceTypes {
}
export type Application = FeathersApplication<ServiceTypes, Configuration>;
export type HookContext<S = any> = FeathersHookContext<Application, S> & {
    params?: {
        disableSoftDelete?: boolean;
        isDeleteRelated?: boolean;
        isFinalDelete?: boolean;
    };
};
declare module '@feathersjs/feathers' {
    interface Params {
        user?: User;
        isTouch?: Boolean;
    }
}
export declare const STASH_BEFORE_KEY = "stashBefore";
export type ServiceNamesWithGet = {
    [K in keyof ServiceTypes]: ServiceTypes[K] extends Pick<ServiceMethods<any>, 'get'> ? K : never;
}[keyof ServiceTypes];
declare module '@feathersjs/feathers' {
    interface ServiceOptions {
        docs?: ServiceSwaggerOptions;
    }
}
