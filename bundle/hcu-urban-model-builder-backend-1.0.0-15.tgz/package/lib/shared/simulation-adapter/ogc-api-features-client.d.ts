import { AxiosInstance } from 'axios';
export type Feature = {
    id: number;
    type: 'Feature';
    geometry?: {
        type: string;
        coordinates: any;
    };
    properties: Record<string, any> | null;
};
type FeaturesResponse = {
    numberReturned: number;
    numberMatched: number;
    features: Feature[];
};
type Api = {
    id: string;
    title: string;
    description: string;
};
type Collection = {
    id: string;
    title: string;
    name?: string;
    description?: string;
    itemCount?: number;
    [key: string]: any;
};
type Property = {
    type?: string;
    title: string;
    format?: string;
    'x-ogc-role'?: string;
};
type PropertyFilter = {
    operator?: string;
    value: string;
};
type FilterQuery = {
    limit?: number;
    offset?: number;
    skipGeometry?: boolean;
    selectedProperties?: string[];
    properties?: string[];
    filter?: string;
    propertyFilters?: Record<string, PropertyFilter>;
    [key: string]: any;
};
export declare class OgcApiFeaturesClient {
    client: AxiosInstance;
    private propertiesSchemaCache;
    private conformanceCache;
    constructor(baseURL?: string);
    getApis(): Promise<Api[]>;
    getCollections(apiId: string): Promise<Collection[]>;
    fetchFeatures(apiId: string, collectionId: string, query?: FilterQuery): Promise<FeaturesResponse>;
    getQueryableProperties(apiId: string, collectionId: string): Promise<Record<string, Property>>;
    getPropertiesSchema(apiId: string, collectionId: string): Promise<Record<string, Property>>;
    private fetchPropertiesSchema;
    private supportsPropertySelection;
    /**
     * Single API endpoints serve their collections from the root, multi API endpoints below the api id
     */
    private collectionsPath;
    private getSelectedProperties;
    /**
     * Servers may reject unknown query parameters and property names with 400, so only supported parameters are sent.
     * With property selection the geometry is treated as a regular property and has to be requested explicitly.
     */
    private serializeFeatureQuery;
}
export declare function isGeometryProperty(property: Property): boolean;
export {};
