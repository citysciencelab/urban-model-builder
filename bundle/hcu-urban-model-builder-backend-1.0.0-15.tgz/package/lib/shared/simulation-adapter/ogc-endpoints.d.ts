export type OgcApiType = 'multi-api' | 'single-api' | 'unknown';
export type OgcEndpoint = {
    id: string;
    name: string;
    baseUrl: string;
    isDefault: boolean;
    apiType?: OgcApiType;
};
export declare const DEFAULT_OGC_ENDPOINT: OgcEndpoint;
type OgcNodeEndpointData = {
    endpointId?: string;
    baseUrl?: string;
    apiType?: string;
};
/**
 * Resolves the endpoint of an OGC API Features node. The endpoint configured on the model version wins, the
 * endpoint copied to the node is used if it was removed from the model version. Nodes without any endpoint
 * information (created before endpoints were configurable or keeping the preselected endpoint) use the default.
 */
export declare function resolveOgcEndpoint(nodeData: OgcNodeEndpointData, ogcEndpoints?: OgcEndpoint[] | null): OgcEndpoint;
export declare function isSingleApiEndpoint(endpoint: OgcEndpoint): boolean;
export {};
