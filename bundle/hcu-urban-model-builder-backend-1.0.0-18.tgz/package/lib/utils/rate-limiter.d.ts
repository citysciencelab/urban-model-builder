import type { Application } from '../declarations.js';
/**
 * Registers one use of `name` by the user. Returns whether it is within the limit and, if not, after how
 * many seconds the next attempt can succeed.
 */
export declare function consumeRateLimit(app: Application, name: string, userId: string, limit: number, windowSeconds: number): Promise<{
    allowed: boolean;
    retryAfterSeconds: number;
}>;
