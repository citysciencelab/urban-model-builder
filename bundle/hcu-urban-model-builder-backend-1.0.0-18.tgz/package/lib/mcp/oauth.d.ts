import type { Middleware } from 'koa';
import type { Application } from '../declarations.js';
import type { User } from '../services/users/users.js';
/**
 * OAuth 2.1 for the MCP endpoint, as the MCP authorization specification requires it for clients that cannot
 * be given a personal access token (the connectors of claude.ai and ChatGPT).
 *
 * The backend is only the resource server. Keycloak, which already signs users in to the app, is the
 * authorization server: MCP clients find it through the protected resource metadata served here (RFC 9728),
 * register themselves there and send the access tokens they get to `/mcp`.
 *
 * A token is accepted only if Keycloak issued it for this endpoint: its audience has to be the MCP endpoint.
 * Keycloak adds that audience with the client scope configured as `mcp.oauth.scope` (see
 * scripts/keycloak-configure-mcp.mjs). Tokens of the web app do not have it, so they cannot be replayed here.
 */
export declare const PROTECTED_RESOURCE_METADATA_PATH = "/.well-known/oauth-protected-resource";
export declare function getOAuthSettings(app: Application): {
    issuer: string;
    scope: string;
    /** The identifier of the MCP endpoint as a protected resource, and the audience tokens must have. */
    resource: string;
    metadataUrl: string;
} | null;
/** Value of the WWW-Authenticate header that tells a client where and how to get a token. */
export declare function getChallenge(app: Application, error?: 'invalid_token' | 'insufficient_scope'): string;
/**
 * Serves the protected resource metadata, at the well-known path with and without the path of the MCP
 * endpoint appended, because clients look for either.
 */
export declare function protectedResourceMetadataMiddleware(app: Application): Middleware;
export declare class OAuthTokenError extends Error {
    reason: 'invalid_token' | 'insufficient_scope';
    constructor(reason: 'invalid_token' | 'insufficient_scope', message: string);
}
/**
 * Verifies an access token of the authorization server and returns the user it was issued for. The user is
 * created if they have never signed in to the app, as the web app's login does.
 */
export declare function resolveOAuthToken(app: Application, token: string): Promise<User>;
