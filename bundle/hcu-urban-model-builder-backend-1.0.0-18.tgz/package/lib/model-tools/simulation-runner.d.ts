import type { Application } from '../declarations.js';
import type { SimulationJob } from './simulation-worker.js';
/** Simulates a model version, given with its graph, and returns the result of the simulation adapter. */
export declare function runSimulation(app: Application, job: Omit<SimulationJob, 'id'>): Promise<any>;
