import type { ModelsVersions } from '../services/models-versions/models-versions.schema.js';
import { type OgcEndpoint } from '../shared/simulation-adapter/ogc-endpoints.js';
import type { Application } from '../declarations.js';
import { type ToolDefinition } from './types.js';
/**
 * Geodata for models: OGC API Features services.
 *
 * A model version lists the services ("endpoints") its OGC nodes may use; users manage that list in the
 * editor. On top of that the server has an allowlist of hosts (`ogc.allowedHosts`), because here it is the
 * server that sends the requests, and a language model decides what is requested. The tools only ever talk
 * to an endpoint of the version whose host is on the allowlist.
 */
export declare function isAllowedOgcUrl(app: Application, baseUrl: string): boolean;
export declare const getVersionEndpoints: (version: Pick<ModelsVersions, "ogcEndpoints">) => OgcEndpoint[];
/** The endpoint of the version with the given id, or its default endpoint; it has to be allowed. */
export declare function getAllowedEndpoint(app: Application, version: Pick<ModelsVersions, 'ogcEndpoints'>, endpointId?: string): OgcEndpoint;
export declare function assertAllowedEndpoint(app: Application, endpoint: Pick<OgcEndpoint, 'baseUrl'>): void;
/**
 * Checks the settings of an OGC node a tool wants to store and completes them with the endpoint, which the
 * node carries as a copy (as nodes created in the editor do).
 *
 * With `endpointChosen` the endpoint is the one named by `endpointId` (or the default of the version).
 * Otherwise the node keeps the endpoint it has, which may have been removed from the version since.
 */
export declare function resolveOgcNodeData(app: Application, version: Pick<ModelsVersions, 'ogcEndpoints'>, data: Record<string, any>, endpointChosen: boolean): {
    query: any;
    endpointId: string;
    baseUrl: string;
    apiType: import("../shared/simulation-adapter/ogc-endpoints.js").OgcApiType | undefined;
};
export declare const ogcTools: ToolDefinition[];
