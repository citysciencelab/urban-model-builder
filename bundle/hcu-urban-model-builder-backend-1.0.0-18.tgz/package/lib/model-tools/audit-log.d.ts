import type { Application } from '../declarations.js';
import type { ToolErrorCode, ToolSource } from './types.js';
export declare function recordToolCall(app: Application, call: {
    userId: string;
    source: ToolSource;
    tool: string;
    input: unknown;
    ok: boolean;
    errorCode?: ToolErrorCode;
    durationMs: number;
}): Promise<void>;
/** Deletes the entries that are older than the configured retention. */
export declare function pruneToolCalls(app: Application): Promise<number>;
