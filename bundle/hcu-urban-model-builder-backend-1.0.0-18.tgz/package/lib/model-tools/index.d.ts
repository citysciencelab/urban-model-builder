import type { Application } from '../declarations.js';
import type { User } from '../services/users/users.js';
import { type Simulator, type ToolSource } from './types.js';
export { ToolError } from './types.js';
export type { SimulationRequest, Simulator, ToolContext, ToolDefinition, ToolErrorCode, ToolSource } from './types.js';
/** The tools as a front end needs them to advertise them: name, description and JSON Schema of the input. */
export declare function listTools(): {
    name: string;
    description: string;
    inputSchema: import("@sinclair/typebox").TSchema;
    readOnly: boolean;
}[];
/**
 * Runs a tool on behalf of a user. Every failure is a `ToolError`: its message is written for the language
 * model, and nothing about the server's internals leaks through it. Every call is rate limited and recorded
 * in the tool call log.
 */
export declare function callTool(app: Application, user: User, name: string, input?: unknown, options?: {
    source?: ToolSource;
    simulator?: Simulator;
}): Promise<unknown>;
