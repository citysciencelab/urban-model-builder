/**
 * Runs simulations in a thread of its own (see simulation-runner.ts). The thread has no database connection:
 * it gets the model version with its nodes and edges and serves them to the simulation adapter from memory,
 * as the demo mode of the client does.
 */
export type SimulationJob = {
    id: number;
    version: {
        id: string;
    } & Record<string, unknown>;
    nodes: ({
        id: string;
    } & Record<string, unknown>)[];
    edges: ({
        id: string;
    } & Record<string, unknown>)[];
    parameterValues: Record<string, number>;
};
export type SimulationJobResult = {
    id: number;
    ok: true;
    result: unknown;
} | {
    id: number;
    ok: false;
    error: {
        message: string;
        nodeId?: string | null;
    };
};
