/** Names used towards language models instead of the numeric enums. */
export declare const NODE_TYPE_NAMES: {
    readonly 0: "stock";
    readonly 1: "variable";
    readonly 2: "flow";
    readonly 3: "converter";
    readonly 4: "state";
    readonly 5: "transition";
    readonly 6: "action";
    readonly 7: "population";
    readonly 8: "agent";
    readonly 9: "folder";
    readonly 10: "ghost";
    readonly 11: "ogc-api-features";
};
