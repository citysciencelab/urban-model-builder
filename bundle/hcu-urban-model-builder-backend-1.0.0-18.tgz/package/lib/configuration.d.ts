import type { Static } from '@feathersjs/typebox';
export declare const configurationSchema: import("@sinclair/typebox").TIntersect<[import("@sinclair/typebox").TObject<{
    authentication: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        secret: import("@sinclair/typebox").TString<string>;
        entity: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<string>, import("@sinclair/typebox").TNull]>>;
        entityId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        service: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        authStrategies: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>;
        parseStrategies: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
        jwtOptions: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{}>>;
        jwt: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
            header: import("@sinclair/typebox").TString<string>;
            schemes: import("@sinclair/typebox").TString<string>;
        }>>;
        local: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
            usernameField: import("@sinclair/typebox").TString<string>;
            passwordField: import("@sinclair/typebox").TString<string>;
            hashSize: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
            errorMessage: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            entityUsernameField: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            entityPasswordField: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        }>>;
        oauth: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
            redirect: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            origins: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
            defaults: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
                key: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
                secret: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
            }>>;
        }>>;
    }>>;
    paginate: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        default: import("@sinclair/typebox").TNumber;
        max: import("@sinclair/typebox").TNumber;
    }>>;
    origins: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>>;
    mongodb: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    mysql: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        client: import("@sinclair/typebox").TString<string>;
        connection: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<string>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TObject<{
            host: import("@sinclair/typebox").TString<string>;
            port: import("@sinclair/typebox").TNumber;
            user: import("@sinclair/typebox").TString<string>;
            password: import("@sinclair/typebox").TString<string>;
            database: import("@sinclair/typebox").TString<string>;
        }>>]>;
        pool: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
            min: import("@sinclair/typebox").TNumber;
            max: import("@sinclair/typebox").TNumber;
        }>>;
    }>>;
    postgresql: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        client: import("@sinclair/typebox").TString<string>;
        connection: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<string>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TObject<{
            host: import("@sinclair/typebox").TString<string>;
            port: import("@sinclair/typebox").TNumber;
            user: import("@sinclair/typebox").TString<string>;
            password: import("@sinclair/typebox").TString<string>;
            database: import("@sinclair/typebox").TString<string>;
        }>>]>;
        pool: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
            min: import("@sinclair/typebox").TNumber;
            max: import("@sinclair/typebox").TNumber;
        }>>;
    }>>;
    sqlite: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        client: import("@sinclair/typebox").TString<string>;
        connection: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<string>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TObject<{
            host: import("@sinclair/typebox").TString<string>;
            port: import("@sinclair/typebox").TNumber;
            user: import("@sinclair/typebox").TString<string>;
            password: import("@sinclair/typebox").TString<string>;
            database: import("@sinclair/typebox").TString<string>;
        }>>]>;
        pool: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
            min: import("@sinclair/typebox").TNumber;
            max: import("@sinclair/typebox").TNumber;
        }>>;
    }>>;
    mssql: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        client: import("@sinclair/typebox").TString<string>;
        connection: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<string>, import("@sinclair/typebox").TPartial<import("@sinclair/typebox").TObject<{
            host: import("@sinclair/typebox").TString<string>;
            port: import("@sinclair/typebox").TNumber;
            user: import("@sinclair/typebox").TString<string>;
            password: import("@sinclair/typebox").TString<string>;
            database: import("@sinclair/typebox").TString<string>;
        }>>]>;
        pool: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
            min: import("@sinclair/typebox").TNumber;
            max: import("@sinclair/typebox").TNumber;
        }>>;
    }>>;
}>, import("@sinclair/typebox").TObject<{
    host: import("@sinclair/typebox").TString<string>;
    port: import("@sinclair/typebox").TNumber;
    public: import("@sinclair/typebox").TString<string>;
    ogc: import("@sinclair/typebox").TObject<{
        /** Hosts, with port if it is not the default one, e.g. "api.hamburg.de". */
        allowedHosts: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>;
    }>;
    limits: import("@sinclair/typebox").TObject<{
        toolCallsPerMinute: import("@sinclair/typebox").TNumber;
        simulationsPerMinute: import("@sinclair/typebox").TNumber;
        chatTurnsPerHour: import("@sinclair/typebox").TNumber;
        /** A simulation started by a tool is stopped after this time. */
        simulationTimeoutSeconds: import("@sinclair/typebox").TNumber;
        maxConcurrentSimulations: import("@sinclair/typebox").TNumber;
        /** How long the in-app chat waits for the user's browser to return a simulation. */
        browserSimulationTimeoutSeconds: import("@sinclair/typebox").TNumber;
        /** Entries of the tool call log are deleted after this many days. */
        auditLogRetentionDays: import("@sinclair/typebox").TNumber;
    }>;
    mcp: import("@sinclair/typebox").TObject<{
        /** The URL under which clients reach the MCP endpoint, e.g. https://api.example.org/mcp. */
        publicUrl: import("@sinclair/typebox").TString<"uri">;
        oauth: import("@sinclair/typebox").TObject<{
            /** Accept OAuth access tokens of the OIDC issuer in addition to personal access tokens. */
            enabled: import("@sinclair/typebox").TBoolean;
            /** The client scope of the authorization server that adds `publicUrl` as audience to a token. */
            scope: import("@sinclair/typebox").TString<string>;
        }>;
    }>;
    llm: import("@sinclair/typebox").TObject<{
        /** Secret the users' API keys are encrypted with. Without it, keys cannot be stored and the chat is off. */
        encryptionSecret: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        openRouterBaseUrl: import("@sinclair/typebox").TString<string>;
        /** OpenRouter ids of the models users may choose from. */
        models: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>;
        defaultModel: import("@sinclair/typebox").TString<string>;
        /** Upper limit of model calls for one chat message. */
        maxIterations: import("@sinclair/typebox").TNumber;
    }>;
}>]>;
export type ApplicationConfiguration = Static<typeof configurationSchema>;
export declare const configurationValidator: import("@feathersjs/schema").Validator<any, any>;
