import type { Static } from '@feathersjs/typebox';
export declare const chatRequestSchema: import("@sinclair/typebox").TObject<{
    /** Chosen by the client, to match progress events with its request. */
    requestId: import("@sinclair/typebox").TString<"uuid">;
    /** The model version the conversation is about, i.e. the one open in the editor. */
    modelVersionId: import("@sinclair/typebox").TString<"uuid">;
    messages: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        role: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"user">, import("@sinclair/typebox").TLiteral<"assistant">]>;
        content: import("@sinclair/typebox").TString<string>;
    }>>;
    /** One of the configured models; the user's preferred or the default model if omitted. */
    model: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    /** Copy the model version before the assistant changes anything for the first time. */
    createCheckpoint: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
}>;
export type ChatRequest = Static<typeof chatRequestSchema>;
export declare const chatRequestValidator: import("@feathersjs/schema").Validator<any, any>;
export declare const chatResponseSchema: import("@sinclair/typebox").TObject<{
    requestId: import("@sinclair/typebox").TString<string>;
    status: import("@sinclair/typebox").TLiteral<"completed">;
    model: import("@sinclair/typebox").TString<string>;
    message: import("@sinclair/typebox").TObject<{
        role: import("@sinclair/typebox").TLiteral<"assistant">;
        content: import("@sinclair/typebox").TString<string>;
    }>;
    toolCalls: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        name: import("@sinclair/typebox").TString<string>;
        arguments: import("@sinclair/typebox").TUnknown;
        ok: import("@sinclair/typebox").TBoolean;
        error: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>>;
    /** True if the assistant was stopped because it needed too many steps. */
    limitReached: import("@sinclair/typebox").TBoolean;
    usage: import("@sinclair/typebox").TObject<{
        promptTokens: import("@sinclair/typebox").TNumber;
        completionTokens: import("@sinclair/typebox").TNumber;
    }>;
    /** The backup copy that was made before the first change, if any. */
    checkpoint: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        modelId: import("@sinclair/typebox").TString<string>;
        modelVersionId: import("@sinclair/typebox").TString<string>;
        name: import("@sinclair/typebox").TString<string>;
    }>>;
}>;
export type ChatResponse = Static<typeof chatResponseSchema>;
/** Result of `create` over a real-time connection: the answer follows as a progress event. */
export declare const chatStartedSchema: import("@sinclair/typebox").TObject<{
    requestId: import("@sinclair/typebox").TString<string>;
    status: import("@sinclair/typebox").TLiteral<"started">;
}>;
export type ChatStarted = Static<typeof chatStartedSchema>;
/**
 * What the user's browser sends back after simulating on behalf of the assistant: the summary of
 * `summarizeSimulation` (src/shared/simulation-summary.ts), or the error of the simulation.
 */
export declare const chatSimulationResultSchema: import("@sinclair/typebox").TObject<{
    simulationId: import("@sinclair/typebox").TString<"uuid">;
    summary: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        steps: import("@sinclair/typebox").TInteger;
        sampledTimes: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TNumber>;
        series: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
            nodeId: import("@sinclair/typebox").TString<string>;
        }>>;
        hint: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
    }>>;
    error: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        message: import("@sinclair/typebox").TString<string>;
        nodeId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<string>, import("@sinclair/typebox").TNull]>>;
    }>>;
}>;
export type ChatSimulationResult = Static<typeof chatSimulationResultSchema>;
export declare const chatSimulationResultValidator: import("@feathersjs/schema").Validator<any, any>;
