import type { Params } from '@feathersjs/feathers';
import type { ModelsVersions } from '../services/models-versions/models-versions.schema.js';
import type { Nodes } from '../services/nodes/nodes.schema.js';
import type { Edges } from '../services/edges/edges.schema.js';
import { type ToolContext } from './types.js';
/**
 * Provider name of service calls made on behalf of a user. Any provider makes a call "external" for the
 * existing hooks, so permission filters and permission checks apply exactly as for REST and Socket.IO.
 */
export declare const MODEL_TOOLS_PROVIDER = "model-tools";
/** Params for a service call that must be subject to the user's permissions. */
export declare const userParams: (ctx: ToolContext, extra?: Params) => Params;
/** Loads a model version the user may read (member of the model, or the version is published). */
export declare function getReadableVersion(ctx: ToolContext, modelVersionId: string): Promise<ModelsVersions>;
/** Loads a model version and ensures the user may edit its graph: collaborator or higher, draft, latest. */
export declare function getEditableVersion(ctx: ToolContext, modelVersionId: string): Promise<ModelsVersions>;
/**
 * Loads the graph of a version. Callers must have checked access to the version before, because these are
 * internal calls without a permission filter.
 */
export declare function loadGraph(ctx: ToolContext, modelVersionId: string): Promise<{
    nodes: Nodes[];
    edges: Edges[];
}>;
