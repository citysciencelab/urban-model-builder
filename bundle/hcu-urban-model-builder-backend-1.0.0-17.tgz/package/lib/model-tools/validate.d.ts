import { EdgeType, NodeType } from '../client.js';
/** The parts of nodes and edges the checks need, so they work on stored and on not yet stored graphs. */
export type CheckNode = {
    id: string;
    type: NodeType;
    name?: string | null;
    data: Record<string, any>;
    ghostParentId?: string | null;
};
export type CheckEdge = {
    type: EdgeType;
    sourceId: string;
    targetId: string;
};
export type GraphIssue = {
    severity: 'error' | 'warning';
    nodeId?: string;
    nodeName?: string;
    message: string;
};
/**
 * Index to answer whether a node may use another node in its equations. A node can reference the nodes linked
 * to it, and a flow or transition can reference the nodes it connects.
 */
export declare function buildReferenceIndex(nodes: CheckNode[], edges: CheckEdge[]): {
    origin: (id: string) => string;
    byName: Map<string, CheckNode[]>;
    isConnected: (sourceId: string, targetId: string) => boolean;
    connect: (sourceId: string, targetId: string) => Set<string>;
};
export type ReferenceIndex = ReturnType<typeof buildReferenceIndex>;
/** Sorts the [Name] references of a node into unknown names, ambiguous names and nodes that are not linked. */
export declare function checkReferences(node: CheckNode, index: ReferenceIndex): {
    unknown: string[];
    ambiguous: string[];
    unlinked: CheckNode[];
};
/** Static checks that find the usual reasons for a failing or meaningless simulation without running it. */
export declare function validateGraph(nodes: CheckNode[], edges: CheckEdge[]): GraphIssue[];
