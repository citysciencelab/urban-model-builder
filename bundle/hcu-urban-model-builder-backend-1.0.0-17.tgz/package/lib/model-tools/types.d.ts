import type { Static, TSchema } from '@feathersjs/typebox';
import type { Application } from '../declarations.js';
import type { User } from '../services/users/users.js';
/** Everything a tool needs to act: the app and the user on whose behalf it acts. */
export interface ToolContext {
    app: Application;
    user: User;
}
export interface ToolDefinition<S extends TSchema = TSchema> {
    name: string;
    /** Written for the language model: what the tool does and when to use it. */
    description: string;
    inputSchema: S;
    /** True if the tool never changes data. Front ends can use this to skip confirmations. */
    readOnly: boolean;
    handler: (ctx: ToolContext, input: Static<S>) => Promise<unknown>;
}
export declare const defineTool: <S extends TSchema>(tool: ToolDefinition<S>) => ToolDefinition<S>;
export type ToolErrorCode = 'unknown_tool' | 'invalid_input' | 'not_found' | 'forbidden' | 'conflict' | 'simulation_failed' | 'internal';
/** An error whose message is meant to be shown to the language model so it can correct itself. */
export declare class ToolError extends Error {
    code: ToolErrorCode;
    details?: unknown | undefined;
    constructor(code: ToolErrorCode, message: string, details?: unknown | undefined);
    toJSON(): {
        code: ToolErrorCode;
        message: string;
        details: unknown;
    };
}
