import type { Nodes } from '../services/nodes/nodes.schema.js';
type SimulationResult = {
    times: number[];
    nodes: Record<string, {
        series: unknown[];
    }>;
};
/** Indices of at most `maxPoints` evenly spread entries, always including the first and the last one. */
export declare function sampleIndices(length: number, maxPoints: number): number[];
/**
 * Reduces a simulation result to what a language model can use: per recorded node a few statistics and a
 * sample of the series, instead of every time step.
 */
export declare function summarizeSimulation(result: SimulationResult, nodes: Nodes[], maxPoints: number): {
    hint?: string | undefined;
    steps: number;
    sampledTimes: number[];
    series: ({
        first: number;
        last: number;
        min: number;
        max: number;
        mean: number;
        values: number[];
        nodeId: string;
        name: string | null | undefined;
        type: "variable" | "state" | "transition" | "action" | "agent" | "flow" | "stock" | "converter" | "population" | "folder" | "ghost" | "ogc-api-features" | undefined;
    } | {
        agentCount: number;
        stateCounts: Record<string, number>[];
        nodeId: string;
        name: string | null | undefined;
        type: "variable" | "state" | "transition" | "action" | "agent" | "flow" | "stock" | "converter" | "population" | "folder" | "ghost" | "ogc-api-features" | undefined;
    } | {
        values: unknown[];
        nodeId: string;
        name: string | null | undefined;
        type: "variable" | "state" | "transition" | "action" | "agent" | "flow" | "stock" | "converter" | "population" | "folder" | "ghost" | "ogc-api-features" | undefined;
    })[];
};
export {};
