import { EdgeType, NodeType } from '../client.js';
export type Side = 'top' | 'right' | 'bottom' | 'left';
/** The parts of a node the layout needs. Positions are relative to the parent, as in the editor. */
export type LayoutNode = {
    id: string;
    type: NodeType;
    parentId: string | null;
    ghostParentId: string | null;
    position: {
        x: number;
        y: number;
    };
    width: number | null;
    height: number | null;
    data: {
        direction?: Side;
    };
};
export type LayoutEdge = {
    type: EdgeType;
    sourceId: string;
    targetId: string;
};
export type LayoutChange = {
    position?: {
        x: number;
        y: number;
    };
    width?: number;
    height?: number;
};
export declare const CONTAINER_MIN_SIZE: {
    width: number;
    height: number;
};
export declare function nodeSize(node: LayoutNode): {
    width: number;
    height: number;
};
/**
 * Computes positions for the `movable` nodes and sizes for containers that have to grow.
 *
 * Each container is laid out on its own, innermost first, so that a container is a single box for the level
 * above. Nodes that are not movable keep their place; movable siblings are laid out as a block below them.
 * The given nodes are not modified.
 */
export declare function computeLayout(nodes: LayoutNode[], edges: LayoutEdge[], movable: Set<string>): Map<string, LayoutChange>;
/**
 * The direction a flow or transition node should point to: towards its end node, or away from its start node.
 * Returns null if it is connected to neither.
 */
export declare function arrowDirection(node: LayoutNode, edges: LayoutEdge[], byId: Map<string, LayoutNode>): Side | null;
/** Chooses the handles of an edge from the relative position of its two nodes, as a user would. */
export declare function edgeHandles(edge: LayoutEdge, byId: Map<string, LayoutNode>): {
    sourceHandle: string;
    targetHandle: string;
};
