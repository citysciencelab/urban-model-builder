/** Reference text for language models: how a model is built from nodes and edges. */
export declare function getModelingReference(): string;
