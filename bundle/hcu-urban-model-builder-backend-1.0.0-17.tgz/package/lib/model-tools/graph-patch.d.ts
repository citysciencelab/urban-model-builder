import { type Static } from '@feathersjs/typebox';
import { type ToolContext } from './types.js';
export declare const graphPatchSchema: import("@sinclair/typebox").TObject<{
    modelVersionId: import("@sinclair/typebox").TString<"uuid">;
    createNodes: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        isParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        parameterMin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        parameterMax: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        parameterStep: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        isOutputParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        ref: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        type: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"variable" | "state" | "transition" | "action" | "agent" | "flow" | "stock" | "converter" | "population" | "folder">[]>;
        name: import("@sinclair/typebox").TString<string>;
        description: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        data: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{}>>;
        parent: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        position: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>>;
    }>>>;
    updateNodes: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        isParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        parameterMin: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        parameterMax: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        parameterStep: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        isOutputParameter: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        id: import("@sinclair/typebox").TString<"uuid">;
        name: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        description: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString<string>>;
        data: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{}>>;
        parent: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString<string>, import("@sinclair/typebox").TNull]>>;
        position: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
            x: import("@sinclair/typebox").TNumber;
            y: import("@sinclair/typebox").TNumber;
        }>>;
    }>>>;
    deleteNodeIds: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>>;
    createEdges: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        type: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<"link" | "transition" | "flow" | "agent-population">[]>;
        source: import("@sinclair/typebox").TString<string>;
        target: import("@sinclair/typebox").TString<string>;
    }>>>;
    deleteEdgeIds: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<"uuid">>>;
    autoLink: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
}>;
export type GraphPatch = Static<typeof graphPatchSchema>;
/** Applies a batch of changes to the graph of a draft version: all of it, or nothing. */
export declare function applyGraphPatch(ctx: ToolContext, input: GraphPatch): Promise<{
    createdNodes: {
        ref: string | undefined;
        id: string;
        type: "variable" | "state" | "transition" | "action" | "agent" | "flow" | "stock" | "converter" | "population" | "folder" | "ghost" | "ogc-api-features";
        name: string | null | undefined;
    }[];
    createdEdges: {
        autoLinked?: boolean | undefined;
        id: string;
        type: "link" | "transition" | "flow" | "agent-population";
        source: string;
        target: string;
    }[];
    updatedNodeIds: string[];
    deletedNodeIds: string[];
    deletedEdgeIds: string[];
    warnings: string[];
    issues: import("./validate.js").GraphIssue[];
}>;
