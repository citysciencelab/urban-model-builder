import type { Application } from '../declarations.js';
type GraphService = 'nodes' | 'edges';
/** Maps placeholder ids of records created earlier in the same batch to their real ids. */
export type IdMap = Map<string, string>;
export type BatchOperation = {
    service: GraphService;
    method: 'create';
    placeholderId: string;
    data: (ids: IdMap) => any;
} | {
    service: GraphService;
    method: 'patch';
    id: string;
    data: (ids: IdMap) => any;
} | {
    service: GraphService;
    method: 'remove';
    id: string;
};
/**
 * Runs graph writes in one database transaction and emits the real-time events only after the commit, so that
 * connected editors never see a change that is rolled back afterwards.
 *
 * The writes are internal service calls: schema validation and all other hooks run, but the per-record
 * permission checks do not. The caller must have checked that the user may edit the model version.
 *
 * `cascadedRemovals` are records the database removes implicitly (children, ghosts and edges of removed nodes);
 * their `removed` events are emitted too, because the services do not know about them.
 */
export declare function executeBatch(app: Application, operations: BatchOperation[], cascadedRemovals?: {
    service: GraphService;
    record: any;
}[]): Promise<{
    ids: IdMap;
    records: any[];
}>;
export {};
