import type { ClientApplication } from '../../client.js';
import type { ChatProgress, ChatRequest, ChatResponse, ChatStarted, ChatService } from './chat.class.js';
export type { ChatProgress, ChatRequest, ChatResponse, ChatStarted };
export type ChatClientService = Pick<ChatService, (typeof chatMethods)[number]>;
export declare const chatPath = "chat";
export declare const chatMethods: Array<keyof ChatService>;
/** Event sent to the caller of `create` while its request is running. */
export declare const CHAT_PROGRESS_EVENT = "progress";
export declare const chatClient: (client: ClientApplication) => void;
declare module '../../client.js' {
    interface ServiceTypes {
        [chatPath]: ChatClientService;
    }
}
