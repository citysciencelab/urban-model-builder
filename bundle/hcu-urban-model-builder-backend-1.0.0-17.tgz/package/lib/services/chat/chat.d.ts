import type { Application } from '../../declarations.js';
import { ChatService } from './chat.class.js';
import { chatPath } from './chat.shared.js';
export * from './chat.class.js';
export * from './chat.schema.js';
export declare const chat: (app: Application) => void;
declare module '../../declarations.js' {
    interface ServiceTypes {
        [chatPath]: ChatService;
    }
}
