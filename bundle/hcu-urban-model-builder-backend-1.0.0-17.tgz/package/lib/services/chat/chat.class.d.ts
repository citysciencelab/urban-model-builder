import type { Params } from '@feathersjs/feathers';
import type { Application } from '../../declarations.js';
import { type AgentEvent } from '../../llm/agent.js';
import type { ChatRequest, ChatResponse, ChatStarted } from './chat.schema.js';
export type { ChatRequest, ChatResponse, ChatStarted };
/**
 * Payload of the progress event. A turn that was started over a real-time connection ends with exactly one
 * `done` or `error` event.
 */
export type ChatProgress = {
    requestId: string;
} & (AgentEvent | {
    type: 'done';
    response: ChatResponse;
} | {
    type: 'error';
    message: string;
    reason?: string;
});
/** Internal: the channel a progress event is published to. Removed before the event is sent. */
export declare const PROGRESS_CHANNEL_KEY = "_channel";
/**
 * The in-app chat: one call is one turn of a conversation with a language model that can use the model tools
 * on behalf of the calling user. The model is reached through OpenRouter with the user's own API key.
 */
export declare class ChatService {
    private app;
    /** Users with a running turn; a second one has to wait, which also bounds the load a user can cause. */
    private busyUsers;
    constructor(app: Application);
    /**
     * Starts a turn. Over a real-time connection the call returns at once and the answer follows as a `done`
     * (or `error`) progress event, because a turn takes longer than clients wait for a response. Other callers
     * (REST, internal) get the answer as the result.
     */
    create(data: ChatRequest, params?: Params): Promise<ChatResponse | ChatStarted>;
    private runTurn;
    private getVersion;
    /** Copies the version into a new model of the user, as there is no undo for changes of the assistant. */
    private createCheckpoint;
}
