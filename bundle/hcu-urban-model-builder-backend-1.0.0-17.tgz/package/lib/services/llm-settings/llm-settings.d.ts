import type { Application } from '../../declarations.js';
import { LlmSettingsService } from './llm-settings.class.js';
import { llmSettingsPath } from './llm-settings.shared.js';
export * from './llm-settings.class.js';
export * from './llm-settings.schema.js';
export declare const llmSettings: (app: Application) => void;
declare module '../../declarations.js' {
    interface ServiceTypes {
        [llmSettingsPath]: LlmSettingsService;
    }
}
