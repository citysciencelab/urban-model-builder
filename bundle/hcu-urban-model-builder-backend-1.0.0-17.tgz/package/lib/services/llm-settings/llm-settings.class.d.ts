import type { Id, Params } from '@feathersjs/feathers';
import type { Application } from '../../declarations.js';
import type { LlmSettings, LlmSettingsPatch } from './llm-settings.schema.js';
export type { LlmSettings, LlmSettingsPatch };
/**
 * The settings of the signed-in user for the in-app chat: their OpenRouter API key and preferred model.
 *
 * The key is write-only. It is stored encrypted, never returned by this service, and decrypted only on the
 * server for a chat request (`getOpenRouterKey`).
 */
export declare class LlmSettingsService {
    private app;
    constructor(app: Application);
    private get knex();
    private getUserId;
    get(id: Id, params?: Params): Promise<LlmSettings>;
    patch(id: Id, data: LlmSettingsPatch, params?: Params): Promise<LlmSettings>;
    /** Server-side only: the decrypted key of a user, or null if there is none or it cannot be decrypted. */
    getOpenRouterKey(userId: string): Promise<string | null>;
}
