import type { ClientApplication } from '../../client.js';
import type { LlmSettings, LlmSettingsPatch, LlmSettingsService } from './llm-settings.class.js';
export type { LlmSettings, LlmSettingsPatch };
export type LlmSettingsClientService = Pick<LlmSettingsService, (typeof llmSettingsMethods)[number]>;
export declare const llmSettingsPath = "llm-settings";
export declare const llmSettingsMethods: Array<keyof LlmSettingsService>;
/** The only id of the service: the settings of the signed-in user. */
export declare const LLM_SETTINGS_ID = "me";
export declare const llmSettingsClient: (client: ClientApplication) => void;
declare module '../../client.js' {
    interface ServiceTypes {
        [llmSettingsPath]: LlmSettingsClientService;
    }
}
