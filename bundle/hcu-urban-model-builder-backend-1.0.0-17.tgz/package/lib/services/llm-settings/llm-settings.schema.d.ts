import type { Static } from '@feathersjs/typebox';
export declare const llmSettingsSchema: import("@sinclair/typebox").TObject<{
    /** False if the server cannot store keys; the chat is then unavailable for everyone. */
    chatAvailable: import("@sinclair/typebox").TBoolean;
    hasOpenRouterKey: import("@sinclair/typebox").TBoolean;
    openRouterKeyHint: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    /** The model the user chose, null for the default. */
    model: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    defaultModel: import("@sinclair/typebox").TString<string>;
    availableModels: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString<string>>;
}>;
export type LlmSettings = Static<typeof llmSettingsSchema>;
export declare const llmSettingsPatchSchema: import("@sinclair/typebox").TObject<{
    openRouterKey: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
    model: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TNull, import("@sinclair/typebox").TString<string>]>>;
}>;
export type LlmSettingsPatch = Static<typeof llmSettingsPatchSchema>;
export declare const llmSettingsPatchValidator: import("@feathersjs/schema").Validator<any, any>;
