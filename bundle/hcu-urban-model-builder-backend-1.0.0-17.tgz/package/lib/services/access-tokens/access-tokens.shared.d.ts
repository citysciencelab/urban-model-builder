import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client.js';
import type { AccessTokens, AccessTokensData, AccessTokensQuery, AccessTokensService } from './access-tokens.class.js';
export type { AccessTokens, AccessTokensData, AccessTokensQuery };
export type AccessTokensClientService = Pick<AccessTokensService<Params<AccessTokensQuery>>, (typeof accessTokensMethods)[number]>;
export declare const accessTokensPath = "access-tokens";
export declare const accessTokensMethods: Array<keyof AccessTokensService>;
export declare const accessTokensClient: (client: ClientApplication) => void;
declare module '../../client.js' {
    interface ServiceTypes {
        [accessTokensPath]: AccessTokensClientService;
    }
}
