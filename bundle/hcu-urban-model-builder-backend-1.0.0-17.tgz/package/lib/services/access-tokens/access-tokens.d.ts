import type { Application } from '../../declarations.js';
import { AccessTokensService } from './access-tokens.class.js';
import { accessTokensPath } from './access-tokens.shared.js';
export * from './access-tokens.class.js';
export * from './access-tokens.schema.js';
export declare const accessTokens: (app: Application) => void;
declare module '../../declarations.js' {
    interface ServiceTypes {
        [accessTokensPath]: AccessTokensService;
    }
}
