import type { Application } from '../../declarations.js';
import type { User } from '../users/users.js';
/** Makes tokens recognisable, for users and for secret scanners. */
export declare const ACCESS_TOKEN_PREFIX = "umb_pat_";
export declare function generateAccessToken(): {
    token: string;
    tokenHash: string;
    tokenPrefix: string;
};
/**
 * A token is 256 random bits, so a plain SHA-256 is sufficient: there is nothing to guess, and the hash can be
 * looked up by index, which a salted password hash could not.
 */
export declare function hashAccessToken(token: string): string;
/** Returns the user a valid, unexpired token belongs to, otherwise null. */
export declare function resolveAccessToken(app: Application, token: string): Promise<User | null>;
