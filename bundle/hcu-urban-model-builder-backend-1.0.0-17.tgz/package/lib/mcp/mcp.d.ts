import type { Middleware } from 'koa';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import type { Application } from '../declarations.js';
import type { User } from '../services/users/users.js';
export declare const MCP_PATH = "/mcp";
/**
 * Builds an MCP server whose tools act on behalf of one user. The server is a thin adapter: which tools exist
 * and what they do is defined by the tool layer in `src/model-tools`.
 */
export declare function createMcpServer(app: Application, user: User): Server<{
    method: string;
    params?: {
        [x: string]: unknown;
        _meta?: {
            [x: string]: unknown;
            progressToken?: string | number | undefined;
            "io.modelcontextprotocol/related-task"?: {
                taskId: string;
            } | undefined;
        } | undefined;
    } | undefined;
}, {
    method: string;
    params?: {
        [x: string]: unknown;
        _meta?: {
            [x: string]: unknown;
            progressToken?: string | number | undefined;
            "io.modelcontextprotocol/related-task"?: {
                taskId: string;
            } | undefined;
        } | undefined;
    } | undefined;
}, {
    [x: string]: unknown;
    _meta?: {
        [x: string]: unknown;
        progressToken?: string | number | undefined;
        "io.modelcontextprotocol/related-task"?: {
            taskId: string;
        } | undefined;
    } | undefined;
}>;
/**
 * Koa middleware that serves the MCP endpoint (Streamable HTTP transport) at `MCP_PATH`.
 *
 * Callers authenticate with a personal access token. The endpoint is stateless: every request gets its own
 * server and transport, so it needs no session affinity and works behind a load balancer.
 */
export declare function mcpMiddleware(app: Application): Middleware;
