/** Messages and tool calls in the format of OpenRouter's (OpenAI-compatible) chat completions API. */
export type ToolCall = {
    id: string;
    type: 'function';
    function: {
        name: string;
        arguments: string;
    };
};
export type ChatMessage = {
    role: 'system' | 'user';
    content: string;
} | {
    role: 'assistant';
    content: string | null;
    tool_calls?: ToolCall[];
} | {
    role: 'tool';
    tool_call_id: string;
    content: string;
};
export type ToolSpecification = {
    type: 'function';
    function: {
        name: string;
        description: string;
        parameters: unknown;
    };
};
export type Usage = {
    promptTokens: number;
    completionTokens: number;
};
export type LlmErrorReason = 'invalid_api_key' | 'insufficient_credits' | 'rate_limited' | 'llm_error';
/** A failed request to the model provider, with a message that can be shown to the user. */
export declare class LlmError extends Error {
    reason: LlmErrorReason;
    constructor(reason: LlmErrorReason, message: string);
}
/**
 * Sends one chat completion request and reads the streamed answer. Text is passed on as it arrives; the
 * complete answer, including the tool calls the model wants to make, is returned at the end.
 */
export declare function streamChatCompletion(options: {
    baseUrl: string;
    apiKey: string;
    model: string;
    messages: ChatMessage[];
    tools: ToolSpecification[];
    signal?: AbortSignal;
    onTextDelta?: (text: string) => void;
}): Promise<{
    content: string;
    toolCalls: ToolCall[];
    usage: Usage;
}>;
