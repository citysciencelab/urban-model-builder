import type { Application } from '../declarations.js';
/** Whether the server is configured to store secrets of users. */
export declare const canStoreSecrets: (app: Application) => boolean;
/** Encrypts a secret of a user for storage (AES-256-GCM, authenticated). */
export declare function encryptSecret(app: Application, plaintext: string): string;
/** Returns the secret, or null if it cannot be decrypted, e.g. after the encryption secret was changed. */
export declare function decryptSecret(app: Application, stored: string): string | null;
