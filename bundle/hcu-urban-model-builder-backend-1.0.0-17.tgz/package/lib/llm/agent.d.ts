import type { Application } from '../declarations.js';
import type { User } from '../services/users/users.js';
import { type ChatMessage, type Usage } from './openrouter.js';
/** What happens during a turn, reported while it runs so the user can follow it. */
export type AgentEvent = {
    type: 'text_delta';
    text: string;
} | {
    type: 'tool_call';
    id: string;
    name: string;
    arguments: unknown;
} | {
    type: 'tool_result';
    id: string;
    name: string;
    ok: boolean;
    error?: string;
};
export type AgentToolCall = {
    name: string;
    arguments: unknown;
    ok: boolean;
    error?: string;
};
/**
 * Runs one turn of the chat: calls the model, executes the tools it asks for on behalf of the user, feeds the
 * results back, and repeats until the model answers in text or the iteration limit is reached.
 */
export declare function runAgent(options: {
    app: Application;
    user: User;
    apiKey: string;
    model: string;
    messages: ChatMessage[];
    signal?: AbortSignal;
    onEvent?: (event: AgentEvent) => void;
    /** Called once, before the first tool that changes data. */
    beforeFirstWrite?: () => Promise<void>;
}): Promise<{
    content: string;
    toolCalls: AgentToolCall[];
    usage: Usage;
    iterations: number;
    limitReached: boolean;
}>;
